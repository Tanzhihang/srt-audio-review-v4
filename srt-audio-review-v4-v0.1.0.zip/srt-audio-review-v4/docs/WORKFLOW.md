# V4 工作流与关键命令

以下命令从仓库根目录运行。完整执行要求见 [SKILL.md](../skills/srt-audio-review-v4/SKILL.md)。所有源文件只读，工作文件放在独立目录；不要将 `--out` 或 `--report` 指向源 SRT、源音频或 edits 输入。

## 1. 建立基线与候选

```bash
python3 skills/srt-audio-review-v4/scripts/prepare_trial.py \
  --srt input.srt --audio original.wav --out-dir work/review --topic automotive

python3 skills/srt-audio-review-v4/scripts/full_srt_prescan.py \
  --srt input.srt --context-manifest work/review/context_manifest.json \
  --out-dir work/review --term '本次指定术语'

python3 skills/srt-audio-review-v4/scripts/build_boundary_candidates.py \
  --srt input.srt --out work/review/boundary_candidates.json --term '本次指定术语'
```

`--topic` 支持 `general`、`phone`、`automotive`。扫描结果只是候选；必须阅读全部正文和所有 `N−1` 个相邻边界，阅读过程中记录台账。

## 2. 本地全量转写

首次初始化需要 Python 3.10+、ffmpeg，以及允许联网下载依赖和模型：

```bash
python3 skills/srt-audio-review-v4/scripts/setup_local_whisper.py

python3 skills/srt-audio-review-v4/scripts/transcribe_local_whisper.py \
  --audio original.wav --out work/review/local_whisper_full.json \
  --initial-prompt '本次规范术语和产品名'

python3 skills/srt-audio-review-v4/scripts/compare_srt_local_whisper.py --help
```

默认 `small`、CPU、`fp16=false`、逐词时间戳。全部 D/B 项复用同一份转写。必要时截取并试听本地片段；Whisper 的差异不能自动覆盖字幕。

## 3. 冻结文字底稿，规划 B 组

先完成听写、术语和口水词处理，输出 `work/review/audio_calibrated.srt`。从这一刻起，断句只能移动块边界和空格，不得增删、改写或调换字符顺序。

再次扫描清理后的字幕边界。合并连续链式问题；B 组不能重叠，组内 D 修改不能独立写入。按 [B 组契约](../skills/srt-audio-review-v4/references/boundary-edit-schema.md) 与 [音频定位契约](../skills/srt-audio-review-v4/references/audio-timing-schema.md) 填写整组文字、时间与证据。每个新切口都必须定位到原音。

## 4. 原子应用整组修改

```bash
python3 skills/srt-audio-review-v4/scripts/apply_confirmed_timed_group_edits.py \
  --srt work/review/audio_calibrated.srt \
  --edits work/review/confirmed_boundary_edits.json \
  --out work/review/final.srt --report work/review/atomic_apply_report.json
```

原文不匹配、组重叠、证据未完成、组外时间变化或时长不合法时应中止。不要将兼容的仅文字写入器用于新断句组交付。

## 5. 全量复审和四项最终验收

重新阅读最终文件全部边界，保存 [逐边界台账](../skills/srt-audio-review-v4/references/boundary-review-ledger-schema.md)，再运行：

```bash
python3 skills/srt-audio-review-v4/scripts/validate_boundary_text_conservation.py \
  --before work/review/audio_calibrated.srt --after work/review/final.srt \
  --allow-timing-changes --report work/review/conservation.json

python3 skills/srt-audio-review-v4/scripts/validate_cross_block_semantics.py \
  --srt work/review/final.srt --baseline input.srt --allow-timing-changes \
  --term '本次指定术语' --report work/review/semantics.json

python3 skills/srt-audio-review-v4/scripts/validate_audio_timing_alignment.py \
  --srt work/review/final.srt --edits work/review/confirmed_boundary_edits.json \
  --audio original.wav --report work/review/audio_timing.json

python3 skills/srt-audio-review-v4/scripts/validate_boundary_review_ledger.py \
  --srt work/review/final.srt --ledger work/review/final_boundary_review_ledger.json \
  --report work/review/ledger_validation.json
```

无 B 组时，edits 采用空数组。存在合理人工保留项时，语义验收额外传 `--allowlist`，每项必须给出针对两侧实际文字的具体理由。不得用 allowlist 绕过字符守恒。全部验证通过后仍需确认实际语义复核已完成，不能机械生成台账充数。

## 演示扫描

仓库含人工编写的 `examples/demo.srt`，可测试候选扫描和 HTML 查看：

```bash
mkdir -p work/demo
python3 skills/srt-audio-review-v4/scripts/build_boundary_candidates.py \
  --srt examples/demo.srt --out work/demo/candidates.json
python3 skills/srt-audio-review-v4/scripts/build_boundary_confirmation_html.py \
  --candidates work/demo/candidates.json --out work/demo/review.html
```

这个例子没有对应原音，只用于展示候选扫描，不能视为完成音频校对。
