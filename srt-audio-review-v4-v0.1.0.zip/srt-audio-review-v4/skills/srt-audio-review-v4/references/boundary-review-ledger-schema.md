# V4 逐边界语义审查台账

台账用于证明最终文件的每一个相邻字幕边界都被实际阅读过。它不能由脚本在审查结束后统一填成“保留”；审查者必须按块号顺序，在阅读当前 3–5 块上下文时记录当前边界的结论。

```json
{
  "schema": "srt-audio-review-v4/boundary-review-ledger-v1",
  "srt_sha256": "FINAL_SRT_SHA256",
  "block_count": 3,
  "boundaries": [
    {
      "review_order": 1,
      "left_block": 1,
      "right_block": 2,
      "left_text": "一期视频告诉你",
      "right_text": "这个原厂升顶帐篷到底怎么使用",
      "cut": "一期视频告诉你 | 这个原厂升顶帐篷到底怎么使用",
      "decision": "edited",
      "group_id": "B0001",
      "review_basis": "原厂是完整词；原字已移动到右块，当前切口位于两个完整分句之间。"
    },
    {
      "review_order": 2,
      "left_block": 2,
      "right_block": 3,
      "left_text": "这个原厂升顶帐篷到底怎么使用",
      "right_text": "下一句",
      "cut": "这个原厂升顶帐篷到底怎么使用 | 下一句",
      "decision": "kept",
      "group_id": null,
      "review_basis": "左块问句语义结束，右块另起新句；切口未拆词、术语或句法附着成分。"
    }
  ]
}
```

## 字段约束

- `srt_sha256` 必须是最终 SRT 的实际 SHA-256。
- `boundaries` 必须按顺序完整覆盖 `1-2` 到 `N-1—N`，不可缺失、重复或乱序。
- `left_text`、`right_text` 必须逐字等于最终 SRT 对应字幕块正文。
- `cut` 必须等于 `左块末尾最多 16 个字符 + " | " + 右块开头最多 16 个字符`，换行折叠为空格。
- `decision` 只能是 `kept`、`edited` 或 `allowlisted`。
- `edited` 必须填写对应 B 组的 `group_id`；`allowlisted` 必须填写 `allowlist_signatures`。
- `review_basis` 必须引用当前切口的实际词语并说明句法关系；“自然续接”“已检查”“没问题”等空泛文字不合格。

验证脚本只证明台账完整且与最终文件一致，不能替代语义判断。若台账内容由机械模板批量生成，即使脚本通过也禁止交付。
