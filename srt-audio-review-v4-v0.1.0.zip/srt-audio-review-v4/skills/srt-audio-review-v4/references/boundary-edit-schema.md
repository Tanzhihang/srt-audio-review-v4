# V4 跨块修改数据契约

每个 B 候选必须代表一个完整的连续语义组，而不是单独字幕块。

```json
{
  "id": "B0001",
  "blocks": [214, 215],
  "original_texts": [
    {"block": 214, "time_range": "00:03:10,000 --> 00:03:11,000", "text": "我上车的时候都是有"},
    {"block": 215, "time_range": "00:03:11,000 --> 00:03:12,000", "text": "有一点费劲"}
  ],
  "replacement_texts": [
    {"block": 214, "text": "我上车的时候都是"},
    {"block": 215, "text": "有一点费劲"}
  ],
  "replacement_timecodes": [
    {"block": 214, "time_range": "00:03:10,000 --> 00:03:10,920"},
    {"block": 215, "time_range": "00:03:10,920 --> 00:03:12,000"}
  ],
  "issue_types": ["exact_overlap", "dangling_tail"],
  "requires_audio_timing_review": true,
  "audio_timing_review_status": "resolved",
  "audio_timing_evidence": {
    "source_audio_sha256": "AUDIO_SHA256",
    "clip_range_seconds": [189.0, 193.0],
    "method": "manual_listen+word_timestamps",
    "internal_boundaries": [
      {
        "left_block": 214,
        "right_block": 215,
        "left_end_seconds": 190.92,
        "right_start_seconds": 190.92,
        "confidence": "high",
        "decision_basis": "原音在190.92秒结束“都是”，随后开始“有一点费劲”，切换点位于两者之间。"
      }
    ]
  },
  "status": "confirmed"
}
```

## 硬性约束

- `blocks` 至少包含两个升序连续块号。
- 所有 B 候选彼此不共享字幕块；相邻问题链必须合并为一个更大的 B 组。
- `original_texts` 和 `replacement_texts` 必须完整且仅覆盖全部 `blocks`。
- `replacement_timecodes` 必须完整且仅覆盖全部 `blocks`。
- 一个确认组中的字幕块必须全部写入成功，否则整组不写入。
- 多个确认组先全部验证，再统一写入；任一组失败时不得生成部分输出。
- 所有重新分配文字的 B 组必须设置 `requires_audio_timing_review=true`，且只有 `audio_timing_review_status=resolved`、全部组内边界证据齐全时才允许写入。
- 不改变字幕块数、编号、每块内部行数、换行符或末尾空行结构。未进入 B 组的时间码不变；B 组只允许依据原音调整组内切换点，组最外侧开始和结束时间不变。
- 进入 B 项的块不得再由 D 项独立写入；单块修改必须并入该 B 项。

## 最终 allowlist

只允许保留经人工结合上下文或原音确认的项目。每项必须同时包含机器报告中的精确 `signature` 和非空理由：

```json
[
  {
    "signature": "214-215|exact_overlap|有",
    "reason": "结合原音确认说话者有意重复，且两块分别对应不同镜头节奏"
  },
  {
    "signature": "318|residual_filler|呢",
    "reason": "此处“呢”承担反问语气，用户明确要求保留"
  }
]
```

不得使用“看起来没问题”“先保留”等空泛理由批量绕过最终验收。
