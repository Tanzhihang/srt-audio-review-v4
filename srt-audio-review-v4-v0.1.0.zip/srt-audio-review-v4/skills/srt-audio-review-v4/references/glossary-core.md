# 通用词库

| Correct term | Common wrong forms | Notes |
|---|---|---|
| OpenAI | Open AI, openai | 公司名 |
| ChatGPT | Chat GPT, chatgpt | 产品名 |
| Codex | Code X, codex | 产品名 |
| Transformer | transformer, 变压器模型, Transformer模型 | 通用 AI 架构 |
| 字节跳动 | ByteDance, Bytedance, 字节跳, 字节条动 | 公司名 |
| 豆包 | Doubao, 逗包, 豆包 AI | 字节跳动 AI 智能助手 |
| 豆包大模型 | Doubao大模型, 豆包 大模型, 豆包模型 | 字节跳动大模型 |
| 火山引擎 | Volcengine, Volcano Engine, 火山因擎 | 字节跳动云服务平台 |
| 火山方舟 | Volcengine Ark, Volcano Ark, 火山方州 | 火山引擎大模型服务平台 |
| 扣子 | Coze, coz, 口子, 扣子 AI | AI 智能体开发平台 |
| ByteDance Seed | Bytedance Seed, 字节Seed, 字节跳动Seed | 字节跳动 AI 研究团队 |
| Seed2.0 | Seed 2.0, Seed二点零, Seed 2点0 | ByteDance Seed 模型 |
| Seedance 2.0 | Seedance2.0, Seed Dance 2.0, Seedance二点零 | ByteDance Seed 视频生成模型 |
| Seedream | Seed Dream, Seedream模型, Seedream 图像模型 | ByteDance Seed 图像生成模型 |
| Seedream 2.0 | Seedream2.0, Seed Dream 2.0, Seedream二点零 | ByteDance Seed 图像生成模型 |
| Seed LiveInterpret 2.0 | Seed-LiveInterpret 2.0, Seed Live Interpret 2.0, Seed实时翻译 | ByteDance Seed 语音翻译模型 |
| AI | ai, A I, 诶爱, 埃艾 | 通用 AI 缩写 |
| 人工智能 | 人工知能, 人工质能, 人工智能能 | 通用 AI 术语 |
| 生成式 AI | 生成式AI, Generative AI, 生成式人工智能 | 通用 AI 术语 |
| AIGC | AI GC, A I G C, aigc, AI生成内容 | 通用 AI 术语 |
| AGI | A G I, agi, 通用人工智能 | 通用 AI 术语 |
| 大模型 | 大模形, 大磨型, large model | 通用 AI 术语 |
| 大语言模型 | LLM, L L M, 大语音模型, 大语言模块 | 通用 AI 模型 |
| 多模态大模型 | multimodal large model, 多模态 大模型, 多摸态大模型 | 通用 AI 模型 |
| 推理模型 | reasoning model, 推理大模型, 思考模型 | 通用 AI 模型 |
| AI Agent | AI智能体, AI代理, Agent智能体 | 通用 AI 术语 |
| 智能体 | Agent, 智能代理, 智能提 | 通用 AI 术语 |
| 提示词 | Prompt, prompt, 普朗普特, 提示辞 | 通用 AI 术语 |
| 提示词工程 | Prompt Engineering, prompt engineering, 提示工程 | 通用 AI 术语 |
| 上下文窗口 | Context Window, context window, 上下文长度 | 通用 AI 术语 |
| RAG | Retrieval-Augmented Generation, 检索增强生成, R A G | 通用 AI 架构 |
| 向量数据库 | Vector Database, vector database, 向量库 | 通用 AI 基础设施 |
| 知识库 | Knowledge Base, knowledge base, 知识酷 | 通用 AI 应用 |
| 微调 | fine-tuning, Finetune, fine tune, 模型微调 | 通用 AI 训练术语 |
| 文生图 | text-to-image, T2I, 文字生成图片 | 通用 AI 生成任务 |
| 图生图 | image-to-image, I2I, 图片生成图片 | 通用 AI 生成任务 |
| 文生视频 | text-to-video, T2V, 文字生成视频 | 通用 AI 生成任务 |
| 图生视频 | image-to-video, I2V, 图片生成视频 | 通用 AI 生成任务 |
