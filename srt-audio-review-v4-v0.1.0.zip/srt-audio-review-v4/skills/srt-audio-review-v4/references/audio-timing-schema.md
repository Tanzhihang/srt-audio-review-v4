# V4 重新断句后的音频时间定位

所有实际重新分配文字的 B 组都必须试听原音，并为组内每一个字幕切换点确定最终时间位置。纯文字负责决定语义如何切分；音频负责决定切分后的文字应在什么时候出现、属于哪一条字幕。

```json
{
  "id": "B0001",
  "blocks": [2, 3],
  "original_texts": [
    {
      "block": 2,
      "time_range": "00:00:03,333 --> 00:00:04,566",
      "text": "一期视频告诉你这个原"
    },
    {
      "block": 3,
      "time_range": "00:00:04,566 --> 00:00:06,100",
      "text": "厂升顶帐篷到底怎么使用"
    }
  ],
  "replacement_texts": [
    {"block": 2, "text": "一期视频告诉你"},
    {"block": 3, "text": "这个原厂升顶帐篷到底怎么使用"}
  ],
  "replacement_timecodes": [
    {"block": 2, "time_range": "00:00:03,333 --> 00:00:04,350"},
    {"block": 3, "time_range": "00:00:04,350 --> 00:00:06,100"}
  ],
  "requires_audio_timing_review": true,
  "audio_timing_review_status": "resolved",
  "audio_timing_evidence": {
    "source_audio_sha256": "AUDIO_SHA256",
    "clip_range_seconds": [2.333, 7.100],
    "method": "local_whisper_word_timestamps+manual_listen",
    "internal_boundaries": [
      {
        "left_block": 2,
        "right_block": 3,
        "left_end_seconds": 4.350,
        "right_start_seconds": 4.350,
        "confidence": "high",
        "decision_basis": "原音在4.35秒结束“告诉你”，随后开始完整词“这个原厂”，切换点放在两者之间。"
      }
    ]
  },
  "status": "confirmed"
}
```

## 硬约束

- 任何 `replacement_texts` 与 `original_texts` 不同的 B 组，都必须设置 `requires_audio_timing_review=true`。
- 必须先对完整音频运行一次本地 Whisper 转写并保存逐词时间戳；所有 B 组复用同一份结果，不得逐组调用网络服务。
- 音频证据范围必须覆盖整个 B 组，并保留前后语境；只有本地逐词结果缺字、重叠或切点不明确时才截取片段人工试听。
- 每个组内相邻字幕边界都必须有一条 `internal_boundaries` 记录；不能只听该组的一部分。
- 高匹配率且切点明确时，允许本地逐词时间戳直接作为最终定位证据；转写缺词、多人重叠或切点过近时必须补听本地片段。
- `transcribe_local_whisper.py` 输出的词时间戳均为原音频绝对秒数，可直接填写组内边界；不得再次叠加片段起点。
- 禁止使用 4o、OpenAI、OpenRouter 或其他外部语音转写 API，禁止上传源音频或截取片段。
- 完整词、固定术语和不可分句法成分不得跨字幕边界。如果原切点落在词中，应把切点移动到该词之前或之后的真实语音边界。
- `replacement_timecodes` 必须完整覆盖 B 组所有字幕块。
- B 组最外侧的开始和结束时间保持不变；只允许调整组内切换点，因此不会影响相邻未修改字幕。
- 新时间码必须递增、不得重叠，每条字幕默认至少显示 300 毫秒。
- 如果原音中没有可用的精确切点，允许在语义完整与同步之间选择最接近的静音或音节边界，但必须把判断依据和 `confidence=medium` 写入证据；不得猜测后标为 high。
- 写入必须使用 `apply_confirmed_timed_group_edits.py`，交付前必须通过 `validate_audio_timing_alignment.py`。
