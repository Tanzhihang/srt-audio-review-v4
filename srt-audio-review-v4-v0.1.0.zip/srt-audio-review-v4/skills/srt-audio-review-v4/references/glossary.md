# SRT 校稿词库入口

这是词库入口文件。实际词条已经拆分到下面几个文件，校稿时按主题读取，减少误改和上下文消耗。

## 必读文件

- `references/glossary-custom.md`：用户临时新增或最高优先级词条。
- `references/do-not-auto-replace.md`：禁止因为词库而自动替换的常用词。

## 按主题读取

- `references/glossary-core.md`：通用词、基础产品名。
- `references/glossary-phone.md`：手机、数码、操作系统、消费电子产品名。
- `references/glossary-auto.md`：汽车、车型、智能座舱、辅助驾驶相关词。

## 添加新词

日常新增词优先写到 `glossary-custom.md`。如果已经明确属于手机或汽车领域，再整理到对应主题文件。

第二列 `Common wrong forms` 只写明确错写、误识别或带上下文的错误表达，不要写可独立成立的常用词。
