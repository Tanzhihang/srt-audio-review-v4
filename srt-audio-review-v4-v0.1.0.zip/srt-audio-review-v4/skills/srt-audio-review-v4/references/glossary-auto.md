# 汽车与辅助驾驶词库

| Correct term | Common wrong forms | Notes |
|---|---|---|
| HUAWEI HiCar | Hi Car, hicar, 华为车机 | 华为车载互联 |
| 鸿蒙智行 | 鸿蒙智驾, 鸿蒙智联, HIMA | 华为智能汽车生态联盟 |
| HIMA | Harmony Intelligent Mobility Alliance, 鸿蒙智行联盟 | 鸿蒙智行英文简称 |
| 问界 | 文界, 问届, AITO | 鸿蒙智行品牌 |
| 问界 新M5 Ultra | 问界M5 Ultra, 问界新M5, 问界 M5 Ultra | 鸿蒙智行车型 |
| 问界 M6 | 问界M6, 问界M六, AITO M6 | 鸿蒙智行车型 |
| 问界 M7 | 问界M7, 问界M七, AITO M7 | 鸿蒙智行车型 |
| 问界 M8 | 问界M8, 问界M八, AITO M8 | 鸿蒙智行车型 |
| 问界 M9 | 问界M9, 问界M九, AITO M9 | 鸿蒙智行车型 |
| 问界 M9 Ultimate | 问界M9 Ultimate, 问界 M9终极版, 问界M9旗舰版 | 鸿蒙智行车型 |
| 智界 | 智届, 质界, Luxeed | 鸿蒙智行品牌 |
| 智界 新S7 | 智界S7, 智界 S7, Luxeed S7 | 鸿蒙智行车型 |
| 智界 R7 | 智界R7, 智界R七, Luxeed R7 | 鸿蒙智行车型 |
| 智界 V9 | 智界V9, 智界V九, Luxeed V9 | 鸿蒙智行车型 |
| 享界 | 想界, 享届, Stelato | 鸿蒙智行品牌 |
| 享界 S9 | 享界S9, 享界S九, Stelato S9 | 鸿蒙智行车型 |
| 享界 S9T | 享界S9T, 享界 S9 T, 享界旅行版 | 鸿蒙智行车型 |
| 尊界 | 尊届, 尊介, Maextro | 鸿蒙智行品牌 |
| 尊界 S800 | 尊界S800, 尊界S八百, Maextro S800 | 鸿蒙智行车型 |
| 尊界 S800 Grand Design 典藏大观 | 尊界S800 Grand Design, 尊界S800典藏大观, 尊界典藏大观 | 鸿蒙智行车型 |
| 尚界 | 上界, 尚届 | 鸿蒙智行品牌 |
| 尚界 H5 | 尚界H5, 尚界H五 | 鸿蒙智行车型 |
| 尚界 Z7 | 尚界Z7, 尚界Z七 | 鸿蒙智行车型 |
| 尚界 Z7T | 尚界Z7T, 尚界 Z7 T, 尚界猎装 | 鸿蒙智行车型 |
| 华为乾崑 | 华为乾坤, 乾坤, 乾崑 | 华为智能汽车解决方案品牌 |
| 华为乾崑智驾 | 华为乾坤智驾, 乾坤智驾, 乾崑智驾 | 华为智能驾驶 |
| 华为乾崑智驾 ADS 4 | ADS4, ADS 4, 乾崑智驾ADS4 | 华为智能驾驶 |
| 华为乾崑智驾 ADS 5 | ADS5, ADS 5, 乾崑智驾ADS5 | 华为智能驾驶 |
| HUAWEI ADS | Huawei ADS, 华为ADS, ADS | 华为辅助驾驶系统 |
| 鸿蒙座舱 | 鸿蒙坐舱, HarmonySpace, Harmony Space | 华为智能座舱 |
| HarmonySpace | Harmony Space, 鸿蒙座舱, HarmonyOS Cockpit | 华为智能座舱 |
| 乾崑车控 | 乾坤车控, 乾崑车空 | 华为汽车解决方案 |
| 乾崑车载光 | 乾坤车载光, 乾崑车灯 | 华为汽车解决方案 |
| 乾崑车云 | 乾坤车云, 乾崑车云服务 | 华为汽车解决方案 |
| 华为乾崑 APP | 乾崑APP, 乾坤APP, 华为乾坤 App | 华为汽车应用 |
| 华为途灵平台 | 途灵平台, 图灵平台, 途铃平台 | 华为车控平台 |
| HUAWEI XMC 数字底盘引擎 | XMC数字底盘, 华为XMC, XMC 底盘 | 华为车控技术 |
| 华为“巨鲸”电池 | 巨鲸电池, 华为巨鲸电池 | 华为汽车技术 |
| 雪鸮智能增程系统 | 雪枭智能增程, 雪鸮增程系统 | 华为汽车技术 |
| 鸿蒙 ALPS 健康座舱 | ALPS健康座舱, 鸿蒙阿尔卑斯健康座舱 | 华为汽车技术 |
| Xiaomi SU7 | 小米SU7, 小米 SU 七, 小米汽车SU7 | Xiaomi 汽车 |
| Xiaomi YU7 | 小米YU7, 小米 YU 七, 小米汽车YU7 | Xiaomi 汽车 |
| 理想汽车 | Li Auto, Lixiang | 车企品牌 |
| 理想 L6 | 理想L6, 理想L六, Li Auto L6 | 理想车型 |
| 理想 L7 | 理想L7, 理想L七, Li Auto L7 | 理想车型 |
| 理想 L8 | 理想L8, 理想L八, Li Auto L8 | 理想车型 |
| 理想 L9 | 理想L9, 理想L九, Li Auto L9 | 理想车型 |
| 理想 MEGA | 理想Mega, 理想mega, Li Auto MEGA | 理想车型 |
| 理想 i6 | 理想i6, 理想 I6, Li Auto i6 | 理想车型 |
| 理想 i8 | 理想i8, 理想 I8, Li Auto i8 | 理想车型 |
| 理想 AD Max | 理想AD Max, 理想智驾Max, Li Auto AD Max | 理想辅助驾驶 |
| 理想 AD Pro | 理想AD Pro, 理想智驾Pro, Li Auto AD Pro | 理想辅助驾驶 |
| 理想同学 | 理想同学, Lixiang Tongxue, 理想语音助手 | 理想车机助手 |
| 蔚来 | NIO, nio, 未來 | 车企品牌 |
| 蔚来 ET9 | NIO ET9, ET9, 蔚来ET九 | 蔚来车型 |
| 蔚来 ET7 | NIO ET7, ET7, 蔚来ET七 | 蔚来车型 |
| 蔚来 ET5 | NIO ET5, ET5, 蔚来ET五 | 蔚来车型 |
| 蔚来 ET5T | NIO ET5T, ET5 T, 蔚来ET5旅行版 | 蔚来车型 |
| 蔚来 ES8 | NIO ES8, ES8, 蔚来ES八 | 蔚来车型 |
| 蔚来 ES7 | NIO ES7, ES7, 蔚来ES七 | 蔚来车型 |
| 蔚来 ES6 | NIO ES6, ES6, 蔚来ES六 | 蔚来车型 |
| 蔚来 EC7 | NIO EC7, EC7, 蔚来EC七 | 蔚来车型 |
| 蔚来 EC6 | NIO EC6, EC6, 蔚来EC六 | 蔚来车型 |
| 乐道 L60 | ONVO L60, 乐道L60, 乐道L六十 | 蔚来子品牌车型 |
| firefly 萤火虫 | Firefly, 萤火虫, 蔚来萤火虫 | 蔚来子品牌 |
| NIO Pilot | NIOPilot, 蔚来Pilot, 蔚来辅助驾驶 | 蔚来辅助驾驶 |
| NAD | NIO Autonomous Driving, 蔚来NAD, 蔚来自动驾驶 | 蔚来辅助驾驶 |
| NOP | Navigate on Pilot, 蔚来NOP, 领航辅助 | 蔚来辅助驾驶 |
| NOP+ | NOP Plus, 蔚来NOP+, 蔚来NOP加 | 蔚来辅助驾驶 |
| Aquila 蔚来超感系统 | Aquila, 蔚来Aquila, 蔚来超感 | 蔚来感知系统 |
| Adam 蔚来超算平台 | 蔚来Adam, 蔚来超算 | 蔚来计算平台 |
| Banyan | 蔚来Banyan, Banyan系统, 榕树系统 | 蔚来智能系统 |
| NOMI | Nomi, nomi, 蔚来NOMI | 蔚来车机助手 |
| Tesla | tesla, 特司拉 | 车企品牌 |
| Model S | Tesla Model S, ModelS, 特斯拉Model S | Tesla 车型 |
| Model 3 | Tesla Model 3, Model3, 特斯拉Model 3 | Tesla 车型 |
| Model X | Tesla Model X, ModelX, 特斯拉Model X | Tesla 车型 |
| Model Y | Tesla Model Y, ModelY, 特斯拉Model Y | Tesla 车型 |
| Cybertruck | Cyber Truck, 赛博皮卡, 特斯拉皮卡 | Tesla 车型 |
| Roadster | Tesla Roadster, 特斯拉Roadster, 跑车版特斯拉 | Tesla 车型 |
| Tesla Semi | Semi, 特斯拉Semi, 特斯拉卡车 | Tesla 车型 |
| Cybercab | Cyber Cab, 赛博出租车, 特斯拉Robotaxi | Tesla 车型 |
| Autopilot | Auto Pilot, 特斯拉Autopilot | Tesla 辅助驾驶 |
| Enhanced Autopilot | EAP, 增强版Autopilot, 增强自动辅助驾驶 | Tesla 辅助驾驶 |
| Full Self-Driving | FSD, 特斯拉FSD | Tesla 辅助驾驶 |
| Tesla Vision | 特斯拉Vision, Tesla视觉, 纯视觉方案 | Tesla 感知系统 |
| Hardware 4 | HW4, 特斯拉HW4, 硬件4 | Tesla 硬件 |
| Robotaxi | RoboTaxi, 特斯拉Robotaxi | 自动驾驶出行 |
| 零跑汽车 | 零跑, Leapmotor, Leap Motor | 车企品牌 |
| 零跑 B01 | 零跑B01, Leapmotor B01, B零一 | 零跑车型 |
| 零跑 B10 | 零跑B10, Leapmotor B10, B十 | 零跑车型 |
| 零跑 C01 | 零跑C01, Leapmotor C01, C零一 | 零跑车型 |
| 零跑 C10 | 零跑C10, Leapmotor C10, C十 | 零跑车型 |
| 零跑 C11 | 零跑C11, Leapmotor C11, C十一 | 零跑车型 |
| 零跑 C16 | 零跑C16, Leapmotor C16, C十六 | 零跑车型 |
| 零跑 T03 | 零跑T03, Leapmotor T03, T零三 | 零跑车型 |
| Leapmotor Pilot | 零跑Pilot, 零跑智能驾驶, 零跑辅助驾驶 | 零跑辅助驾驶 |
| 零跑领航辅助 | 零跑领航, 零跑NOA, Leapmotor NOA | 零跑辅助驾驶 |
| 智己汽车 | 智己, IM Motors, IM智己 | 车企品牌 |
| 智己 L7 | 智己L7, IM L7, L七 | 智己车型 |
| 智己 L6 | 智己L6, IM L6, L六 | 智己车型 |
| 智己 LS7 | 智己LS7, IM LS7, LS七 | 智己车型 |
| 智己 LS6 | 智己LS6, IM LS6, LS六 | 智己车型 |
| 智己 LS9 | 智己LS9, IM LS9, LS九 | 智己车型 |
| IM AD | 智己IM AD, 智己智驾, IMAD | 智己辅助驾驶 |
| IM AD Max | 智己IM AD Max, IMAD Max, 智己智驾Max | 智己辅助驾驶 |
| IMOS | IM OS, 智己IMOS, 智己车机系统 | 智己车机系统 |
| 灵蜥数字底盘 | 灵犀数字底盘, 智己数字底盘, 蜥蜴数字底盘 | 智己底盘技术 |
| 小米汽车 | Xiaomi EV, 小米EV, 小米 Auto | 车企品牌 |
| 新一代 Xiaomi SU7 | 新一代小米SU7, 小米SU7新一代, New Xiaomi SU7 | Xiaomi 汽车 |
| Xiaomi SU7 Ultra | 小米SU7 Ultra, 小米SU7ultra, 小米SU7性能版 | Xiaomi 汽车 |
| Xiaomi SU7 Ultra Prototype | 小米SU7 Ultra原型车, SU7 Ultra Prototype, 小米原型车 | Xiaomi 汽车 |
| Xiaomi YU7 GT | 小米YU7 GT, YU7 GT, 小米YU七GT | Xiaomi 汽车 |
| Xiaomi Pilot | 小米Pilot, 小米智能驾驶, 小米智驾 | Xiaomi 辅助驾驶 |
| Xiaomi HAD | 小米HAD, 小米高阶智能驾驶, Xiaomi Hyper Autonomous Driving | Xiaomi 辅助驾驶 |
| 小米端到端辅助驾驶 | 小米端到端智驾, 小米E2E, Xiaomi E2E | Xiaomi 辅助驾驶 |
| 小米澎湃智能座舱 | 澎湃智能座舱, Xiaomi HyperOS座舱, 小米车机 | Xiaomi 智能座舱 |
| 长城汽车 | GWM, Great Wall Motor | 车企品牌 |
| 哈弗 | Haval, 哈弗汽车 | 长城汽车品牌 |
| 哈弗 H6 | 哈弗H6, Haval H6, 哈弗H六 | 长城车型 |
| 哈弗猛龙 | Haval Raptor, 哈弗猛龍 | 长城车型 |
| 哈弗大狗 | Haval Big Dog, 哈弗Big Dog | 长城车型 |
| 哈弗二代大狗 | 二代大狗, Haval Second Generation Big Dog, 哈弗2代大狗 | 长城车型 |
| 魏牌 | WEY, 魏, 魏派 | 长城汽车品牌 |
| 魏牌蓝山 | WEY Lanshan, 魏牌蓝山DHT | 长城车型 |
| 魏牌高山 | WEY Gaoshan, 魏牌MPV | 长城车型 |
| 魏牌摩卡 | WEY Mocha, 魏牌Mocha | 长城车型 |
| 坦克 | TANK, Tank, 坦克汽车 | 长城汽车品牌 |
| 坦克 300 | 坦克300, Tank 300, 坦克三百 | 长城车型 |
| 坦克 400 Hi4-T | 坦克400 Hi4-T, Tank 400, 坦克四百 | 长城车型 |
| 坦克 500 Hi4-T | 坦克500 Hi4-T, Tank 500, 坦克五百 | 长城车型 |
| 坦克 700 Hi4-T | 坦克700 Hi4-T, Tank 700, 坦克七百 | 长城车型 |
| 欧拉 | ORA, 欧拉汽车, Ora | 长城汽车品牌 |
| 欧拉好猫 | ORA Good Cat, 欧拉Good Cat | 长城车型 |
| 欧拉闪电猫 | ORA Lightning Cat, 欧拉Lightning Cat | 长城车型 |
| 欧拉芭蕾猫 | ORA Ballet Cat, 欧拉Ballet Cat | 长城车型 |
| 长城炮 | GWM POER, 长城皮卡, 炮皮卡 | 长城车型 |
| 山海炮 | 山海炮皮卡, GWM Shanhai Cannon, 山海 Cannon | 长城车型 |
| Coffee Pilot | 咖啡Pilot, Coffee智能驾驶, 长城咖啡智驾 | 长城辅助驾驶 |
| Coffee OS | 咖啡OS, CoffeeOS, 长城车机系统 | 长城车机系统 |
| NOH | Navigation on Highwaypilot, 高速领航辅助, 长城NOH | 长城辅助驾驶 |
| 阿维塔 | AVATR, Avatr, 阿维塔汽车 | 车企品牌 |
| 阿维塔 06 | 阿维塔06, AVATR 06, 阿维塔零六 | 阿维塔车型 |
| 阿维塔 07 | 阿维塔07, AVATR 07, 阿维塔零七 | 阿维塔车型 |
| 阿维塔 11 | 阿维塔11, AVATR 11, 阿维塔十一 | 阿维塔车型 |
| 阿维塔 12 | 阿维塔12, AVATR 12, 阿维塔十二 | 阿维塔车型 |
| 阿维塔 012 | 阿维塔012, AVATR 012, 阿维塔零一二 | 阿维塔车型 |
| AVATR.OS | AVATR OS, 阿维塔OS, 阿维塔车机系统 | 阿维塔车机系统 |
| CHN 平台 | CHN平台, 长安华为宁德时代平台, CHN架构 | 阿维塔平台 |
| 阿维塔昆仑增程 | 昆仑增程, 阿维塔增程, Kunlun增程 | 阿维塔技术 |
| 阿维塔智驾 | 阿维塔智能驾驶, 阿维塔辅助驾驶, 阿维塔ADS | 阿维塔辅助驾驶 |
| 极氪 | ZEEKR, Zeekr, 极客汽车 | 车企品牌 |
| 极氪 001 | 极氪001, ZEEKR 001, 极氪零零一 | 极氪车型 |
| 极氪 001 FR | 极氪001 FR, ZEEKR 001 FR, 极氪FR | 极氪车型 |
| 极氪 007 | 极氪007, ZEEKR 007, 极氪零零七 | 极氪车型 |
| 极氪 009 | 极氪009, ZEEKR 009, 极氪零零九 | 极氪车型 |
| 极氪 009 光辉 | 极氪009光辉, ZEEKR 009 Grand, 极氪光辉 | 极氪车型 |
| 极氪 7X | 极氪7X, ZEEKR 7X, 极氪七X | 极氪车型 |
| 极氪 X | 极氪X, ZEEKR X, 极氪小车 | 极氪车型 |
| 极氪 MIX | 极氪MIX, ZEEKR MIX, 极氪Mix | 极氪车型 |
| ZEEKR AD | 极氪AD, Zeekr AD, 极氪智驾 | 极氪辅助驾驶 |
| 浩瀚智驾 | 极氪浩瀚智驾, Haohan智驾, 浩瀚智能驾驶 | 极氪辅助驾驶 |
| NZP | Navigation ZEEKR Pilot, 极氪NZP, 高速自主领航 | 极氪辅助驾驶 |
| ZEEKR OS | 极氪OS, Zeekr OS, 极氪车机系统 | 极氪车机系统 |
| 辅助驾驶 | 驾驶辅助, 辅住驾驶, 辅驾 | 通用智能汽车术语 |
| 智能驾驶 | 智驾, 智能驾使 | 通用智能汽车术语 |
| 高阶智能驾驶 | 高阶智驾, 高级智能驾驶, 高阶自动驾驶 | 通用智能汽车术语 |
| 城市 NOA | 城市NOA, 城区NOA, 城市领航辅助 | 通用辅助驾驶 |
| 高速 NOA | 高速NOA, 高速领航辅助, 高速导航辅助 | 通用辅助驾驶 |
| 领航辅助 | 领航驾驶, 导航辅助驾驶, Navigate on Pilot | 通用辅助驾驶 |
| 记忆泊车 | 记忆停车, 记忆泊入, HPA | 通用辅助驾驶 |
| 自动泊车 | 自动停车, 泊车辅助, APA | 通用辅助驾驶 |
| 遥控泊车 | 远程泊车, 手机泊车, RPA | 通用辅助驾驶 |
| 代客泊车 | 代客停车, AVP, 自动代客泊车 | 通用辅助驾驶 |
| 智能召唤 | Smart Summon, 车辆召唤 | 通用辅助驾驶 |
| 哨兵模式 | Sentinel Mode, 守卫模式, 哨兵功能 | 通用汽车功能 |
| 激光雷达 | LiDAR, lidar, 激光雷达器 | 通用感知硬件 |
| 毫米波雷达 | 毫米波, 毫米雷达, millimeter-wave radar | 通用感知硬件 |
| 超声波雷达 | 超声波传感器, USS, 超声雷达 | 通用感知硬件 |
| 视觉感知 | 视觉识别, 视角感知, 感知视觉 | 通用感知术语 |
| 纯视觉方案 | 纯视觉, Vision-only, 视觉方案 | 通用感知方案 |
| BEV 感知 | BEV, 鸟瞰图感知, Bird's Eye View | 通用感知算法 |
| Occupancy Network | 占用网络, Occupancy, 占据网络 | 通用感知算法 |
| 端到端 | E2E, end-to-end, 端端到 | 通用智驾算法 |
| 世界模型 | World Model, world model, 世界模式 | 通用智驾算法 |
| VLA | Vision-Language-Action, 视觉语言动作模型, VLA模型 | 通用智能驾驶模型 |
| VLM | Vision-Language Model, 视觉语言模型, VLM模型 | 通用多模态模型 |
| 基座模型 | foundation model, Foundation Model, 基础模型 | 通用 AI 模型 |
| OTA | Over-the-air, 空中升级, 在线升级 | 通用汽车软件 |
| AEB | 自动紧急制动, 自动刹车, Autonomous Emergency Braking | 通用主动安全 |
| ACC | 自适应巡航, Adaptive Cruise Control, 自动巡航 | 通用辅助驾驶 |
| LCC | 车道居中辅助, Lane Centering Control, 车道居中 | 通用辅助驾驶 |
| LKA | 车道保持辅助, Lane Keeping Assist, 车道保持 | 通用辅助驾驶 |
| LDW | 车道偏离预警, Lane Departure Warning, 偏离预警 | 通用主动安全 |
| HWA | 高速辅助驾驶, Highway Assist, 高速辅助 | 通用辅助驾驶 |
| TJA | 交通拥堵辅助, Traffic Jam Assist, 拥堵辅助 | 通用辅助驾驶 |
| BSD | 盲区监测, Blind Spot Detection, 盲点监测 | 通用主动安全 |
| DOW | 开门预警, Door Open Warning, 开门提醒 | 通用主动安全 |
| RCTA | 后方横向来车预警, Rear Cross Traffic Alert, 后方穿行预警 | 通用主动安全 |
| FCW | 前向碰撞预警, Forward Collision Warning, 前碰撞预警 | 通用主动安全 |
| ELK | 紧急车道保持, Emergency Lane Keeping, 紧急车道辅助 | 通用主动安全 |
| IPA | 智能泊车辅助, Intelligent Parking Assist, 泊车辅助 | 通用辅助驾驶 |
| NCA | 城市领航辅助, Navigation Cruise Assist, 导航巡航辅助 | 通用辅助驾驶 |
| NGP | Navigation Guided Pilot, 导航辅助驾驶, 智能导航辅助驾驶 | 通用辅助驾驶 |
| NOA | Navigate on Autopilot, 领航辅助, 导航辅助驾驶 | 通用辅助驾驶 |
| 高精地图 | HD Map, 高清地图, 高精度地图 | 通用地图术语 |
| 无图智驾 | 无高精地图智驾, Mapless, 无图NOA | 通用辅助驾驶 |
| 车路云一体化 | 车路云, V2X, 车路协同 | 通用智能交通 |
| C-V2X | V2X, 车联网, 蜂窝车联网 | 通用车联网 |
| 智能座舱 | 智慧座舱, 智能坐舱, 车机座舱 | 通用智能汽车术语 |
| 数字底盘 | 智能底盘, 数字化底盘, 底盘控制 | 通用汽车技术 |
| 线控底盘 | 线控转向, 线控制动, drive-by-wire | 通用汽车技术 |
| 空气悬架 | 空悬, 空气悬挂, air suspension | 通用汽车技术 |
| CDC 连续可变阻尼减振器 | CDC减振器, CDC悬架, 连续可变阻尼 | 通用汽车技术 |
| 增程式电动汽车 | 增程车, 增程式, REEV | 通用新能源车术语 |
| 纯电动汽车 | 纯电车, BEV车型, Battery Electric Vehicle | 通用新能源车术语 |
| 插电式混合动力汽车 | 插混, PHEV, 插电混动 | 通用新能源车术语 |
| 超充 | 超级快充, 超级充电, Supercharger | 通用充电术语 |
| 800V 高压平台 | 800V平台, 八百伏平台, 高压快充平台 | 通用电驱术语 |
