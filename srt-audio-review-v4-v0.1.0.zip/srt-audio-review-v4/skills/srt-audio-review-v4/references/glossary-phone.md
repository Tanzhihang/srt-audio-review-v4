# 手机与消费电子词库

| Correct term | Common wrong forms | Notes |
|---|---|---|
| HUAWEI | Huawei, huawei, 华伟, 华维 | 品牌名 |
| HarmonyOS | Harmony OS, 鸿蒙OS, 鸿蒙 OS | 华为操作系统 |
| HarmonyOS NEXT | Harmony OS NEXT, 鸿蒙 NEXT, 鸿蒙next | 华为操作系统 |
| HUAWEI Mate | 华为mate, Mate系列, mate系列 | 华为手机系列 |
| HUAWEI Mate 70 | 华为mate70, Mate七十, Mate70 | 华为手机 |
| HUAWEI Mate 70 Pro | 华为mate70pro, Mate70 Pro, Mate七十Pro | 华为手机 |
| HUAWEI Mate 70 Pro+ | 华为mate70pro+, Mate70 Pro Plus, Mate70 Pro加 | 华为手机 |
| HUAWEI Mate 70 RS 非凡大师 | Mate70 RS, Mate70 非凡大师, Mate70RS | 华为手机 |
| HUAWEI Mate 70 Pro 优享版 | Mate70 Pro优享版, Mate70优享版, 华为Mate70 Pro优享版 | 华为手机 |
| HUAWEI Mate 70 Air | Mate70 Air, 华为Mate70Air, Mate七十Air | 华为手机 |
| HUAWEI Mate 80 | Mate80, 华为Mate80, Mate八十 | 华为手机 |
| HUAWEI Mate 80 Pro | Mate80 Pro, 华为Mate80Pro, Mate八十Pro | 华为手机 |
| HUAWEI Mate 80 Pro Max | Mate80 Pro Max, 华为Mate80ProMax, Mate八十Pro Max | 华为手机 |
| HUAWEI Mate 80 Pro Max 风驰版 | Mate80 Pro Max风驰版, 华为Mate80风驰版, Mate八十风驰版 | 华为手机 |
| HUAWEI Mate 80 RS 非凡大师 | Mate80 RS, Mate80非凡大师, 华为Mate80 RS | 华为手机 |
| HUAWEI Mate XT 非凡大师 | Mate XT, Mate X T | 华为折叠屏手机 |
| HUAWEI Mate XTs 非凡大师 | Mate XTs, Mate XTs非凡大师, 华为三折叠XTs | 华为折叠屏手机 |
| HUAWEI Mate X | MateX, Mate X系列 | 华为折叠屏手机系列 |
| HUAWEI Mate X6 | MateX6, Mate X 六, 华为MateX6 | 华为折叠屏手机 |
| HUAWEI Mate X7 | MateX7, Mate X 七, 华为MateX7 | 华为折叠屏手机 |
| HUAWEI Pura | Pura, pura, 普拉, p系列 | 华为手机系列，原 P 系列 |
| HUAWEI Pura X | PuraX, 普拉X, 华为PuraX | 华为手机 |
| HUAWEI Pura 90 Pro Max | Pura90 Pro Max, Pura九十Pro Max, 普拉90 Pro Max | 华为手机 |
| HUAWEI Pura 90 Pro | Pura90 Pro, Pura九十Pro, 普拉90 Pro | 华为手机 |
| HUAWEI Pura 90 | Pura90, Pura九十, 普拉90 | 华为手机 |
| HUAWEI Pura X Max | Pura X Max, PuraX Max, 普拉X Max | 华为手机 |
| HUAWEI Pura 80 | Pura80, 普拉80, 华为Pura80 | 华为手机 |
| HUAWEI Pura 80 Pro | Pura80 Pro, 普拉80 Pro | 华为手机 |
| HUAWEI Pura 80 Pro+ | Pura80 Pro+, Pura80 Pro Plus, 普拉80 Pro加 | 华为手机 |
| HUAWEI Pura 80 Ultra | Pura80 Ultra, 普拉80 Ultra, Pura 80ultra | 华为手机 |
| HUAWEI nova | nova, 诺瓦, nova系列 | 华为手机系列 |
| HUAWEI nova 13 | nova13, 诺瓦13, 华为nova13 | 华为手机 |
| HUAWEI nova 13 Pro | nova13 Pro, 诺瓦13Pro, 华为nova13pro | 华为手机 |
| HUAWEI nova 14 | nova14, 诺瓦14, 华为nova14 | 华为手机 |
| HUAWEI nova 14 Pro | nova14 Pro, 诺瓦14Pro, 华为nova14pro | 华为手机 |
| HUAWEI nova 14 Ultra | nova14 Ultra, 诺瓦14Ultra, 华为nova14ultra | 华为手机 |
| HUAWEI nova 14 活力版 | nova14活力版, 诺瓦14活力版, 华为nova14青春版 | 华为手机 |
| HUAWEI nova 15 | nova15, 诺瓦15, 华为nova15 | 华为手机 |
| HUAWEI nova 15 Pro | nova15 Pro, 诺瓦15Pro, 华为nova15pro | 华为手机 |
| HUAWEI nova 15 Ultra | nova15 Ultra, 诺瓦15Ultra, 华为nova15ultra | 华为手机 |
| HUAWEI nova 16 | nova16, 诺瓦16, 华为nova16 | 华为手机 |
| HUAWEI nova 16 Pro | nova16 Pro, 诺瓦16Pro, 华为nova16pro | 华为手机 |
| HUAWEI nova 16 Ultra | nova16 Ultra, 诺瓦16Ultra, 华为nova16ultra | 华为手机 |
| HUAWEI nova 16z | nova16z, 诺瓦16z, 华为nova16 z | 华为手机 |
| HUAWEI nova Flip | novaFlip, nova Flip折叠, 华为nova小折叠 | 华为折叠屏手机 |
| HUAWEI nova Flip S | novaFlip S, nova FlipS, 华为nova Flip S | 华为折叠屏手机 |
| HUAWEI Pocket | Pocket, pocket | 华为折叠屏手机系列 |
| HUAWEI Pocket 2 | Pocket2, pocket 2, 华为Pocket二 | 华为折叠屏手机 |
| HUAWEI Pocket 2 优享版 | Pocket2优享版, 华为Pocket2优享版, Pocket二优享版 | 华为折叠屏手机 |
| HUAWEI 畅享 | 华为畅想, 畅享系列, Changxiang | 华为手机系列 |
| 华为畅享 70S | 畅享70S, 华为畅想70S, 畅享七十S | 华为手机 |
| 华为畅享 70X | 畅享70X, 华为畅想70X, 畅享七十X | 华为手机 |
| 华为畅享 70X 活力版 | 畅享70X活力版, 华为畅想70X活力版, 畅享七十X活力版 | 华为手机 |
| 华为畅享 70X 尊享版 | 畅享70X尊享版, 华为畅想70X尊享版, 畅享七十X尊享版 | 华为手机 |
| 华为畅享 80 | 畅享80, 华为畅想80, 畅享八十 | 华为手机 |
| 华为畅享 90 | 畅享90, 华为畅想90, 畅享九十 | 华为手机 |
| 华为畅享 90 Plus | 畅享90 Plus, 华为畅想90 Plus, 畅享九十Plus | 华为手机 |
| 华为畅享 90 Pro Max | 畅享90 Pro Max, 华为畅想90 Pro Max, 畅享九十Pro Max | 华为手机 |
| 华为畅享 90m Plus | 畅享90m Plus, 华为畅想90m Plus, 畅享九十m Plus | 华为手机 |
| Apple | apple, 苹果公司 | 品牌名 |
| iPhone | iphone, IPhone | Apple 手机 |
| iPhone 17 Pro | iPhone17 Pro, iPhone十七Pro, 苹果17 Pro | Apple 手机 |
| iPhone Air | iPhoneAir, iPhone AIR, 苹果Air | Apple 手机 |
| iPhone 17 | iPhone17, iPhone十七, 苹果17 | Apple 手机 |
| iPhone 17e | iPhone17e, iPhone 17 E, 苹果17e | Apple 手机 |
| iPhone 16 | iPhone16, iPhone十六, 苹果16 | Apple 手机 |
| Mac | MAC | Apple 电脑 |
| MacBook Neo | MacBookNeo, Macbook Neo, Mac Book Neo | Apple 笔记本 |
| MacBook Air | Macbook Air, Mac Book Air, 苹果Air本 | Apple 笔记本 |
| MacBook Pro | Macbook Pro, Mac Book Pro, 苹果Pro本 | Apple 笔记本 |
| iMac | IMac, i mac, 苹果一体机 | Apple 台式电脑 |
| Mac mini | MacMini, Mac Mini, mac迷你 | Apple 台式电脑 |
| Mac Studio | MacStudio, Mac studio, 苹果工作站 | Apple 台式电脑 |
| Studio Display | studio display, Studio屏, 苹果显示器 | Apple 显示器 |
| Pro Display XDR | ProDisplay XDR, XDR显示器, 苹果XDR显示器 | Apple 显示器 |
| Studio Display XDR | StudioDisplay XDR, Studio DisplayXDR, 苹果XDR显示器 | Apple 显示器 |
| iPad | ipad, IPad | Apple 平板 |
| iPad Pro | iPadPro, ipad pro, 苹果平板Pro | Apple 平板 |
| iPad Air | iPadAir, ipad air, 苹果平板Air | Apple 平板 |
| iPad mini | iPadmini, ipad mini, 苹果小平板 | Apple 平板 |
| Apple Pencil | apple pencil, 苹果笔, Apple笔 | Apple 配件 |
| Magic Keyboard | magic keyboard, 妙控键盘, 苹果键盘 | Apple 配件 |
| Apple Watch | apple watch, iWatch | Apple 手表 |
| Apple Watch Series 11 | Apple Watch 11, Series11, 苹果手表11 | Apple 手表 |
| Apple Watch SE 3 | Apple Watch SE3, Watch SE 3, 苹果手表SE3 | Apple 手表 |
| Apple Watch Ultra 3 | Watch Ultra 3, Apple Watch Ultra3, 苹果Ultra手表3 | Apple 手表 |
| Apple Watch Nike | Apple Watch耐克, Watch Nike | Apple 手表 |
| Apple Watch Hermès | Apple Watch Hermes, Apple Watch爱马仕, Watch Hermès | Apple 手表 |
| AirPods | airpods, Air pods | Apple 耳机 |
| AirPods 4 | AirPods4, AirPods四代, 苹果耳机4 | Apple 耳机 |
| AirPods Pro 3 | AirPodsPro3, AirPods Pro三代, 苹果降噪耳机3 | Apple 耳机 |
| AirPods Max 2 | AirPodsMax2, AirPods Max二代, 苹果头戴耳机2 | Apple 耳机 |
| Apple Vision Pro | Vision Pro, AppleVisionPro, 苹果头显 | Apple 空间计算设备 |
| visionOS | Vision OS, vision os, 苹果头显系统 | Apple 操作系统 |
| HomePod | homepod, Home Pod | Apple 音箱 |
| HomePod mini | HomePodmini, Home Pod mini, 苹果小音箱 | Apple 音箱 |
| AirTag | Airtag, air tag | Apple 配件 |
| Apple TV 4K | AppleTV 4K, Apple TV | Apple 产品 |
| Apple Music | apple music | Apple 服务 |
| Apple Pay | apple pay | Apple 服务 |
| App Store | app store | Apple 服务 |
| iCloud | ICloud, icloud | Apple 服务 |
| FaceTime | Facetime, face time, 苹果视频通话 | Apple 应用 |
| iMessage | IMessage, imessage, 苹果信息 | Apple 应用 |
| Safari | safari | Apple 应用 |
| Xiaomi | xiaomi, Xiao Mi | 品牌名 |
| Xiaomi HyperOS | HyperOS, 小米澎湃OS, 澎湃 OS | 小米操作系统 |
| Xiaomi 17T Pro | 小米17T Pro, Xiaomi17T Pro, 小米十七T Pro | Xiaomi 手机 |
| Xiaomi 17T | 小米17T, Xiaomi17T, 小米十七T | Xiaomi 手机 |
| Xiaomi 17 Max | 小米17 Max, Xiaomi17 Max, 小米十七Max | Xiaomi 手机 |
| Xiaomi 17 Ultra 徕卡版 | 小米17 Ultra徕卡版, Xiaomi17 Ultra Leica, 小米17 Ultra莱卡版 | Xiaomi 手机 |
| Xiaomi 17 Ultra | 小米17 Ultra, Xiaomi17 Ultra, 小米十七Ultra | Xiaomi 手机 |
| Xiaomi 17 Pro Max | 小米17 Pro Max, Xiaomi17 Pro Max, 小米十七Pro Max | Xiaomi 手机 |
| Xiaomi MIX | 小米MIX, MIX系列, mix系列 | Xiaomi 手机系列 |
| Xiaomi MIX Fold | 小米MIX Fold, MIX Fold, 小米折叠屏 | Xiaomi 折叠屏手机系列 |
| Xiaomi MIX Flip | 小米MIX Flip, MIX Flip, 小米小折叠 | Xiaomi 折叠屏手机系列 |
| Xiaomi Civi | 小米Civi, Civi系列, 小米西维 | Xiaomi 手机系列 |
| Xiaomi Pad | 小米Pad, 小米平板, Xiaomi平板 | Xiaomi 平板系列 |
| Xiaomi Pad 8 Pro | 小米Pad8 Pro, Xiaomi Pad8 Pro, 小米平板8 Pro | Xiaomi 平板 |
| Xiaomi Pad 8 | 小米Pad8, Xiaomi Pad8, 小米平板8 | Xiaomi 平板 |
| Xiaomi Pad 7S Pro | 小米Pad7S Pro, Xiaomi Pad7S Pro, 小米平板7S Pro | Xiaomi 平板 |
| Xiaomi Pad 7 Ultra | 小米Pad7 Ultra, 小米平板7 Ultra | Xiaomi 平板 |
| Xiaomi Pad 7 Pro | 小米Pad7 Pro, Xiaomi Pad7 Pro, 小米平板7 Pro | Xiaomi 平板 |
| Xiaomi Pad 7 | 小米Pad7, Xiaomi Pad7, 小米平板7 | Xiaomi 平板 |
| Xiaomi Watch | 小米Watch, 小米手表, Xiaomi手表 | Xiaomi 手表系列 |
| Xiaomi Watch S5 | 小米Watch S5, Xiaomi WatchS5, 小米手表S5 | Xiaomi 手表 |
| Xiaomi Watch 5 | 小米Watch 5, Xiaomi Watch5, 小米手表5 | Xiaomi 手表 |
| Xiaomi Watch S4 | 小米Watch S4, Xiaomi WatchS4, 小米手表S4 | Xiaomi 手表 |
| REDMI Watch 6 | 红米Watch6, Redmi Watch 6, REDMI手表6 | REDMI 手表 |
| Xiaomi Buds | 小米Buds, Xiaomi耳机, 小米耳机 | Xiaomi 耳机系列 |
| Xiaomi Buds 6 | 小米Buds6, Xiaomi Buds6, 小米耳机6 | Xiaomi 耳机 |
| Xiaomi Buds 5 Pro | 小米Buds5 Pro, Xiaomi Buds5 Pro, 小米耳机5 Pro | Xiaomi 耳机 |
| Xiaomi Buds 5 | 小米Buds5, Xiaomi Buds5, 小米耳机5 | Xiaomi 耳机 |
| 小米手环10 Pro | 小米手环 10 Pro, Mi Band 10 Pro, 小米手环十Pro | Xiaomi 穿戴 |
| 小米手环10 | 小米手环 10, Mi Band 10, 小米手环十 | Xiaomi 穿戴 |
| 小米AI眼镜 | 小米 AI 眼镜, Xiaomi AI眼镜, 小米眼镜 | Xiaomi 穿戴 |
| REDMI | Redmi, redmi | 小米品牌 |
| REDMI K90 至尊版 | 红米K90至尊版, Redmi K90至尊版, REDMI K90 Ultra | REDMI 手机 |
| REDMI K90 Max | 红米K90 Max, Redmi K90 Max, K90 Max | REDMI 手机 |
| REDMI K90 Pro Max | 红米K90 Pro Max, Redmi K90 Pro Max, K90 Pro Max | REDMI 手机 |
| REDMI Turbo 5 MAX | 红米Turbo5 Max, Redmi Turbo 5 Max, Turbo5 MAX | REDMI 手机 |
| REDMI Turbo 5 | 红米Turbo5, Redmi Turbo 5, Turbo五 | REDMI 手机 |
| REDMI 17C | 红米17C, Redmi 17C, 红米十七C | REDMI 手机 |
| REDMI Note | 红米Note, Redmi Note, Note系列 | REDMI 手机系列 |
| REDMI Pad | 红米Pad, Redmi Pad, REDMI平板 | REDMI 平板系列 |
| REDMI K Pad | 红米K Pad, Redmi K Pad, REDMI KPad | REDMI 平板 |
| REDMI K Pad 2 | 红米K Pad2, Redmi K Pad 2, REDMI KPad2 | REDMI 平板 |
| REDMI Pad 2 | 红米Pad2, Redmi Pad 2, REDMI平板2 | REDMI 平板 |
| REDMI Pad 2 SE | 红米Pad2 SE, Redmi Pad 2 SE, REDMI平板2 SE | REDMI 平板 |
| REDMI Pad 2 Pro | 红米Pad2 Pro, Redmi Pad 2 Pro, REDMI平板2 Pro | REDMI 平板 |
| REDMI Buds 8 Pro | 红米Buds8 Pro, Redmi Buds 8 Pro, REDMI耳机8 Pro | REDMI 耳机 |
| REDMI Buds 8 | 红米Buds8, Redmi Buds 8, REDMI耳机8 | REDMI 耳机 |
| REDMI Buds 8 活力版 | 红米Buds8活力版, Redmi Buds 8活力版, REDMI耳机8活力版 | REDMI 耳机 |
| REDMI Buds 8 青春版 | 红米Buds8青春版, Redmi Buds 8青春版, REDMI耳机8青春版 | REDMI 耳机 |
| OPPO | Oppo, oppo, 欧珀 | 品牌名 |
| ColorOS | Color OS, coloros, OPPO系统 | OPPO 操作系统 |
| OPPO Find N | Find N, find n, OPPO折叠屏 | OPPO 折叠屏手机系列 |
| OPPO Find N6 | Find N6, OPPO N6, FindN6 | OPPO 折叠屏手机 |
| OPPO Find N5 | Find N5, OPPO N5, FindN5 | OPPO 折叠屏手机 |
| OPPO Find N3 | Find N3, OPPO N3, FindN3 | OPPO 折叠屏手机 |
| OPPO Find N3 Flip | Find N3 Flip, OPPO N3 Flip, FindN3 Flip | OPPO 折叠屏手机 |
| OPPO Find X | Find X, FindX, OPPO FindX | OPPO 手机系列 |
| OPPO Find X9 Ultra | Find X9 Ultra, FindX9 Ultra, OPPO X9 Ultra | OPPO 手机 |
| OPPO Find X9s Pro | Find X9s Pro, FindX9s Pro, OPPO X9s Pro | OPPO 手机 |
| OPPO Find X9 Pro 卫星通信版 | Find X9 Pro卫星通信版, OPPO X9 Pro卫星版, FindX9 Pro卫星通信版 | OPPO 手机 |
| OPPO Find X9 Pro | Find X9 Pro, FindX9 Pro, OPPO X9 Pro | OPPO 手机 |
| OPPO Find X9 | Find X9, FindX9, OPPO X9 | OPPO 手机 |
| OPPO Find X8 Ultra | Find X8 Ultra, FindX8 Ultra, OPPO X8 Ultra | OPPO 手机 |
| OPPO Find X8s+ | Find X8s+, FindX8s Plus, OPPO X8s加 | OPPO 手机 |
| OPPO Find X8s | Find X8s, FindX8s, OPPO X8s | OPPO 手机 |
| OPPO Find X8 Pro 卫星通信版 | Find X8 Pro卫星通信版, OPPO X8 Pro卫星版, FindX8 Pro卫星通信版 | OPPO 手机 |
| OPPO Find X8 Pro | Find X8 Pro, FindX8 Pro, OPPO X8 Pro | OPPO 手机 |
| OPPO Find X8 | Find X8, FindX8, OPPO X8 | OPPO 手机 |
| OPPO Reno | Reno, reno, Reno系列 | OPPO 手机系列 |
| OPPO Reno16 | Reno16, Reno 16, OPPO Reno十六 | OPPO 手机 |
| OPPO Reno16 Pro | Reno16 Pro, Reno 16 Pro, OPPO Reno十六Pro | OPPO 手机 |
| OPPO Reno15 Pro | Reno15 Pro, Reno 15 Pro, OPPO Reno十五Pro | OPPO 手机 |
| OPPO Reno15 | Reno15, Reno 15, OPPO Reno十五 | OPPO 手机 |
| OPPO Reno15c | Reno15c, Reno 15c, OPPO Reno十五c | OPPO 手机 |
| OPPO Reno14 Pro | Reno14 Pro, Reno 14 Pro, OPPO Reno十四Pro | OPPO 手机 |
| OPPO Reno14 | Reno14, Reno 14, OPPO Reno十四 | OPPO 手机 |
| OPPO Reno13 Pro | Reno13 Pro, Reno 13 Pro, OPPO Reno十三Pro | OPPO 手机 |
| OPPO Reno13 | Reno13, Reno 13, OPPO Reno十三 | OPPO 手机 |
| OPPO Reno12 Pro | Reno12 Pro, Reno 12 Pro, OPPO Reno十二Pro | OPPO 手机 |
| OPPO Reno12 | Reno12, Reno 12, OPPO Reno十二 | OPPO 手机 |
| OPPO Reno11 Pro | Reno11 Pro, Reno 11 Pro, OPPO Reno十一Pro | OPPO 手机 |
| OPPO Reno11 | Reno11, Reno 11, OPPO Reno十一 | OPPO 手机 |
| OPPO Reno10 Pro+ | Reno10 Pro+, Reno10 Pro Plus, Reno十Pro加 | OPPO 手机 |
| OPPO Reno10 Pro | Reno10 Pro, Reno 10 Pro, OPPO Reno十Pro | OPPO 手机 |
| OPPO Reno10 | Reno10, Reno 10, OPPO Reno十 | OPPO 手机 |
| OPPO K15 Pro 系列 | K15 Pro系列, OPPO K15Pro系列, K15Pro系列 | OPPO 手机系列 |
| OPPO K15 Pro+ | K15 Pro+, K15 Pro Plus, OPPO K15Pro加 | OPPO 手机 |
| OPPO K15 Pro | K15 Pro, OPPO K15Pro, K十五Pro | OPPO 手机 |
| OPPO K13 Turbo Pro | K13 Turbo Pro, OPPO K13Turbo Pro, K十三Turbo Pro | OPPO 手机 |
| OPPO K13 Turbo | K13 Turbo, OPPO K13Turbo, K十三Turbo | OPPO 手机 |
| OPPO A6s Pro | A6s Pro, OPPO A6sPro, A六s Pro | OPPO 手机 |
| OPPO A6 Pro | A6 Pro, OPPO A6Pro, A六Pro | OPPO 手机 |
| OPPO A6 GT | A6 GT, OPPO A6GT, A六GT | OPPO 手机 |
| vivo | Vivo, VIVO, 维沃 | 品牌名 |
| OriginOS | Origin OS, originos, vivo系统 | vivo 操作系统 |
| vivo X | Vivo X, X系列, vivoX系列 | vivo 手机系列 |
| vivo X Fold6 | X Fold6, vivo XFold6, vivo折叠屏6 | vivo 折叠屏手机 |
| vivo X300 Ultra | X300 Ultra, vivo X300Ultra, X三百Ultra | vivo 手机 |
| vivo X300s | X300s, vivo X300S, X三百s | vivo 手机 |
| vivo X300 Pro | X300 Pro, vivo X300Pro, X三百Pro | vivo 手机 |
| vivo X300 | X300, vivo X三百, vivoX300 | vivo 手机 |
| vivo S60 系列 | S60系列, vivo S60, vivo S六十 | vivo 手机系列 |
| vivo Y600 Pro | Y600 Pro, vivo Y600Pro, vivo Y六百Pro | vivo 手机 |
| vivo Pad6 Pro | vivo Pad 6 Pro, vivoPad6 Pro, vivo平板6 Pro | vivo 平板 |
| vivo TWS 5 Pro | vivo TWS5 Pro, TWS 5 Pro, vivo耳机5 Pro | vivo 耳机 |
| iQOO | IQOO, iqoo, 爱酷 | vivo 子品牌 |
| iQOO Z11i | IQOO Z11i, iQOO Z11 I, 爱酷Z11i | iQOO 手机 |
| iQOO 15 | IQOO 15, iQOO十五, 爱酷15 | iQOO 手机 |
| iQOO Neo | IQOO Neo, iQOO Neo系列, 爱酷Neo | iQOO 手机系列 |
| iQOO Z | IQOO Z, iQOO Z系列, 爱酷Z | iQOO 手机系列 |
| HONOR | Honor, honor | 品牌名 |
| MagicOS | Magic OS, magicos, 荣耀系统 | 荣耀操作系统 |
| 荣耀 Magic | 荣耀Magic, HONOR Magic, magic系列 | 荣耀手机系列 |
| 荣耀Magic V6 | 荣耀 Magic V6, Magic V6, 荣耀V6折叠 | 荣耀折叠屏手机 |
| 荣耀Magic8 Pro Air | 荣耀 Magic8 Pro Air, Magic8 Pro Air, 荣耀Magic8 Air | 荣耀手机 |
| 荣耀Magic8 RSR 保时捷设计 | 荣耀Magic8 RSR保时捷设计, Magic8 RSR, 荣耀保时捷 | 荣耀手机 |
| 荣耀Magic V Flip2 | 荣耀 Magic V Flip2, Magic V Flip2, 荣耀小折叠2 | 荣耀折叠屏手机 |
| 荣耀Magic8 Pro | 荣耀 Magic8 Pro, Magic8 Pro, 荣耀Magic八Pro | 荣耀手机 |
| 荣耀600 Pro | 荣耀 600 Pro, HONOR 600 Pro, 荣耀六百Pro | 荣耀手机 |
| 荣耀600 超级版 | 荣耀 600 超级版, HONOR 600超级版, 荣耀六百超级版 | 荣耀手机 |
| 荣耀600 元气版 | 荣耀 600 元气版, HONOR 600元气版, 荣耀六百元气版 | 荣耀手机 |
| 荣耀500 Pro MOLLY 20周年限定版 | 荣耀500 Pro Molly限定版, 荣耀500 Pro MOLLY, 荣耀500 Molly | 荣耀手机 |
| 荣耀500 Pro | 荣耀 500 Pro, HONOR 500 Pro, 荣耀五百Pro | 荣耀手机 |
| 荣耀WIN Turbo | 荣耀 WIN Turbo, HONOR WIN Turbo, 荣耀Win Turbo | 荣耀手机 |
| 荣耀WIN RT | 荣耀 WIN RT, HONOR WIN RT, 荣耀Win RT | 荣耀手机 |
| 荣耀WIN | 荣耀 WIN, HONOR WIN, 荣耀Win | 荣耀手机系列 |
| 荣耀Power2 | 荣耀 Power2, HONOR Power2, 荣耀Power二 | 荣耀手机 |
| 荣耀Power | 荣耀 Power, HONOR Power, 荣耀电量 | 荣耀手机系列 |
| 荣耀X80 Pro Max | 荣耀 X80 Pro Max, HONOR X80 Pro Max, 荣耀X八十Pro Max | 荣耀手机 |
| 荣耀X70 Pro Max | 荣耀 X70 Pro Max, HONOR X70 Pro Max, 荣耀X七十Pro Max | 荣耀手机 |
| 荣耀X80i | 荣耀 X80i, HONOR X80i, 荣耀X八十i | 荣耀手机 |
| 荣耀X70 焕新版 | 荣耀 X70焕新版, HONOR X70焕新版, 荣耀X七十焕新版 | 荣耀手机 |
| 荣耀X60 GT | 荣耀 X60 GT, HONOR X60 GT, 荣耀X六十GT | 荣耀手机 |
| 荣耀Play11 Plus | 荣耀 Play11 Plus, HONOR Play11 Plus, 荣耀Play十一Plus | 荣耀手机 |
| 荣耀Play10 | 荣耀 Play10, HONOR Play10, 荣耀Play十 | 荣耀手机 |
| 荣耀Play11C | 荣耀 Play11C, HONOR Play11C, 荣耀Play十一C | 荣耀手机 |
| 荣耀Play10A | 荣耀 Play10A, HONOR Play10A, 荣耀Play十A | 荣耀手机 |
| 荣耀Play10T | 荣耀 Play10T, HONOR Play10T, 荣耀Play十T | 荣耀手机 |
| 荣耀畅玩80m | 荣耀畅玩 80m, HONOR Play 80m, 荣耀畅玩八十m | 荣耀手机 |
| 荣耀畅玩80 Plus | 荣耀畅玩 80 Plus, HONOR Play 80 Plus, 荣耀畅玩八十Plus | 荣耀手机 |
| 荣耀畅玩70C | 荣耀畅玩 70C, HONOR Play 70C, 荣耀畅玩七十C | 荣耀手机 |
| 荣耀畅玩80 | 荣耀畅玩 80, HONOR Play 80, 荣耀畅玩八十 | 荣耀手机 |
| 荣耀畅玩80 Pro | 荣耀畅玩 80 Pro, HONOR Play 80 Pro, 荣耀畅玩八十Pro | 荣耀手机 |
| 荣耀GT Pro | 荣耀 GT Pro, HONOR GT Pro, 荣耀GTPro | 荣耀手机 |
| 荣耀GT | 荣耀 GT, HONOR GT, 荣耀GT系列 | 荣耀手机 |
| 豆包手机助手 | 豆包 手机助手, 豆包AI手机助手, Doubao手机助手 | 豆包手机端 AI 助手 |
