---
name: srt-audio-review-v4
description: Local-audio-assisted, non-destructive SRT proofreading with exhaustive semantic boundary review and audio-timed placement for every resegmented subtitle group. Use this Skill to run offline Whisper transcription with word timestamps, clean filler words, proofread terminology, inspect every adjacent boundary, atomically resegment B-number groups, preserve group outer bounds and structure, and block delivery until all semantic, timing, conservation, ledger, allowlist, and residual-filler validation passes.
---

# SRT 校稿 V4（跨块语义断句版）

V4 使用本地离线 Whisper 完成全量音频转写和逐词时间定位，并把“断句”作为**连续字幕块的原子化语义组问题**处理。原始 SRT 和原始音频均只读。不得调用 4o、OpenAI、OpenRouter 或其他外部语音转写 API，也不得上传音频。

## 不可违反的边界

- 先读取本 Skill 的 `references/glossary.md`、`references/rules.md`、`references/glossary-custom.md`、`references/do-not-auto-replace.md` 和对应主题词库。汽车内容必须加载 `references/glossary-auto.md`。
- 用户给出的规范词必须逐字保留。例如用户指定 `享界 G9`，不得擅自改成无空格、同音字或其他型号。
- 原始 SRT、原始音频只读。只向新路径输出修正版 SRT。
- 音频证据只允许在本机生成。默认使用 OpenAI 开源 Whisper `small` 模型、CPU 推理和逐词时间戳；不得调用任何网络语音 API。若本地环境或模型缺失，只能在获得下载依赖的网络授权后安装到共享本地缓存，不能退回外部 API。
- 始终保持字幕块数、编号、每块内部行数、换行符风格和末尾空行结构。D 项及未进入 B 项的字幕时间码保持不变；发生重新断句的 B 组允许依据原音调整组内切换时间，但组最外侧开始与结束时间必须锁死。
- 同一字幕行需要停顿时只使用空格；不主动新增逗号、句号、分号或冒号。
- 单块问题使用 `D0001` 格式；跨块断句问题使用 `B0001` 格式。B 项至少覆盖两个连续块。
- 任意两个 B 项不得共享字幕块。相邻边界形成链时必须合并为一个完整连续组。
- 一旦字幕块进入 B 项，任何 D 项都不得独立写入该块；该块内的错字、术语和口水词修改必须合并到同一 B 项的 `replacement_texts`。
- B 项不得只改其中一个块。确认后必须使用 `scripts/apply_confirmed_timed_group_edits.py` 将整组文字与音频定位后的组内时间码原子化写入。
- 所有实际重新分配文字的 B 项都必须设置 `requires_audio_timing_review=true`；在 `audio_timing_review_status=resolved`、`replacement_timecodes` 和每个组内边界的音频定位证据齐全前禁止写入。
- 口水词清理后必须重新扫描跨块边界。删除 `啊/呢/哦/嗯/呃/哇` 等词可能暴露新的“前块末尾词 = 后块开头词”问题。
- 最终验收存在任何未处置的 blocking、review 或残留口水词时，禁止交付 SRT。人工保留项必须进入带非空理由的 allowlist。
- **边界扫描器只是召回候选的辅助工具，不是正确性证明。** 即使候选数为 0、验证脚本返回 0，也必须完成全文纯文字语序审查；不得以“脚本通过”替代人工语义判断。
- **不得只用一个汇总数字证明已完成全边界审查。** 首轮和最终轮都必须在阅读过程中建立逐边界台账；最终台账必须逐项保存实际左右文本、切口、处置结论和语义依据，并通过 `validate_boundary_review_ledger.py`。事后根据 SRT 机械枚举出的空台账不算人工语义审查。
- 不得批量、模板化或按问题类型整体放行 `dangling_tail`。同一句“自然续接”不能作为 allowlist 理由；高数量同类保留项本身应视为断句尚未完成，必须退回重审。
- 纯文字已经能判断的错位不得依赖音频决定“要不要改”。例如介词留在上一块、宾语跑到下一块、定语与中心词拆开、量词与名词拆开，必须先直接按文字语序规划重排；但所有完成重排的 B 组随后都必须听原音，用于确定每条字幕的文字归属和组内精确切换时间。
- 断句修复的默认动作是**在连续块之间移动原有文字并重新分配**。不得为了让每块看似完整而凭空补写、概括、改写原意；词语增删属于校稿问题，必须有上下文或音频依据。
- 先完成听写纠错、术语统一和口水词清理，再冻结一份“音频校准底稿”。后续 B 断句阶段相对该底稿只能改变空格位置和字幕块边界；去掉所有空白后，全文字符序列必须逐字相同。任何补写、删写、同义改写或词序重排都必须使验收失败。
- 本 Skill 默认采用**直接交付模式**：内部完成 D/B 判断、必要听音、原子写入和全部验收后，直接输出最终 SRT，不先要求用户确认修改表。只有存在无法从文字、上下文或音频判定且不同选择会改变原意的实质歧义时，才向用户提问。

## 等效提速纪律（不降低校对标准）

本节只优化执行编排；不得减少任何全文审查、必要音频证据、结构保护或最终验收。不得以抽样、降低候选阈值、批量放行、缩短语义组或跳过复审换取速度。

1. **一次建立首轮工作集。** 将 `prepare_trial.py`、`full_srt_prescan.py` 和“原始 SRT 的”`build_boundary_candidates.py` 连续批量运行。首轮只读、不转写音频，并把 `block_records.json`、D 候选、B 候选和临时术语视为同一份工作集；不要为同一源文件重复建基线或反复输出全文。
2. **首次全边界审查只走一遍且必须完整。** 按块号顺序覆盖全部 `N-1` 个边界，同时建立统一 D/B 计划。阅读时仅展开当前边界的前后 3–5 块及相连语义组；发现链式问题立即扩组。审查期间不写 SRT、不边看边生成多个临时副本。
3. **音频只做一次本地全量转写。** 先运行 `transcribe_local_whisper.py` 对完整音频生成带逐词时间戳的 JSON，再由 D 疑难项和全部 B 组共同复用这份缓存。不得逐项重复转写，也不得调用 4o/API。只有转写缺字或时间戳无法覆盖目标语句时，才截取本地片段试听；仍不能判断且会改变原意时向用户说明歧义，不可猜测。
4. **只冻结一次音频校准底稿。** 在全部听写纠错、术语统一和口水词清理完成后，统一写入 `AUDIO_CALIBRATED_COPY`。若某块随后属于 B 项，它仍只能以 B 项的完整语义组形式报告和写入；B 项的 `original_texts` 必须取自该底稿，之后仅可重新分配原有字符。
5. **扫描和写入保持最少且完整。** 候选扫描只运行三次：原始 SRT 写入前一次、音频校准/口水词清理后一次、B 写入后最终一次。所有已确认 B 项先统一完成音频时间定位，再在一份 edits 文件中交给 `apply_confirmed_timed_group_edits.py` 一次性原子写入；不得按候选逐个落盘。
6. **最终复审仍覆盖全部边界。** B 写入后从第 1 块重新审查全部 `N-1` 个边界，并用最终候选扫描核对。只在该轮发现硬问题时修复相应完整语义组；修复后重新执行最终全边界审查。不得为方便而只复查改动块。
7. **只并行独立的机械验收。** 本地全量转写完成后，纯文字复核和转写差异整理可以并行；对同一 `FINAL_COPY`，文字守恒验收和跨块语义验收也可以并行。全部硬闸门通过前禁止交付。确认页、完整全文转储和中间报告只在用户要求或存在实质歧义时生成，直接交付模式默认保留结构化 JSON 证据即可。

这套编排的目标是减少重复读写、重复转写和无效上下文输出，而不是降低正确率。若任一硬闸门失败，质量要求优先于速度。

## 标准工作流

### 1. 建立只读基线

1. 用 `scripts/prepare_trial.py` 记录源 SRT、源音频、哈希、块数、规则和词库。
2. 将用户临时术语写入本次输出目录的 `task_glossary.json`，不要回写正式词库。
3. 保存源 SRT 路径作为最终 `--baseline`。后续所有修改写入副本。

### 2. 全文单块扫描（D 项）

1. 使用 `scripts/full_srt_prescan.py` 扫描所有字幕块，不抽样。
2. 按本 Skill 文字规则检查错别字、同音词、术语、产品名、数字单位、代词、漏词、重复和口水词。
3. 为单块候选建立 D 编号和完整相邻上下文。
4. 如果 D 项涉及的块也属于 B 项，取消独立 D 写入，把 D 修改并入 B 项。

### 3. 强制跨块边界扫描（B 项）

在任何文本写入前运行：

```bash
python3 scripts/build_boundary_candidates.py \
  --srt INPUT.srt \
  --out boundary_candidates.json \
  --term '享界 G9'
```

按任务追加所有必须保持完整的术语，例如 `--term '车顶帐'`。

扫描器必须识别并分组：

- 前块后缀与后块前缀完全重合，例如 `应该可以 / 可以放`；
- 一字高风险重复，例如 `都是有 / 有一点费劲`；
- 长短语重启，例如 `比如说前面有人没有听 / 比如说前面有人没有听到`；
- 多级重复链，例如 `这两个 / 这两个X型的铰链 / 铰链来撑起`；
- 术语跨块拆分或前缀遗留后重新开始，例如 `车顶 / 帐...`、`车顶 / 车顶帐...`；
- 悬空连接词、助动词和过短病句块。

`boundary_candidates.json` 必须遵守 `references/boundary-edit-schema.md`。不得把一个 B 项重新拆成多个单块建议。

### 3A. 全部边界的纯文字语序重审（强制，不得跳过）

运行候选扫描后，必须按块号顺序审查全文所有 `N-1` 个相邻边界，而不只是扫描器列出的边界。建立本次任务的边界覆盖记录，至少包含 `reviewed_boundary_count`；只有它等于 `block_count - 1` 时才算完成。

审查时忽略原 SRT 的换块暗示，把前后至少 3–5 块临时拼成连续口语，再重新寻找自然切分点。相邻问题形成链时继续向两侧扩展，直到语义组完整；不得只修触发词所在的两个块。

逐边界检查以下不可随意拆分的结构：

- 定语与中心词，例如“为驾驶而生 / 的轿跑 SUV”“896 线 / 双光路激光雷达”；
- 介词、把字句、被字句及其宾语，例如“挪到 / 了 B 柱”“通过 / 前方摄像头”；
- 动词与宾语、结果补语、趋向补语，例如“按 / 下去”“放在 / 中岛后方”；
- 助动词、否定词、副词与核心谓语，例如“可以 / 打开”“肯定没有 / 传统 SUV 大”；
- 数量词、量词与名词，例如“一个 / 侧向补盲灯”“两处 / 磁吸点位”；
- 连词与其引出的分句，例如只有“但是”“以及”“所以”单独占在一块；
- 固定术语、车型、人名、英文名及专业短语；
- 前块句尾词实际属于下一句，或后块句首词实际属于上一句的情况；
- 重复启动、孤立代词、悬空指示词，以及单看能读、连起来却语序颠倒的情况。

每个边界还必须做一次“跨切口组词”检查：分别拼接左块末尾 1–4 字与右块开头 1–4 字，判断是否把一个完整词、固定搭配或语法附着成分从中切开。像“原 / 厂”“收 / 起来”“紧急情况 / 下面”“最 / 关心的”“又 / 跟普通版”这类切口，即使扫描器没有召回，也必须直接重排。检查重点不是复用这些例子，而是确认切口两侧是否必须合读。

判断标准不是“每块必须成为独立句子”，而是**块边界必须落在自然语义停顿处，不能切断不可分的句法成分，也不能把词归到错误的一侧**。屏幕字数均衡和原时间切点只能作为次要约束；语序正确优先。

对发现的问题建立 B 组并原子化重排。重排后将该组连续拼读两遍：

1. 去掉所有块边界后，整句语序和原意必须自然；
2. 保留块边界逐块阅读时，任何块首或块尾都不得出现被切断、误归属或需要倒回上一块才能理解的词。

完成全部 B 修改、D 修改和口水词清理后，必须从第 1 块重新执行一次全边界审查，不能只复查改过的块。最终逐边界台账遵循 `references/boundary-review-ledger-schema.md`，每条记录必须在阅读该边界时写入，不得在审查结束后仅凭脚本批量生成 `kept` 结论。

### 4. 音频证据、字幕归属与精确时间定位

- 文字和完整上下文负责确定正确语义切分；本地 Whisper 转写、逐词时间戳和必要的本地试听负责解决听写内容、说话人切换与真实停顿。
- **所有 `replacement_texts` 与 `original_texts` 不同的 B 组都必须用本地逐词时间戳定位。** 证据范围必须覆盖该组首块开始到末块结束，并保留前后 padding；不能只沿用原 SRT 的内部切点。
- 按 `references/audio-timing-schema.md` 为 B 组填写 `replacement_timecodes` 和 `audio_timing_evidence`。组内每一个相邻字幕切口都要记录左右时间、听音依据和置信度。
- 默认对完整音频运行一次离线转写。将任务词库和用户给出的规范词组成 `--initial-prompt`，不要把某个项目的专名硬编码进脚本：

```bash
python3 scripts/transcribe_local_whisper.py \
  --audio ORIGINAL_AUDIO \
  --out local_whisper_full.json \
  --initial-prompt '本次任务的规范词和高风险专名'
```

- 本机共享缓存默认位于 `~/.cache/srt-audio-review-v4`，也可用环境变量 `SRT_V4_CACHE` 指定。优先复用缓存；不得为每个项目复制或重新下载依赖与模型。若 `python/` 或 `models/small.pt` 缺失，先取得安装依赖所需的联网授权，再运行 `python3 scripts/setup_local_whisper.py`；安装完成后转写阶段保持全程离线。
- 默认模型固定为 `small`，`device=cpu`、`fp16=false`、`word_timestamps=true`。不得为了提速降到更小模型；只有用户明确要求更高精度时才可改用更大本地模型。
- 使用 `compare_srt_local_whisper.py` 将完整 SRT 与本地转写按时间范围对照，生成听写差异候选。差异候选只是证据，不能不看上下文就覆盖字幕。
- 定位顺序是：先用逐词时间戳找到完整词左右的发音结束/开始时间；匹配率高且切点明确时可直接以 `method=local_whisper_word_timestamps` 记录。若转写缺词、重叠或切点靠得过近，则必须播放本地片段确认，并使用 `method=local_whisper_word_timestamps+manual_listen`。
- 如果原时间切点落在完整词或不可分句法成分中，必须把组内切换点移到该成分之前或之后的真实语音边界。只调整该 B 组内部时间码，组首开始和组尾结束保持不变，因此不影响外部字幕。
- 不允许为了字数均衡把已经重新断句的文字放到声音尚未开始或已经结束的字幕条里。若没有高置信切点，标记 `confidence=medium` 并写明最近可用的静音或音节边界；实质歧义仍无法解决时暂停询问用户。
- 不得因为本地转写与原字幕一致就跳过全文纯文字审查；也不得因为本地转写不同就自动采用其文字。产品名、数字、同音词和上下文语义仍由校稿判断决定。
- 仅在用户要求待确认表，或存在会改变原意的实质歧义时，使用固定脚本生成离线确认页：

```bash
python3 scripts/build_boundary_confirmation_html.py \
  --candidates boundary_candidates.json \
  --out SRT校稿V4-跨块语义断句待确认表.html
```

- 生成确认页时，必须同时显示修改前和修改后的**全部连续块**、块号、时间码、问题类型、证据及音频状态。
- D/B 确认默认在内部完成，不先交付待确认表，也不要求用户再确认一遍。仍不得跳过候选生成、必要音频证据、原子写入和最终验收；存在会改变原意的实质歧义时才暂停询问。

### 5. 完整清洗口水词

- 对所有字幕块检查 `啊/呢/哦/嗯/呃/哇`；结合语义和原音删除口水用法。
- 不得因为第一次清理完成就停止。写入后必须运行残留扫描。
- 清理口水词之后，必须再次运行 `build_boundary_candidates.py`，因为边界问题可能在清理后才显现。
- 用户明确要求保留的语气词必须写入最终 allowlist，包含机器签名和具体理由；不得口头忽略。

### 6. 原子化应用已完成音频定位的 B 项

将每个已确认 B 项完整填写：

- `blocks`：至少两个升序连续块；
- `original_texts`：完整覆盖全部块；
- `replacement_texts`：完整覆盖全部块；
- `replacement_timecodes`：完整覆盖全部块；
- `status=confirmed`；
- `requires_audio_timing_review=true`；
- `audio_timing_review_status=resolved`，并为组内每一个边界提供音频定位证据。

然后运行：

```bash
python3 scripts/apply_confirmed_timed_group_edits.py \
  --srt CURRENT_COPY.srt \
  --edits confirmed_boundary_edits.json \
  --out NEXT_COPY.srt \
  --report atomic_apply_report.json
```

脚本必须先验证全部确认组，再统一写入。任何原文不匹配、块范围重叠、缺少块、内部行数变化、音频时间定位未完成、组外边界变化、时间码重叠或字幕短于最小时长，整次应用失败且不产生部分输出。

### 7. 二次边界扫描与最终硬验收

所有 D 修改、B 修改和口水词清理完成后，再运行一次边界候选扫描。不得只检查本轮修改过的块。

在跨块断句完成后，必须以“完成听写、术语和口水词处理，但尚未重排边界”的音频校准底稿运行文字守恒验收：

```bash
python3 scripts/validate_boundary_text_conservation.py \
  --before AUDIO_CALIBRATED_COPY.srt \
  --after FINAL_COPY.srt \
  --allow-timing-changes \
  --report boundary_text_conservation.json
```

此校验只忽略空格和字幕块边界。它必须确认块结构不变、全文字符序列一致，并确认调整后的时间轴合法且不重叠。失败时不得通过 allowlist 绕过；必须撤销所有增删、改写或词序变化，再仅用原字重做断句。

最终必须运行：

```bash
python3 scripts/validate_cross_block_semantics.py \
  --srt FINAL_COPY.srt \
  --baseline ORIGINAL.srt \
  --allow-timing-changes \
  --term '享界 G9' \
  --term '车顶帐' \
  --allowlist final_allowlist.json \
  --report final_semantic_validation.json
```

并验证所有重新断句 B 组的音频时间定位：

```bash
python3 scripts/validate_audio_timing_alignment.py \
  --srt FINAL_COPY.srt \
  --edits confirmed_boundary_edits.json \
  --audio ORIGINAL_AUDIO \
  --report audio_timing_validation.json
```

并验证最终逐边界台账：

```bash
python3 scripts/validate_boundary_review_ledger.py \
  --srt FINAL_COPY.srt \
  --ledger final_boundary_review_ledger.json \
  --report boundary_review_ledger_validation.json
```

没有人工保留项时省略 `--allowlist`。默认验收内容：

- 块数、编号、内部行数、换行符和末尾空行未改变；未进入 B 组的时间码不变，B 组外边界不变，只有完成原音定位的组内切换时间允许调整；
- 全文无未处置的跨块重复、术语拆分、术语重启、悬空词或过短病句块；
- 全文无残留 `啊/呢/哦/嗯/呃/哇`；
- review 级边界和 blocking 级边界都必须处置；
- `reviewed_boundary_count = block_count - 1`，证明全部相邻边界已覆盖；
- allowlist 每项必须有明确、逐项、不可复用的理由。
- `validate_boundary_text_conservation.py` 返回 0 且报告中 `spoken_text_conserved_ignoring_whitespace=true`。
- `validate_audio_timing_alignment.py` 返回 0，确认每一个重新断句 B 组及其全部组内边界均有原音定位证据，最终文字和时间码与计划一致。
- `validate_boundary_review_ledger.py` 返回 0，台账覆盖的有序边界必须恰好是 `1-2` 到 `N-1—N`，不能只提供 `reviewed_boundary_count`。

allowlist 只允许保留确实无需移动文字的特殊边界，例如：

- 不同说话人的相邻轮次，如“小艺小艺 / 我在”；
- 已经完整结束的问句被检测器误取末字，如“看到没有 / 有……”；
- 为表达前后对照而故意重复的短语；
- 数量清楚的并列枚举项。

每个理由必须引用两侧的实际文本，说明说话人或句法关系，并明确解释“为什么不移动任何词”。禁止使用“自然续接”“口语如此”“人工确认保留”等空泛理由。若出现大量 allowlist、同一理由反复使用，或保留项主要是定中、动宾、介宾等可直接重排的结构，最终验收即使技术上通过也不得交付，必须回到 3A 重审。

只有语义验收、文字守恒验收、音频时间定位验收和逐边界台账验收都返回 0、报告中 `passed=true`、全边界覆盖完成，并且 allowlist 通过上述逐项审查，才能直接交付新 SRT。

## 交付清单

交付修正版 SRT 时同时说明：

- 新 SRT 的绝对路径；
- 原始 SRT 未覆盖；
- 已应用的 D/B 编号；
- 清理的口水词数量和残留扫描结果；
- 最终跨块语义验收报告路径及结果；
- 断句文字守恒验收结果，必须明确说明相对音频校准底稿全文原字一致；
- 块数与时间码情况：说明 B 组外边界保持、组内调整数量，以及未进入 B 组的时间码未改变；
- 音频时间定位验收报告路径、使用的本地模型、已定位 B 组数量、人工补听组数和已确认组内边界数量；
- 全边界覆盖数，必须为 `块数 - 1`；
- 最终逐边界台账及其验证报告路径；
- 所有 allowlist 保留项及逐项理由，不得只汇报数量。

## 资源

- `scripts/boundary_common.py`：严格 SRT 解析、边界检测与连续组生成。
- `scripts/build_boundary_candidates.py`：生成不重叠的 B 编号候选。
- `scripts/build_boundary_confirmation_html.py`：生成显示完整连续组的离线 HTML。
- `scripts/apply_confirmed_group_edits.py`：旧版仅文字、时间码不变的兼容写入器；新增或重新断句的 B 组不得使用它交付。
- `scripts/transcribe_local_whisper.py`：使用共享本地 Whisper `small` 模型对完整音频生成逐词时间戳 JSON；不联网、不调用 API、不上传音频。
- `scripts/setup_local_whisper.py`：首次安装时把 Python 依赖和 `small` 模型下载到用户级共享缓存；只负责本地环境初始化，不转写项目音频。
- `scripts/compare_srt_local_whisper.py`：按 SRT 时间范围对照本地转写，生成逐块差异候选供全文校稿复核。
- `scripts/build_boundary_timing_requests.py`：为全部重新断句 B 组生成待定位范围；定位时复用完整本地转写结果。
- `scripts/apply_confirmed_timed_group_edits.py`：按原音证据原子化写入 B 组文字与组内时间码，同时锁死组外边界。
- `scripts/validate_audio_timing_alignment.py`：校验每个 B 组的原音、字幕归属、内部切换时间与最终 SRT 一致。
- `scripts/validate_cross_block_semantics.py`：最终结构、跨块语义和口水词硬验收。
- `scripts/validate_boundary_text_conservation.py`：断句前后结构及全文原字守恒硬验收。
- `scripts/validate_boundary_review_ledger.py`：校验逐边界台账与最终 SRT 哈希、文本和完整覆盖范围一致。
- `references/boundary-edit-schema.md`：B 项数据契约与 allowlist 格式。
- `references/boundary-review-ledger-schema.md`：逐边界人工语义审查台账的数据契约。
- `references/audio-timing-schema.md`：重新断句 B 组的音频定位、时间码和证据数据契约。
