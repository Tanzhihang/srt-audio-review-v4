#!/usr/bin/env python3
"""Validate inputs before local, offline audio transcription."""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

from review_common import SOURCE_SKILL_DIR, TOPIC_CONFIG, parse_srt, sha256_file, topic_sources


def probe_duration(audio: Path) -> float | None:
    if not shutil.which("ffprobe"):
        return None
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(audio)],
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        return None
    try:
        return round(float(result.stdout.strip()), 3)
    except ValueError:
        return None


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="检查音频/SRT并强制加载本 Skill 上下文；不会联网或修改输入文件。")
    parser.add_argument("--srt", required=True, type=Path, help="剪映导出的原始 .srt")
    parser.add_argument("--audio", required=True, type=Path, help="对应原音频或视频文件")
    parser.add_argument("--out-dir", required=True, type=Path, help="本次试运行输出目录")
    parser.add_argument("--topic", required=True, choices=sorted(TOPIC_CONFIG), help="已确认的视频主题")
    parser.add_argument("--source-skill-dir", type=Path, default=SOURCE_SKILL_DIR, help="规则与词库目录；默认使用本 SRT 校稿 V4 Skill")
    args = parser.parse_args()

    srt = args.srt.expanduser().resolve()
    audio = args.audio.expanduser().resolve()
    out_dir = args.out_dir.expanduser().resolve()
    source_skill_dir = args.source_skill_dir.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    input_errors: list[str] = []
    if not srt.is_file():
        input_errors.append(f"找不到 SRT：{srt}")
    if not audio.is_file():
        input_errors.append(f"找不到音频或视频：{audio}")

    records = []
    if srt.is_file():
        records, parse_errors = parse_srt(srt)
        input_errors.extend(parse_errors)
    duration = probe_duration(audio) if audio.is_file() else None
    if duration is not None and records and records[-1]["end_seconds"] > duration + 2:
        input_errors.append("SRT 最后一个时间码比检测到的音频时长晚超过 2 秒。")

    source_entries = []
    source_errors: list[str] = []
    try:
        for source in topic_sources(args.topic, source_skill_dir):
            path = Path(source["path"])
            loaded = path.is_file()
            entry = {**source, "loaded": loaded, "sha256": sha256_file(path) if loaded else None}
            source_entries.append(entry)
            if not loaded:
                source_errors.append(f"缺少必须读取的{source['role']}：{path}")
    except ValueError as exc:
        source_errors.append(str(exc))

    gate_status = "passed" if not input_errors and not source_errors else "blocked"
    context_manifest = {
        "schema_version": 2,
        "mode": "audio-assisted-srt-break-review-trial",
        "topic": args.topic,
        "topic_label": TOPIC_CONFIG[args.topic]["label"],
        "required_domain_glossary": TOPIC_CONFIG[args.topic]["domain_file"],
        "required_sources": source_entries,
        "context_gate_status": gate_status,
        "context_gate_errors": source_errors,
        "source_srt": str(srt),
        "source_srt_sha256": sha256_file(srt) if srt.is_file() else None,
        "source_srt_blocks": len(records),
        "source_audio": str(audio),
        "source_audio_duration_seconds": duration,
        "writes_or_modifies_source_srt": False,
        "calls_openai_api": False,
        "uses_network_transcription": False,
        "local_whisper_planned": True,
    }
    trial_manifest = {
        "schema_version": 2,
        "mode": "audio-assisted-srt-break-review-trial",
        "srt": str(srt),
        "audio": str(audio),
        "srt_blocks": len(records),
        "srt_first_start_seconds": records[0]["start_seconds"] if records else None,
        "srt_last_end_seconds": records[-1]["end_seconds"] if records else None,
        "media_duration_seconds": duration,
        "validation_errors": input_errors,
        "context_gate_status": gate_status,
        "writes_or_modifies_source_srt": False,
        "calls_openai_api": False,
        "uses_network_transcription": False,
        "local_whisper_planned": True,
    }
    write_json(out_dir / "trial_manifest.json", trial_manifest)
    write_json(out_dir / "context_manifest.json", context_manifest)

    print(f"已写入输入检查：{out_dir / 'trial_manifest.json'}")
    print(f"已写入上下文闸门：{out_dir / 'context_manifest.json'}")
    print(f"- 主题：{TOPIC_CONFIG[args.topic]['label']}")
    print(f"- SRT 字幕块：{len(records)}")
    print(f"- 领域词库：{TOPIC_CONFIG[args.topic]['domain_file']}")
    if gate_status != "passed":
        for item in input_errors + source_errors:
            print(f"- 阻止继续：{item}", file=sys.stderr)
        return 1
    print("- 上下文闸门通过；后续仅允许本地 Whisper，不联网、不上传音频。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
