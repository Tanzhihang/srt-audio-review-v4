#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create the user-facing self-contained HTML confirmation report; never edits an SRT."""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path

OUTPUT_NAME = "字幕错别字待确认修改表-HTML预览.html"


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def display_seconds(value) -> str:
    if isinstance(value, (int, float)):
        return f"{value:.2f} 秒"
    return "未调用"


def timing_value(timing: dict, group: str, key: str) -> str:
    return display_seconds((timing.get(group) or {}).get(key))


def esc(value) -> str:
    return html.escape(str(value or ""), quote=True)


def row_html(item: dict) -> str:
    requires_audio = bool(item.get("requires_audio_review"))
    confidence_class = "low" if requires_audio else "high"
    evidence = (
        "<details><summary>查看依据</summary>"
        "<div class=\"evidence-block\">"
        f"<b>校对依据：</b>{esc(item.get('reason'))}<br>"
        f"<b>本地音频参考：</b>{esc(item.get('audio_reference'))}<br>"
        f"<b>下一步：</b>{esc(item.get('next_action'))}"
        "</div></details>"
    )
    search = " ".join(str(item.get(key, "")) for key in ("id", "time_range", "original_text", "issue_type", "suggestion", "reason", "audio_reference")).lower()
    return (
        f"<tr data-id=\"{esc(item.get('id'))}\" data-category=\"{esc(item.get('issue_type'))}\" data-audio=\"{'true' if requires_audio else 'false'}\" data-search=\"{esc(search)}\">"
        f"<td class=\"id\">{esc(item.get('id'))}</td>"
        f"<td class=\"time\">{esc(item.get('time_range'))}<span class=\"block\">第 {esc(item.get('block'))} 块</span></td>"
        f"<td class=\"original\">{esc(item.get('original_text'))}</td>"
        f"<td><span class=\"issue\">{esc(item.get('issue_type'))}</span></td>"
        f"<td class=\"suggestion\">{esc(item.get('suggestion'))}</td>"
        f"<td><span class=\"confidence {confidence_class}\">{esc(item.get('confidence'))}</span></td>"
        f"<td class=\"evidence\">{evidence}</td></tr>"
    )


def build_html(items: list[dict], prescan: dict, context: dict, evidence: dict, timing: dict) -> str:
    categories = sorted({str(item.get("issue_type", "")) for item in items if item.get("issue_type")})
    category_options = "".join(f'<option value="{esc(category)}">{esc(category)}</option>' for category in categories)
    rows = "\n".join(row_html(item) for item in items)
    scanned = prescan.get("scanned_block_count", prescan.get("source_srt_blocks", "—"))
    required_audio = sum(1 for item in items if item.get("requires_audio_review"))
    audio_first = timing_value(timing, "audio_first_run", "wall_seconds")
    cache_rerun = timing_value(timing, "audio_cache_rerun", "wall_seconds")
    effective_total = timing.get("effective_elapsed_seconds")
    total_label = f"{effective_total:.3f} 秒" if isinstance(effective_total, (int, float)) else "待生成"
    return f'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SRT 校稿 V4 待确认修改表（HTML 预览）</title>
<style>
:root {{ --navy:#173f67; --blue:#eaf3fb; --line:#dbe6f0; --text:#1f2937; --muted:#64748b; --warning:#9c3e00; --warning-bg:#fff0e5; --ok:#25643b; --ok-bg:#e9f7ec; }}
* {{ box-sizing: border-box; }}
body {{ margin:0; background:#f5f8fb; color:var(--text); font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif; }}
header {{ background:linear-gradient(120deg,#173f67,#245d8f); color:#fff; padding:30px max(24px,calc((100% - 1500px)/2)); }}
h1 {{ margin:0; font-size:26px; letter-spacing:.2px; }}
header p {{ margin:8px 0 0; opacity:.9; font-size:14px; }}
main {{ max-width:1500px; margin:0 auto; padding:24px; }}
.notice {{ margin:0 0 18px; padding:12px 14px; border:1px solid #f1d28a; border-radius:10px; color:#765707; background:#fff8dd; font-size:14px; }}
.cards {{ display:grid; grid-template-columns:repeat(5,minmax(150px,1fr)); gap:12px; margin-bottom:22px; }}
.card {{ background:#fff; border:1px solid var(--line); border-radius:12px; padding:14px 16px; box-shadow:0 1px 2px rgba(15,23,42,.03); }}
.card small {{ display:block; color:var(--muted); margin-bottom:5px; font-size:12px; }}
.card strong {{ color:var(--navy); font-size:19px; }}
.toolbar {{ display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin:0 0 14px; }}
input,select,label.toggle {{ height:40px; border:1px solid #cddbe7; border-radius:8px; background:#fff; color:var(--text); font:inherit; font-size:14px; }}
input,select {{ padding:0 12px; }}
input {{ min-width:285px; flex:1; }}
select {{ min-width:160px; }}
label.toggle {{ display:flex; align-items:center; gap:7px; padding:0 12px; cursor:pointer; }}
label.toggle input {{ min-width:auto; flex:none; height:auto; }}
.count {{ color:var(--muted); font-size:14px; margin-left:auto; }}
.table-wrap {{ overflow:auto; border:1px solid var(--line); border-radius:12px; background:#fff; box-shadow:0 1px 2px rgba(15,23,42,.03); }}
table {{ width:100%; min-width:1180px; border-collapse:separate; border-spacing:0; font-size:14px; }}
thead th {{ position:sticky; top:0; z-index:1; background:var(--navy); color:#fff; padding:13px 12px; text-align:left; white-space:nowrap; font-size:13px; }}
thead th:first-child {{ border-top-left-radius:11px; }} thead th:last-child {{ border-top-right-radius:11px; }}
tbody td {{ padding:12px; border-bottom:1px solid #edf2f7; vertical-align:top; line-height:1.55; }}
tbody tr:hover {{ background:#f8fbff; }} tbody tr:last-child td {{ border-bottom:0; }}
.id {{ color:var(--navy); font-weight:700; white-space:nowrap; }}
.time {{ width:178px; color:#334155; white-space:nowrap; }}
.block {{ display:block; margin-top:3px; color:var(--muted); font-size:12px; }}
.original {{ min-width:210px; font-weight:600; }}
.issue {{ display:inline-block; padding:3px 8px; background:var(--blue); color:#245d8f; border-radius:99px; font-size:12px; }}
.suggestion {{ min-width:215px; color:#0f5132; font-weight:650; }}
.confidence {{ display:inline-block; padding:3px 8px; border-radius:99px; font-size:12px; font-weight:700; white-space:nowrap; }}
.confidence.low {{ color:var(--warning); background:var(--warning-bg); }} .confidence.high {{ color:var(--ok); background:var(--ok-bg); }}
.evidence {{ min-width:260px; color:#475569; }}
details summary {{ color:#245d8f; cursor:pointer; font-weight:600; }} .evidence-block {{ margin-top:8px; padding:9px 10px; border-left:3px solid #9ec6e7; border-radius:3px; background:#f6faff; font-size:13px; }}
.empty {{ display:none; padding:28px; text-align:center; color:var(--muted); }}
footer {{ color:var(--muted); text-align:center; font-size:12px; padding:20px 0 4px; }}
@media (max-width:800px) {{ main {{ padding:16px; }} header {{ padding:22px 16px; }} h1 {{ font-size:21px; }} .cards {{ grid-template-columns:repeat(2,1fr); }} .count {{ width:100%; margin-left:0; }} input {{ min-width:100%; }} }}
</style>
</head>
<body>
<header><h1>SRT 校稿 V4 待确认修改表</h1><p>HTML 临时预览 · 仅用于确认 D 编号 · 不修改 Skill，不修改原始 SRT</p></header>
<main>
<p class="notice">已按当前 V4 固定版式移除“前一块 / 本块 / 后一块”。“原文”即当前字幕内容；需要时可展开“查看依据”查看音频参考和校对理由。</p>
<section class="cards">
<div class="card"><small>扫描块数</small><strong>{esc(scanned)}</strong></div>
<div class="card"><small>D 项</small><strong>{len(items)}</strong></div>
<div class="card"><small>必须试听</small><strong>{required_audio}</strong></div>
<div class="card"><small>首次音频证据</small><strong>{esc(audio_first)}</strong></div>
<div class="card"><small>缓存复跑</small><strong>{esc(cache_rerun)}</strong></div>
</section>
<section class="toolbar">
<input id="search" type="search" placeholder="搜索编号、原文、建议、问题类型或依据">
<select id="category"><option value="">全部问题类型</option>{category_options}</select>
<label class="toggle"><input id="audioOnly" type="checkbox"> 只看必须试听</label>
<span id="count" class="count"></span>
</section>
<div class="table-wrap"><table><thead><tr><th>编号</th><th>时间 / 块号</th><th>原文</th><th>问题类别</th><th>建议</th><th>置信度</th><th>依据与音频参考</th></tr></thead><tbody id="rows">{rows}</tbody></table><div id="empty" class="empty">没有符合当前筛选条件的项目。</div></div>
<footer>本轮报告：{len(items)} 条 D 项；全文规则扫描 {esc(scanned)} 块；含缓存复跑总耗时 {esc(total_label)}。源文件哈希：{esc(context.get('source_srt_sha256', '未记录'))}。</footer>
</main>
<script>
(function(){{
  var search=document.getElementById('search'); var category=document.getElementById('category'); var audioOnly=document.getElementById('audioOnly'); var rows=[].slice.call(document.querySelectorAll('#rows tr')); var count=document.getElementById('count'); var empty=document.getElementById('empty');
  function filter(){{ var q=search.value.trim().toLowerCase(); var cat=category.value; var audio=audioOnly.checked; var shown=0; rows.forEach(function(row){{ var match=(!q || row.dataset.search.indexOf(q)!==-1) && (!cat || row.dataset.category===cat) && (!audio || row.dataset.audio==='true'); row.hidden=!match; if(match) shown++; }}); count.textContent='显示 '+shown+' / '+rows.length+' 条'; empty.style.display=shown?'none':'block'; }}
  [search,category,audioOnly].forEach(function(control){{ control.addEventListener(control===search?'input':'change',filter); }}); filter();
}})();
</script>
</body>
</html>
'''


def main() -> int:
    parser = argparse.ArgumentParser(description="生成 V4 首轮 HTML 待确认表；不修改 SRT。")
    parser.add_argument("--d-items", required=True, type=Path)
    parser.add_argument("--prescan", required=True, type=Path)
    parser.add_argument("--context-manifest", required=True, type=Path)
    parser.add_argument("--audio-evidence", required=True, type=Path)
    parser.add_argument("--timing", type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.out.name != OUTPUT_NAME:
        raise SystemExit(f"HTML 文件名必须固定为：{OUTPUT_NAME}")
    items, prescan, context, evidence = (load(path) for path in (args.d_items, args.prescan, args.context_manifest, args.audio_evidence))
    timing = load(args.timing) if args.timing and args.timing.is_file() else {}
    if not isinstance(items, list):
        raise SystemExit("D 项 JSON 格式错误：应为列表")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(build_html(items, prescan, context, evidence, timing), encoding="utf-8")
    print(f"已生成 HTML 待确认表：{args.out}（{len(items)} 个 D 项）。")


if __name__ == "__main__":
    raise SystemExit(main())
