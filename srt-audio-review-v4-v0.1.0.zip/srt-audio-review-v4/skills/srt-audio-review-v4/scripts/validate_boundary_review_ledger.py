#!/usr/bin/env python3
"""Validate an exhaustive, auditable boundary-review ledger against a final SRT."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from boundary_common import read_srt, sha256_file


ALLOWED_DECISIONS = {"kept", "edited", "allowlisted"}
EMPTY_BASIS = {"自然续接", "已检查", "没问题", "正常", "保留"}


def normalized_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def expected_cut(left: str, right: str) -> str:
    left_text = normalized_text(left)
    right_text = normalized_text(right)
    return f"{left_text[-16:]} | {right_text[:16]}"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--srt", required=True)
    parser.add_argument("--ledger", required=True)
    parser.add_argument("--report")
    args = parser.parse_args()

    srt_path = Path(args.srt)
    ledger_path = Path(args.ledger)
    report_path = Path(args.report) if args.report else None
    failures: list[str] = []

    try:
        blocks, _, _ = read_srt(srt_path)
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except Exception as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 2

    if not isinstance(ledger, dict):
        failures.append("ledger root must be an object")
        records = []
    else:
        records = ledger.get("boundaries")
        if not isinstance(records, list):
            failures.append("boundaries must be an array")
            records = []

    actual_hash = sha256_file(srt_path)
    if ledger.get("schema") != "srt-audio-review-v4/boundary-review-ledger-v1":
        failures.append("schema mismatch")
    if ledger.get("srt_sha256") != actual_hash:
        failures.append("srt_sha256 does not match the final SRT")
    if ledger.get("block_count") != len(blocks):
        failures.append("block_count mismatch")
    if len(records) != max(0, len(blocks) - 1):
        failures.append(
            f"boundary count mismatch: expected {max(0, len(blocks)-1)}, got {len(records)}"
        )

    for position, record in enumerate(records, start=1):
        if not isinstance(record, dict):
            failures.append(f"boundary record {position} is not an object")
            continue
        left_number, right_number = position, position + 1
        if record.get("review_order") != position:
            failures.append(f"boundary {position}: review_order mismatch")
        if record.get("left_block") != left_number or record.get("right_block") != right_number:
            failures.append(f"boundary {position}: block pair must be {left_number}-{right_number}")
            continue
        left_text = blocks[left_number - 1].text
        right_text = blocks[right_number - 1].text
        if record.get("left_text") != left_text:
            failures.append(f"boundary {position}: left_text mismatch")
        if record.get("right_text") != right_text:
            failures.append(f"boundary {position}: right_text mismatch")
        if record.get("cut") != expected_cut(left_text, right_text):
            failures.append(f"boundary {position}: cut mismatch")

        decision = record.get("decision")
        if decision not in ALLOWED_DECISIONS:
            failures.append(f"boundary {position}: invalid decision {decision!r}")
        if decision == "edited" and not str(record.get("group_id") or "").strip():
            failures.append(f"boundary {position}: edited decision requires group_id")
        if decision == "allowlisted":
            signatures = record.get("allowlist_signatures")
            if not isinstance(signatures, list) or not signatures or not all(
                isinstance(item, str) and item.strip() for item in signatures
            ):
                failures.append(f"boundary {position}: allowlisted decision requires signatures")

        basis = str(record.get("review_basis") or "").strip()
        if len(basis) < 12 or basis in EMPTY_BASIS:
            failures.append(f"boundary {position}: review_basis is empty or non-specific")

    report = {
        "passed": not failures,
        "schema": "srt-audio-review-v4/boundary-review-ledger-validation-v1",
        "srt": str(srt_path.resolve()),
        "ledger": str(ledger_path.resolve()),
        "srt_sha256": actual_hash,
        "block_count": len(blocks),
        "expected_boundary_count": max(0, len(blocks) - 1),
        "reviewed_boundary_count": len(records),
        "failures": failures,
    }
    if report_path:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if failures:
        print(f"逐边界台账验收失败：{len(failures)} 项。", file=sys.stderr)
        for failure in failures[:20]:
            print(f"- {failure}", file=sys.stderr)
        return 1
    print(f"逐边界台账验收通过：{len(blocks)} 块，{len(records)} 个边界。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
