#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run the V4 first-round mechanical path and produce the fixed HTML report; never edits an SRT.

Local full-audio Whisper transcription is deliberately a separate step shared by all
text-reviewed D items and resegmented B groups.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
HTML_NAME = "字幕错别字待确认修改表-HTML预览.html"


def run(label: str, command: list[str], timings: list[dict]) -> None:
    started = time.perf_counter()
    result = subprocess.run(command, text=True, capture_output=True)
    timings.append({"phase": label, "seconds": round(time.perf_counter() - started, 3), "returncode": result.returncode})
    if result.returncode:
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit(f"阶段失败：{label}")
    if result.stdout.strip():
        print(result.stdout.strip())


def dump(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="运行 SRT 校稿 V4 首轮机械流程；生成固定 HTML，不联网、不修改 SRT。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--audio", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--topic", required=True)
    parser.add_argument("--candidate-review-json", required=True, type=Path, help="候选块复核决定；每项一个 block，不得合并不连续块")
    parser.add_argument("--term", action="append", default=[])
    parser.add_argument("--source-skill-dir", type=Path, default=SCRIPT_DIR.parent)
    args = parser.parse_args()

    out = args.out_dir.expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    python = sys.executable
    timings: list[dict] = []
    began = time.perf_counter()
    run("上下文闸门", [python, str(SCRIPT_DIR / "prepare_trial.py"), "--srt", str(args.srt), "--audio", str(args.audio), "--out-dir", str(out), "--topic", args.topic, "--source-skill-dir", str(args.source_skill_dir)], timings)
    command = [python, str(SCRIPT_DIR / "full_srt_prescan.py"), "--srt", str(args.srt), "--context-manifest", str(out / "context_manifest.json"), "--out-dir", str(out), "--manual-candidates-json", str(args.candidate_review_json)]
    for term in args.term:
        command.extend(["--term", term])
    run("全文快速扫描与候选合并", command, timings)
    run("候选块引用队列", [python, str(SCRIPT_DIR / "build_fast_review_queue.py"), "--prescan", str(out / "pre_audio_candidates.json"), "--out", str(out / "fast_review_queue.json")], timings)
    dump(out / "audio_evidence_manifest.json", {"schema_version": 1, "status": "not_run", "requests": 0, "cache_hits": 0, "d_item_evidence": {}, "network_api_called": False, "note": "首轮机械流程不转写音频；下一步对完整音频运行一次本地 Whisper，供全部 D/B 项复用。"})
    run("D 项与候选对账", [python, str(SCRIPT_DIR / "build_confirmation_report.py"), "--prescan", str(out / "pre_audio_candidates.json"), "--block-records", str(out / "block_records.json"), "--out-dir", str(out), "--audio-evidence", str(out / "audio_evidence_manifest.json")], timings)
    run("候选去向验收", [python, str(SCRIPT_DIR / "validate_candidate_accounting.py"), "--prescan", str(out / "pre_audio_candidates.json"), "--accounting", str(out / "candidate_accounting.json")], timings)

    timing_payload = {"schema_version": 8, "mode": "v4_first_round_html", "status": "building_html", "audio_api_called": False, "local_whisper_planned": True, "terminal_window_opened": False, "semantic_review_scope": "候选块及其完整前一块/本块/后一块；非候选块由全文规则扫描覆盖。完整音频随后只做一次本地转写。", "phases": timings, "effective_elapsed_seconds": round(time.perf_counter() - began, 3)}
    dump(out / "run_timing.json", timing_payload)
    html_command = [python, str(SCRIPT_DIR / "build_confirmation_html.py"), "--d-items", str(out / "manual_d_items.json"), "--prescan", str(out / "pre_audio_candidates.json"), "--context-manifest", str(out / "context_manifest.json"), "--audio-evidence", str(out / "audio_evidence_manifest.json"), "--timing", str(out / "run_timing.json"), "--out", str(out / HTML_NAME)]
    run("HTML 待确认表", html_command, timings)

    timing_payload.update({"status": "verifying", "phases": timings, "effective_elapsed_seconds": round(time.perf_counter() - began, 3)})
    dump(out / "run_timing.json", timing_payload)
    # Rebuild once so the fixed footer contains the final first-round timing.
    result = subprocess.run(html_command, text=True, capture_output=True)
    if result.returncode:
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit("阶段失败：HTML 待确认表最终写入")

    verify = [python, str(SCRIPT_DIR / "verify_fast_report.py"), "--out-dir", str(out)]
    for term in args.term:
        verify.extend(["--require-term", term])
    run("V4 HTML 发布验收", verify, timings)
    payload = {"schema_version": 8, "mode": "v4_first_round_html", "status": "completed", "audio_api_called": False, "local_whisper_planned": True, "terminal_window_opened": False, "semantic_review_scope": "候选块及其完整前一块/本块/后一块；非候选块由全文规则扫描覆盖。完整音频随后只做一次本地转写。", "phases": timings, "mechanical_total_seconds": round(time.perf_counter() - began, 3), "effective_elapsed_seconds": round(time.perf_counter() - began, 3)}
    dump(out / "run_timing.json", payload)
    # One final render keeps the footer aligned with the completed timing JSON.
    result = subprocess.run(html_command, text=True, capture_output=True)
    if result.returncode:
        sys.stderr.write(result.stdout + result.stderr)
        raise SystemExit("阶段失败：HTML 待确认表最终时间写入")
    print("V4 首轮机械流程完成：" + json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
