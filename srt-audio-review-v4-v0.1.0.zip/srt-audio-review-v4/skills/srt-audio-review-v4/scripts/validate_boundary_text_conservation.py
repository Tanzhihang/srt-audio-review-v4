#!/usr/bin/env python3
"""Reject boundary-only SRT edits that add, delete, rewrite, or reorder spoken text."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from boundary_common import read_srt, sha256_file


def compact(text: str) -> str:
    return re.sub(r"\s+", "", text)


def first_difference(before: str, after: str) -> dict | None:
    limit = min(len(before), len(after))
    for index in range(limit):
        if before[index] != after[index]:
            return {
                "character_offset": index,
                "before_context": before[max(0, index - 12):index + 13],
                "after_context": after[max(0, index - 12):index + 13],
            }
    if len(before) != len(after):
        return {
            "character_offset": limit,
            "before_context": before[max(0, limit - 12):limit + 13],
            "after_context": after[max(0, limit - 12):limit + 13],
        }
    return None


def to_seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    seconds, milliseconds = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def timeline_is_valid(blocks) -> bool:
    previous_end = None
    for block in blocks:
        start_text, end_text = block.timecode.split(" --> ", 1)
        start, end = to_seconds(start_text), to_seconds(end_text)
        if end <= start:
            return False
        if previous_end is not None and start < previous_end:
            return False
        previous_end = end
    return True


def main() -> int:
    parser = argparse.ArgumentParser(
        description="校验断句前后全文原字守恒；仅忽略空格和字幕块边界。"
    )
    parser.add_argument("--before", required=True, type=Path, help="完成听写、术语和口水词校准后的断句底稿")
    parser.add_argument("--after", required=True, type=Path, help="仅做跨块断句调整后的 SRT")
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument(
        "--allow-timing-changes",
        action="store_true",
        help="允许经音频定位验证的时间码变化；仍强制块结构、全文原字和时间轴顺序正确",
    )
    args = parser.parse_args()

    before_blocks, before_trailing, before_newline = read_srt(args.before)
    after_blocks, after_trailing, after_newline = read_srt(args.after)

    structure_ok = (
        len(before_blocks) == len(after_blocks)
        and all(
            a.number == b.number
            and len(a.text_lines) == len(b.text_lines)
            for a, b in zip(before_blocks, after_blocks)
        )
        and before_trailing == after_trailing
        and before_newline == after_newline
    )
    timecodes_preserved = (
        len(before_blocks) == len(after_blocks)
        and all(a.timecode == b.timecode for a, b in zip(before_blocks, after_blocks))
    )
    timeline_valid = timeline_is_valid(after_blocks)
    before_text = compact("".join(block.text for block in before_blocks))
    after_text = compact("".join(block.text for block in after_blocks))
    text_ok = before_text == after_text
    changed_blocks = [
        a.number for a, b in zip(before_blocks, after_blocks) if a.text != b.text
    ]
    result = {
        "passed": bool(
            structure_ok
            and text_ok
            and (timeline_valid or not args.allow_timing_changes)
            and (timecodes_preserved or args.allow_timing_changes)
        ),
        "before": str(args.before),
        "after": str(args.after),
        "before_sha256": sha256_file(args.before),
        "after_sha256": sha256_file(args.after),
        "block_count": len(after_blocks),
        "structure_preserved": structure_ok,
        "timecodes_preserved": timecodes_preserved,
        "timing_changes_allowed": args.allow_timing_changes,
        "timeline_valid_non_overlapping": timeline_valid,
        "structure_and_timecodes_preserved": bool(structure_ok and timecodes_preserved),
        "spoken_text_conserved_ignoring_whitespace": text_ok,
        "changed_block_count": len(changed_blocks),
        "first_text_difference": first_difference(before_text, after_text),
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    if result["passed"]:
        print(f"断句文字守恒验收通过：{len(after_blocks)} 块，修改 {len(changed_blocks)} 块，全文原字一致。")
        return 0
    print("断句文字守恒验收失败：存在结构、时间轴或增删、改写、重排文字问题。")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
