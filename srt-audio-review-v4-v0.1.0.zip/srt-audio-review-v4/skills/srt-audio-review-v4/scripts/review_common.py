#!/usr/bin/env python3
"""Shared, read-only helpers for audio-assisted SRT review."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

SOURCE_SKILL_DIR = Path(__file__).resolve().parent.parent  # 本音频 Skill 自带的规则与词库
TIMESTAMP_RE = re.compile(
    r"^(?P<start>\d{2}:\d{2}:\d{2},\d{3}) --> (?P<end>\d{2}:\d{2}:\d{2},\d{3})$"
)
TOPIC_CONFIG = {
    "automotive": {"label": "汽车", "domain_file": "glossary-auto.md"},
    "phone": {"label": "手机数码", "domain_file": "glossary-phone.md"},
    "general": {"label": "通用", "domain_file": "glossary-core.md"},
}
BASE_SOURCE_FILES = (
    ("词库入口", "references/glossary.md"),
    ("校对规则", "references/rules.md"),
    ("自定义词库", "references/glossary-custom.md"),
    ("禁止误改清单", "references/do-not-auto-replace.md"),
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def timestamp_to_seconds(value: str) -> float:
    hour, minute, second_ms = value.split(":")
    second, millisecond = second_ms.split(",")
    return int(hour) * 3600 + int(minute) * 60 + int(second) + int(millisecond) / 1000


def seconds_to_timestamp(value: float) -> str:
    milliseconds = round(max(value, 0) * 1000)
    hour, remainder = divmod(milliseconds, 3_600_000)
    minute, remainder = divmod(remainder, 60_000)
    second, millisecond = divmod(remainder, 1_000)
    return f"{hour:02d}:{minute:02d}:{second:02d},{millisecond:03d}"


def parse_srt(path: Path) -> tuple[list[dict[str, Any]], list[str]]:
    text = path.read_text(encoding="utf-8-sig")
    raw_blocks = re.split(r"\n\s*\n", text.strip()) if text.strip() else []
    records: list[dict[str, Any]] = []
    errors: list[str] = []
    for expected_index, block in enumerate(raw_blocks, start=1):
        lines = block.splitlines()
        if len(lines) < 3:
            errors.append(f"字幕块 {expected_index} 缺少编号、时间码或正文。")
            continue
        if lines[0].strip() != str(expected_index):
            errors.append(f"字幕块 {expected_index} 的编号是 {lines[0]!r}。")
        matched = TIMESTAMP_RE.match(lines[1].strip())
        if not matched:
            errors.append(f"字幕块 {expected_index} 的时间码无效：{lines[1]!r}。")
            continue
        start = timestamp_to_seconds(matched.group("start"))
        end = timestamp_to_seconds(matched.group("end"))
        if end <= start:
            errors.append(f"字幕块 {expected_index} 的结束时间不晚于开始时间。")
        records.append(
            {
                "block": expected_index,
                "start": matched.group("start"),
                "end": matched.group("end"),
                "start_seconds": start,
                "end_seconds": end,
                "text": "\n".join(lines[2:]),
            }
        )
    return records, errors


def topic_sources(topic: str, source_skill_dir: Path = SOURCE_SKILL_DIR) -> list[dict[str, str]]:
    if topic not in TOPIC_CONFIG:
        raise ValueError(f"不支持的主题：{topic}")
    sources = [
        {"role": role, "path": str((source_skill_dir / relative).resolve())}
        for role, relative in BASE_SOURCE_FILES
    ]
    sources.append(
        {
            "role": f"{TOPIC_CONFIG[topic]['label']}领域词库",
            "path": str((source_skill_dir / "references" / TOPIC_CONFIG[topic]["domain_file"]).resolve()),
        }
    )
    return sources


def normalize_text(value: str) -> str:
    value = value.lower().replace("　", " ")
    return re.sub(r"\s+", "", value)


def parse_glossary_markdown(path: Path) -> list[dict[str, Any]]:
    """Read the stable Correct term | Common wrong forms | Notes table conservatively."""
    entries: list[dict[str, Any]] = []
    if not path.is_file():
        return entries
    for raw_line in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()
        if not line.startswith("|") or line.count("|") < 3:
            continue
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) < 2:
            continue
        if all(set(cell) <= {"-", ":", " "} for cell in cells):
            continue
        correct = cells[0]
        wrong_forms = cells[1]
        if correct in {"正确词", "Correct term"} or not correct:
            continue
        variants = [correct]
        variants.extend(item.strip() for item in re.split(r"[,，、]", wrong_forms) if item.strip())
        entries.append(
            {
                "correct_term": correct,
                "variants": list(dict.fromkeys(variants)),
                "notes": cells[2] if len(cells) > 2 else "",
                "source": str(path),
            }
        )
    return entries


def context_excerpt(records: list[dict[str, Any]], block_numbers: list[int], radius: int = 1) -> str:
    if not records or not block_numbers:
        return ""
    start = max(1, min(block_numbers) - radius)
    end = min(len(records), max(block_numbers) + radius)
    return " / ".join(f"[{item['block']}] {item['text'].replace(chr(10), ' ')}" for item in records[start - 1:end])
