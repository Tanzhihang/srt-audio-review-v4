#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Release gate for V4 HTML confirmation delivery; never edits an SRT."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HTML_NAME = "字幕错别字待确认修改表-HTML预览.html"
EXPECTED_HEADERS = ["编号", "时间 / 块号", "原文", "问题类别", "建议", "置信度", "依据与音频参考"]
REQUIRED_LAYOUT_MARKERS = [
    "linear-gradient(120deg,#173f67,#245d8f)",
    "class=\"notice\"",
    "class=\"cards\"",
    "id=\"search\"",
    "id=\"category\"",
    "id=\"audioOnly\"",
    "<details><summary>查看依据</summary>",
    "只看必须试听",
    "源文件哈希：",
]


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="验收 V4 HTML 待确认报告；失败时禁止发布。")
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--require-term", action="append", default=[])
    args = parser.parse_args()
    root = args.out_dir.expanduser().resolve()
    required = [
        "context_manifest.json", "pre_audio_candidates.json", "block_records.json",
        "task_glossary.json", "fast_review_queue.json", "candidate_accounting.json",
        "manual_d_items.json", "audio_evidence_manifest.json", HTML_NAME, "run_timing.json",
    ]
    failures = [f"缺少产物：{name}" for name in required if not (root / name).is_file()]
    if failures:
        print("V4 验收失败：\n- " + "\n- ".join(failures), file=sys.stderr)
        return 1

    context, pre, block_records, glossary, queue, report, evidence = (
        load(root / name) for name in (
            "context_manifest.json", "pre_audio_candidates.json", "block_records.json",
            "task_glossary.json", "fast_review_queue.json", "manual_d_items.json",
            "audio_evidence_manifest.json",
        )
    )
    if context.get("context_gate_status") != "passed":
        failures.append("上下文加载硬闸门未通过")
    domain = next((source for source in context.get("required_sources", []) if source["path"].endswith(context.get("required_domain_glossary", ""))), None)
    if not domain or not domain.get("loaded"):
        failures.append("领域词库未实际加载")
    if not pre.get("full_scan_complete") or pre.get("scanned_block_count") != pre.get("source_srt_blocks"):
        failures.append("全文扫描不完整")
    records = block_records.get("records", [])
    if not block_records.get("compression_forbidden") or len(records) != block_records.get("source_srt_blocks"):
        failures.append("单一字幕块记录不完整")
    if queue.get("mode") != "candidate_only_review" or not queue.get("compression_forbidden"):
        failures.append("快速复核队列模式或禁止压缩约束缺失")
    for term in args.require_term:
        if term not in {entry.get("term") for entry in glossary.get("terms", [])}:
            failures.append(f"临时术语缺失：{term}")
    if not isinstance(report, list):
        failures.append("D 项数据格式错误")
        report = []
    for item in report:
        block = item.get("block")
        if not isinstance(block, int) or not 1 <= block <= len(records):
            failures.append(f"{item.get('id')} 不是有效逐块 D 项")
            continue
        current = item.get("context", {}).get("current", {}).get("text")
        if records[block - 1]["text"] != item.get("original_text") or current != item.get("original_text"):
            failures.append(f"{item.get('id')} 原文或完整上下文被压缩/改写")

    source = (root / HTML_NAME).read_text(encoding="utf-8")
    expected_ids = [str(item.get("id")) for item in report]
    actual_ids = re.findall(r'<tr\s+data-id="([^"]+)"', source)
    if actual_ids != expected_ids:
        failures.append("HTML D 编号与 D 项 JSON 不一致")
    headers = re.findall(r"<th>([^<]+)</th>", source)
    if headers != EXPECTED_HEADERS:
        failures.append("HTML 主表不是固定七列表头或字段顺序错误")
    if 'class="block"' not in source:
        failures.append("HTML 缺少时间 / 块号的固定呈现")
    if any(marker not in source for marker in REQUIRED_LAYOUT_MARKERS):
        failures.append("HTML 未严格使用 V4 固定版式或筛选交互")
    if any(header in headers for header in ("前一块", "本块", "后一块")):
        failures.append("HTML 表头出现了禁止展示的相邻上下文列")
    if re.search(r'<(?:script|link|img)[^>]+(?:src|href)=["\']https?://', source, flags=re.I):
        failures.append("HTML 含外部网络资源，不是离线单文件")
    if evidence.get("requests", 0) and set(evidence.get("d_item_evidence", {})) - set(expected_ids):
        failures.append("音频证据包含未知 D 项")
    if list(root.rglob("*.srt")):
        failures.append("第一轮输出目录出现 .srt 文件")

    if failures:
        print("V4 验收失败：\n- " + "\n- ".join(failures), file=sys.stderr)
        return 1
    print("V4 验收通过：全文扫描、完整上下文留存、固定 HTML 七列表、离线筛选交互、D 编号和原 SRT 不变约束均已满足。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
