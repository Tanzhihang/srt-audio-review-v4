#!/usr/bin/env python3
"""Atomically apply audio-timed V4 B groups without changing group outer bounds."""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any

from boundary_common import read_srt, write_json, write_srt


TIMECODE_RE = re.compile(r"^(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})$")


def close(a: float, b: float, tolerance: float = 0.0005) -> bool:
    return abs(a - b) <= tolerance


def compact_group_text(text_map: dict[int, str], numbers: list[int]) -> str:
    return re.sub(r"\s+", "", "".join(text_map[number] for number in numbers))


def to_seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    seconds, milliseconds = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def parse_range(value: Any, item_id: str, field: str, failures: list[str]) -> tuple[float, float] | None:
    if not isinstance(value, str) or not TIMECODE_RE.fullmatch(value):
        failures.append(f"{item_id} 的 {field} 时间码无效：{value!r}")
        return None
    start_text, end_text = value.split(" --> ", 1)
    start, end = to_seconds(start_text), to_seconds(end_text)
    if end <= start:
        failures.append(f"{item_id} 的 {field} 结束时间必须晚于开始时间")
        return None
    return start, end


def rows_to_map(
    rows: Any,
    item_id: str,
    field: str,
    value_key: str,
    failures: list[str],
) -> dict[int, str] | None:
    if not isinstance(rows, list):
        failures.append(f"{item_id} 的 {field} 必须是数组")
        return None
    result: dict[int, str] = {}
    for row in rows:
        if not isinstance(row, dict) or "block" not in row or value_key not in row:
            failures.append(f"{item_id} 的 {field} 每项必须包含 block 和 {value_key}")
            return None
        try:
            number = int(row["block"])
        except (TypeError, ValueError):
            failures.append(f"{item_id} 的 {field} 含无效块号")
            return None
        if number in result:
            failures.append(f"{item_id} 的 {field} 重复包含第 {number} 块")
            return None
        result[number] = row[value_key]
    return result


def main() -> int:
    parser = argparse.ArgumentParser(
        description="原子化应用已完成音频定位的 B 组文字与组内时间码；绝不覆盖输入 SRT。"
    )
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--edits", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--min-duration", type=float, default=0.300)
    args = parser.parse_args()

    source = args.srt.expanduser().resolve()
    out = args.out.expanduser().resolve()
    report = args.report.expanduser().resolve()
    if source == out:
        write_json(report, {"passed": False, "failures": ["禁止覆盖输入 SRT"], "applied": []})
        print("禁止覆盖输入 SRT。", file=sys.stderr)
        return 1
    if args.min_duration <= 0:
        raise SystemExit("--min-duration 必须大于 0")

    blocks, trailing, newline = read_srt(source)
    raw = json.loads(args.edits.read_text(encoding="utf-8"))
    edits = raw.get("candidates", raw) if isinstance(raw, dict) else raw
    if not isinstance(edits, list):
        write_json(report, {"passed": False, "failures": ["edits 必须是数组或包含 candidates 数组"], "applied": []})
        return 1

    confirmed = [item for item in edits if isinstance(item, dict) and item.get("status") == "confirmed"]
    touched: dict[int, str] = {}
    planned: list[tuple[dict[str, Any], dict[int, str], dict[int, str]]] = []
    failures: list[str] = []

    for item in confirmed:
        item_id = str(item.get("id") or "未知编号")
        numbers = item.get("blocks")
        if not isinstance(numbers, list) or len(numbers) < 2 or any(not isinstance(n, int) for n in numbers):
            failures.append(f"{item_id} 必须包含至少两个整数连续 blocks")
            continue
        if numbers != list(range(numbers[0], numbers[-1] + 1)):
            failures.append(f"{item_id} blocks 必须升序且连续")
            continue
        if numbers[0] < 1 or numbers[-1] > len(blocks):
            failures.append(f"{item_id} blocks 超出字幕范围")
            continue
        if item.get("requires_audio_timing_review") is not True:
            failures.append(f"{item_id} 必须设置 requires_audio_timing_review=true")
            continue
        if item.get("audio_timing_review_status") != "resolved":
            failures.append(f"{item_id} 的 audio_timing_review_status 不是 resolved")
            continue
        evidence = item.get("audio_timing_evidence")
        if not isinstance(evidence, dict):
            failures.append(f"{item_id} 缺少 audio_timing_evidence")
            continue
        internal_boundaries = evidence.get("internal_boundaries")
        if not isinstance(internal_boundaries, list) or len(internal_boundaries) != len(numbers) - 1:
            failures.append(f"{item_id} 未完整提供每个组内边界的音频定位证据")
            continue

        original_texts = rows_to_map(item.get("original_texts"), item_id, "original_texts", "text", failures)
        replacement_texts = rows_to_map(item.get("replacement_texts"), item_id, "replacement_texts", "text", failures)
        replacement_times = rows_to_map(item.get("replacement_timecodes"), item_id, "replacement_timecodes", "time_range", failures)
        if original_texts is None or replacement_texts is None or replacement_times is None:
            continue
        if set(original_texts) != set(numbers) or set(replacement_texts) != set(numbers) or set(replacement_times) != set(numbers):
            failures.append(f"{item_id} 的文字与时间码必须完整覆盖 blocks")
            continue

        current_ranges: dict[int, tuple[float, float]] = {}
        proposed_ranges: dict[int, tuple[float, float]] = {}
        item_failed = False
        for number in numbers:
            if number in touched:
                failures.append(f"{item_id} 与 {touched[number]} 重复修改第 {number} 块")
                item_failed = True
                continue
            current = blocks[number - 1]
            if current.text != original_texts[number]:
                failures.append(f"{item_id} 第 {number} 块原文不匹配")
                item_failed = True
            original_row = next(
                (row for row in item.get("original_texts", []) if isinstance(row, dict) and row.get("block") == number),
                None,
            )
            if not original_row or original_row.get("time_range") != current.timecode:
                failures.append(f"{item_id} 第 {number} 块原时间码不匹配")
                item_failed = True
            replacement = replacement_texts[number]
            if not isinstance(replacement, str) or not replacement.strip():
                failures.append(f"{item_id} 第 {number} 块替换文本为空")
                item_failed = True
            elif len(replacement.split("\n")) != len(current.text_lines):
                failures.append(f"{item_id} 第 {number} 块内部行数改变")
                item_failed = True
            parsed_current = parse_range(current.timecode, item_id, f"第 {number} 块原时间码", failures)
            parsed_proposed = parse_range(replacement_times[number], item_id, f"第 {number} 块新时间码", failures)
            if parsed_current is None or parsed_proposed is None:
                item_failed = True
            else:
                current_ranges[number] = parsed_current
                proposed_ranges[number] = parsed_proposed
                if parsed_proposed[1] - parsed_proposed[0] < args.min_duration:
                    failures.append(f"{item_id} 第 {number} 块时长短于 {args.min_duration:.3f} 秒")
                    item_failed = True

        if item_failed:
            continue
        if compact_group_text(original_texts, numbers) != compact_group_text(replacement_texts, numbers):
            failures.append(f"{item_id} 重新断句前后原字不守恒")
            continue
        if not close(proposed_ranges[numbers[0]][0], current_ranges[numbers[0]][0]):
            failures.append(f"{item_id} 不得改变语义组最外侧开始时间")
            continue
        if not close(proposed_ranges[numbers[-1]][1], current_ranges[numbers[-1]][1]):
            failures.append(f"{item_id} 不得改变语义组最外侧结束时间")
            continue
        for left, right in zip(numbers, numbers[1:]):
            if proposed_ranges[left][1] > proposed_ranges[right][0]:
                failures.append(f"{item_id} 第 {left}-{right} 块新时间码发生重叠")
                item_failed = True
            if proposed_ranges[left][1] > current_ranges[numbers[-1]][1] or proposed_ranges[right][0] < current_ranges[numbers[0]][0]:
                failures.append(f"{item_id} 第 {left}-{right} 块时间码超出原语义组外边界")
                item_failed = True
        if item_failed:
            continue

        planned.append((item, replacement_texts, replacement_times))
        for number in numbers:
            touched[number] = item_id

    if failures:
        write_json(report, {"passed": False, "failures": failures, "applied": []})
        print("V4 音频定位原子写入失败：\n- " + "\n- ".join(failures), file=sys.stderr)
        return 1

    applied = []
    changed_timecodes = 0
    for item, text_map, time_map in planned:
        for number in item["blocks"]:
            block = blocks[number - 1]
            block.text_lines = text_map[number].split("\n")
            if block.timecode != time_map[number]:
                changed_timecodes += 1
            block.timecode = time_map[number]
        applied.append({"id": item["id"], "blocks": item["blocks"]})

    out.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(prefix=f".{out.name}.", suffix=".tmp", dir=str(out.parent))
    os.close(file_descriptor)
    temporary_path = Path(temporary_name)
    try:
        write_srt(temporary_path, blocks, trailing, newline)
        output_blocks, output_trailing, output_newline = read_srt(temporary_path)
        structural_failures: list[str] = []
        if len(output_blocks) != len(blocks):
            structural_failures.append("写入后字幕块数改变")
        if output_trailing != trailing or output_newline != newline:
            structural_failures.append("写入后空行或换行符结构改变")
        for expected, actual in zip(blocks, output_blocks):
            if expected.number != actual.number or expected.timecode != actual.timecode:
                structural_failures.append(f"写入后第 {expected.number} 块编号或时间码不匹配计划")
            if len(expected.text_lines) != len(actual.text_lines):
                structural_failures.append(f"写入后第 {expected.number} 块内部行数改变")
        if structural_failures:
            write_json(report, {"passed": False, "failures": structural_failures, "applied": []})
            return 1
        os.replace(temporary_path, out)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()

    write_json(
        report,
        {
            "passed": True,
            "source_srt": str(source),
            "output_srt": str(out),
            "confirmed_group_count": len(confirmed),
            "applied_group_count": len(applied),
            "changed_block_count": len(touched),
            "changed_timecode_count": changed_timecodes,
            "group_outer_bounds_preserved": True,
            "applied": applied,
        },
    )
    print(
        f"已原子化应用 {len(applied)} 个音频定位语义组、{len(touched)} 个字幕块，"
        f"调整 {changed_timecodes} 个时间码：{out}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
