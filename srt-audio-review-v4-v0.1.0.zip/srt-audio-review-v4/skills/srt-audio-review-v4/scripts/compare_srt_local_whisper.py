#!/usr/bin/env python3
"""Build review candidates by comparing SRT blocks with local Whisper words."""
from __future__ import annotations

import argparse
import difflib
import json
import re
from pathlib import Path

from boundary_common import read_srt, sha256_file


def seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    secs, millis = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(secs) + int(millis) / 1000


def compact(value: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u4e00-\u9fff%]", "", value).lower()


def main() -> int:
    parser = argparse.ArgumentParser(description="将 SRT 与本地 Whisper 逐词时间戳对照，生成差异候选。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--transcript", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--threshold", type=float, default=0.86)
    args = parser.parse_args()

    srt = args.srt.expanduser().resolve()
    transcript = args.transcript.expanduser().resolve()
    blocks, _, _ = read_srt(srt)
    data = json.loads(transcript.read_text(encoding="utf-8"))
    if data.get("network_api_called") is not False or data.get("audio_uploaded") is not False:
        raise SystemExit("转写清单没有证明本地离线运行，拒绝继续。")
    words = [word for segment in data.get("segments", []) for word in segment.get("words", [])]
    candidates = []
    for index, block in enumerate(blocks):
        start_text, end_text = block.timecode.split(" --> ")
        start, end = seconds(start_text), seconds(end_text)
        heard = "".join(
            str(word.get("word", ""))
            for word in words
            if start <= (float(word["start"]) + float(word["end"])) / 2 < end
        ).strip()
        ratio = difflib.SequenceMatcher(a=compact(block.text), b=compact(heard), autojunk=False).ratio()
        if ratio >= args.threshold and compact(block.text) == compact(heard):
            continue
        candidates.append({
            "id": f"L{len(candidates) + 1:04d}",
            "block": block.number,
            "time_range": block.timecode,
            "previous_text": blocks[index - 1].text if index else None,
            "srt_text": block.text,
            "local_whisper_text": heard,
            "next_text": blocks[index + 1].text if index + 1 < len(blocks) else None,
            "similarity": round(ratio, 4),
            "status": "review_required",
            "note": "本地转写仅作证据，必须结合上下文和原音判断，禁止自动覆盖。",
        })
    payload = {
        "schema": "srt-audio-review-v4/local-whisper-comparison-v1",
        "source_srt": str(srt),
        "source_srt_sha256": sha256_file(srt),
        "transcript": str(transcript),
        "transcript_model": data.get("model"),
        "network_api_called": False,
        "candidate_count": len(candidates),
        "candidates": candidates,
    }
    output = args.out.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"本地音频差异候选：{len(candidates)} 项 -> {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
