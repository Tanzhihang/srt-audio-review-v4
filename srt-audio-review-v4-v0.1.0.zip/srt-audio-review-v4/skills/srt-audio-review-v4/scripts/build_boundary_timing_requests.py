#!/usr/bin/env python3
"""Build one batch of audio requests for every confirmed, text-changing B group."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def to_seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    seconds, milliseconds = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def main() -> int:
    parser = argparse.ArgumentParser(
        description="为全部已确认且重新分配文字的 B 组生成批量音频时间定位请求。"
    )
    parser.add_argument("--edits", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    raw = json.loads(args.edits.read_text(encoding="utf-8"))
    edits = raw.get("candidates", raw) if isinstance(raw, dict) else raw
    if not isinstance(edits, list):
        raise SystemExit("edits 必须是数组或包含 candidates 数组")

    requests = []
    seen: set[str] = set()
    for item in edits:
        if not isinstance(item, dict) or item.get("status") != "confirmed":
            continue
        item_id = str(item.get("id") or "").strip()
        blocks = item.get("blocks")
        originals = item.get("original_texts")
        replacements = item.get("replacement_texts")
        if not item_id or item_id in seen:
            raise SystemExit(f"B 编号缺失或重复：{item_id!r}")
        seen.add(item_id)
        if not isinstance(blocks, list) or len(blocks) < 2:
            raise SystemExit(f"{item_id} 缺少连续 blocks")
        if not isinstance(originals, list) or not isinstance(replacements, list):
            raise SystemExit(f"{item_id} 缺少 original_texts/replacement_texts")
        original_by_block = {int(row["block"]): row for row in originals}
        replacement_by_block = {int(row["block"]): row for row in replacements}
        if set(original_by_block) != set(blocks) or set(replacement_by_block) != set(blocks):
            raise SystemExit(f"{item_id} 的文本没有完整覆盖 blocks")
        changed = any(
            original_by_block[number].get("text") != replacement_by_block[number].get("text")
            for number in blocks
        )
        if not changed:
            continue
        first_range = str(original_by_block[blocks[0]].get("time_range") or "")
        last_range = str(original_by_block[blocks[-1]].get("time_range") or "")
        if " --> " not in first_range or " --> " not in last_range:
            raise SystemExit(f"{item_id} 的 original_texts 缺少有效 time_range")
        start = to_seconds(first_range.split(" --> ", 1)[0])
        end = to_seconds(last_range.split(" --> ", 1)[1])
        requests.append(
            {
                # Keep the D-style identifier for compatibility with existing manifests.
                "d_id": item_id,
                "item_type": "B_timing",
                "blocks": blocks,
                "start_seconds": start,
                "end_seconds": end,
                "reason": "重新断句后的全部字幕条必须结合原音确定组内切换时间和文字归属。",
            }
        )

    output = {
        "schema": "srt-audio-review-v4/boundary-timing-requests-v1",
        "requests": requests,
        "request_count": len(requests),
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"已生成 B 组音频时间定位请求：{len(requests)} 组。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
