#!/usr/bin/env python3
"""Build a non-compressed, block-by-block text audit before any audio review.

This script never alters the source SRT.  It reads every block, records its exact
text plus separate previous/current/next context, and creates one candidate per
single SRT block and issue type.  Candidates are evidence for human review, not
automatic changes.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

from review_common import normalize_text, parse_glossary_markdown, parse_srt, sha256_file

FILLER_END_RE = re.compile(r"([啊呢哦嗯呃额哎嘛吧呀])(?:[。！？!?，,\s]*)$")
FILLER_START_RE = re.compile(r"^\s*([嗯呃额哎哦])(?:[，,\s]+|$)")
FILLER_REPEAT_RE = re.compile(r"(啊啊|呢呢|哦哦|嗯嗯|呃呃|额额)")
CHAR_REPEAT_RE = re.compile(r"([\u4e00-\u9fffA-Za-z])\1")
SHORT_PHRASE_REPEAT_RE = re.compile(r"([\u4e00-\u9fffA-Za-z]{2,4})\1")
PRONOUN_RE = re.compile(r"[他她它]")
HIGH_RISK_RE = re.compile(r"(?i)(?<![A-Za-z])(max|mac|麦\s*x)(?![A-Za-z])")


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def context_for(records: list[dict[str, Any]], block: int) -> dict[str, Any]:
    current = records[block - 1]
    previous = records[block - 2] if block > 1 else None
    following = records[block] if block < len(records) else None

    def as_line(item: dict[str, Any] | None) -> dict[str, Any] | None:
        if item is None:
            return None
        return {"block": item["block"], "time_range": f"{item['start']}–{item['end']}", "text": item["text"]}

    return {"previous": as_line(previous), "current": as_line(current), "next": as_line(following)}


def glossary_entries_from_context(context: dict[str, Any]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    allowed = {"glossary-custom.md", context["required_domain_glossary"]}
    for item in context["required_sources"]:
        if not item["loaded"]:
            continue
        path = Path(item["path"])
        if path.name not in allowed:
            continue
        for entry in parse_glossary_markdown(path):
            key = (entry["correct_term"], entry["source"])
            if key not in seen:
                seen.add(key)
                entries.append(entry)
    return entries


def resolve_seed_term(seed: str, entries: list[dict[str, Any]]) -> dict[str, str]:
    wanted = normalize_text(seed)
    for entry in entries:
        variants = {normalize_text(value) for value in entry["variants"]}
        if wanted == normalize_text(entry["correct_term"]) or wanted in variants:
            return {"term": entry["correct_term"], "source": "user_seed+old_glossary", "notes": entry["notes"]}
    return {"term": seed.strip(), "source": "user_seed", "notes": "本次临时术语；不写入旧正式词库。"}


def candidate(
    candidate_id: str,
    record: dict[str, Any],
    records: list[dict[str, Any],],
    classification: str,
    reason: str,
    proposed_direction: str | None = None,
    requires_audio_review: bool = False,
    source: str = "automated_full_text_scan",
) -> dict[str, Any]:
    return {
        "id": candidate_id,
        "block": record["block"],
        "time_range": f"{record['start']}–{record['end']}",
        "context_blocks": [number for number in (record["block"] - 1, record["block"], record["block"] + 1) if 1 <= number <= len(records)],
        "classification": classification,
        "proposed_direction": proposed_direction,
        "reason": reason,
        "requires_audio_review": requires_audio_review,
        "auto_change_allowed": False,
        "source": source,
        "disposition": "untriaged",
    }


def automatic_candidates(records: list[dict[str, Any]], entries: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    term_matches: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    number = 1

    def add(record: dict[str, Any], classification: str, reason: str, proposed: str | None = None, audio: bool = False) -> None:
        nonlocal number
        candidates.append(candidate(f"P{number:04d}", record, records, classification, reason, proposed, audio))
        number += 1

    for record in records:
        normalized = normalize_text(record["text"])
        for entry in entries:
            for variant in entry["variants"]:
                normalized_variant = normalize_text(variant)
                if not normalized_variant or normalized_variant not in normalized:
                    continue
                term_matches.append({
                    "block": record["block"], "time_range": f"{record['start']}–{record['end']}",
                    "matched_form": variant, "correct_term": entry["correct_term"], "source": entry["source"],
                })
                if normalized_variant != normalize_text(entry["correct_term"]):
                    add(record, "词库变体 / 待确认", f"命中旧词库变体「{variant}」。", entry["correct_term"], True)
                break

        repeats = sorted(set(match.group(0) for match in CHAR_REPEAT_RE.finditer(record["text"])))
        if repeats:
            add(record, "连续重复识别候选", f"检测到连续重复字符：{'、'.join(repeats)}。", None, True)
        phrase_repeats = sorted(set(match.group(0) for match in SHORT_PHRASE_REPEAT_RE.finditer(record["text"])))
        if phrase_repeats:
            add(record, "短语重复识别候选", f"检测到可能重复短语：{'、'.join(phrase_repeats)}。", None, True)
        end_filler = FILLER_END_RE.search(record["text"])
        if end_filler:
            add(record, "句尾口水词 / 待确认", f"检测到句尾语气词「{end_filler.group(1)}」；需判断是否影响原意或人物口癖。")
        start_filler = FILLER_START_RE.search(record["text"])
        if start_filler:
            add(record, "句首犹豫词 / 待确认", f"检测到句首犹豫词「{start_filler.group(1)}」。")
        filler_repeats = sorted(set(match.group(0) for match in FILLER_REPEAT_RE.finditer(record["text"])))
        if filler_repeats:
            add(record, "重复口水词 / 待确认", f"检测到重复口水词：{'、'.join(filler_repeats)}。")
        pronouns = sorted(set(match.group(0) for match in PRONOUN_RE.finditer(record["text"])))
        if pronouns:
            add(record, "代词指代检查", f"检测到代词：{'、'.join(pronouns)}；必须结合完整上下文确认人或非人指代。")
        high_risk = sorted(set(match.group(0) for match in HIGH_RISK_RE.finditer(record["text"])))
        if high_risk:
            add(record, "高风险英文/产品词检查", f"检测到高风险词：{'、'.join(high_risk)}；不得自动归一化。", None, True)

    return term_matches, candidates


def manual_candidates(raw: Any, records: list[dict[str, Any]], start_number: int) -> list[dict[str, Any]]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError("人工语义候选文件必须是 JSON 数组。")
    result: list[dict[str, Any]] = []
    number = start_number
    for item in raw:
        if not isinstance(item, dict) or not isinstance(item.get("block"), int):
            raise ValueError("人工候选必须每项只使用一个整数 block；禁止合并不连续字幕块。")
        block = item["block"]
        if not 1 <= block <= len(records):
            raise ValueError(f"人工候选 block 超出范围：{block}")
        record = records[block - 1]
        result.append(candidate(
            f"P{number:04d}", record, records,
            item.get("classification", "人工全文语义候选 / 待确认"),
            item.get("reason", "人工逐块全文审校发现的候选；需要用户确认。"),
            item.get("proposed_direction"), bool(item.get("requires_audio_review", False)), "manual_block_by_block_review",
        ))
        number += 1
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="对全部 SRT 块逐块审计；禁止压缩对白上下文或自动修改原 SRT。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--context-manifest", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--term", action="append", default=[], help="本次临时术语；可重复使用")
    parser.add_argument("--manual-candidates-json", type=Path, help="人工逐块全文候选；每项只能有一个 block")
    args = parser.parse_args()

    srt = args.srt.expanduser().resolve()
    out_dir = args.out_dir.expanduser().resolve()
    context = load_json(args.context_manifest.expanduser().resolve())
    if context.get("context_gate_status") != "passed":
        print("上下文闸门未通过；禁止全文初审和音频复核。", file=sys.stderr)
        return 1
    if str(srt) != context.get("source_srt") or sha256_file(srt) != context.get("source_srt_sha256"):
        print("原始 SRT 路径或哈希与上下文清单不一致；禁止继续。", file=sys.stderr)
        return 1

    records, errors = parse_srt(srt)
    if errors:
        print("SRT 格式异常：" + "；".join(errors), file=sys.stderr)
        return 1
    if len(records) != context.get("source_srt_blocks"):
        print("SRT 块数与上下文清单不一致；禁止继续。", file=sys.stderr)
        return 1

    entries = glossary_entries_from_context(context)
    task_terms = [resolve_seed_term(seed, entries) for seed in args.term if seed.strip()]
    task_terms = list({item["term"]: item for item in task_terms}.values())
    term_matches, candidates = automatic_candidates(records, entries)
    raw_manual = load_json(args.manual_candidates_json.expanduser().resolve()) if args.manual_candidates_json else None
    candidates.extend(manual_candidates(raw_manual, records, len(candidates) + 1))

    out_dir.mkdir(parents=True, exist_ok=True)
    task_glossary = {
        "schema_version": 3, "topic": context["topic"], "source_srt": str(srt),
        "writes_to_formal_glossary": False, "terms": task_terms,
        "old_glossary_entries_loaded": len(entries),
    }
    # Keep full block text exactly once. Candidates reference neighbouring blocks by number.
    block_records = {
        "schema_version": 4, "source_srt": str(srt), "source_srt_sha256": sha256_file(srt),
        "source_srt_blocks": len(records), "scanned_block_count": len(records),
        "scanned_block_numbers": [record["block"] for record in records], "full_text_rules_loaded": True,
        "compression_forbidden": True, "records": records,
    }
    prescan = {
        "schema_version": 3, "source_srt": str(srt), "source_srt_sha256": sha256_file(srt),
        "source_srt_blocks": len(records), "scanned_block_count": len(records),
        "scanned_block_numbers": [record["block"] for record in records], "full_scan_complete": True,
        "full_text_rules_loaded": True, "semantic_manual_review_required": True, "compression_forbidden": True, "context_gate_status": context["context_gate_status"],
        "task_glossary_path": str((out_dir / "task_glossary.json").resolve()),
        "block_records_path": str((out_dir / "block_records.json").resolve()),
        "term_matches": term_matches, "candidate_count": len(candidates), "candidates": candidates,
        "candidate_accounting_required": True,
        "notes": "每项候选只对应一个字幕块。每个候选在报告前必须有明确去向，禁止无声丢弃或压缩多块对白。",
    }
    write_json(out_dir / "task_glossary.json", task_glossary)
    write_json(out_dir / "block_records.json", block_records)
    write_json(out_dir / "pre_audio_candidates.json", prescan)
    print(f"已写入单一字幕块记录：{out_dir / 'block_records.json'}（{len(records)} 块；完整原文只保存一次）。")
    print(f"已写入全文候选：{out_dir / 'pre_audio_candidates.json'}（{len(candidates)} 项；每项只对应一个块）。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
