#!/usr/bin/env python3
"""Create an M4A review clip around a chosen SRT time range without touching inputs."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="用 ffmpeg 截取带上下文的本地音频片段，供疑难位置人工试听。"
    )
    parser.add_argument("audio", type=Path, help="原始音频或视频")
    parser.add_argument("--start", required=True, type=float, help="目标段开始秒数")
    parser.add_argument("--end", required=True, type=float, help="目标段结束秒数")
    parser.add_argument("--padding", type=float, default=1.0, help="前后保留秒数（默认 1 秒）")
    parser.add_argument("--out", required=True, type=Path, help="输出 .m4a 文件")
    args = parser.parse_args()

    source = args.audio.expanduser().resolve()
    output = args.out.expanduser().resolve()
    if not source.is_file():
        print(f"找不到音频或视频：{source}", file=sys.stderr)
        return 2
    if args.end <= args.start:
        print("--end 必须大于 --start。", file=sys.stderr)
        return 2
    if output.suffix.lower() != ".m4a":
        print("输出文件必须使用 .m4a 扩展名。", file=sys.stderr)
        return 2
    if not shutil.which("ffmpeg"):
        print("找不到 ffmpeg，无法截取音频片段。", file=sys.stderr)
        return 2

    clip_start = max(0.0, args.start - args.padding)
    clip_end = args.end + args.padding
    output.parent.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        [
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-ss", f"{clip_start:.3f}", "-to", f"{clip_end:.3f}",
            "-i", str(source), "-vn", "-c:a", "aac", "-b:a", "128k", str(output),
        ],
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        print(result.stderr.strip() or "ffmpeg 截取失败。", file=sys.stderr)
        return result.returncode or 1
    print(f"已生成待转写片段：{output}")
    print(f"实际截取范围：{clip_start:.3f}–{clip_end:.3f} 秒")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
