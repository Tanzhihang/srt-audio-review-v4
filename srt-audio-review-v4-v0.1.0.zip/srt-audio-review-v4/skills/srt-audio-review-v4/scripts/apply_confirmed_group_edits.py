#!/usr/bin/env python3
"""Atomically apply confirmed V4 multi-block edits to a new SRT."""
from __future__ import annotations
import argparse
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any
from boundary_common import read_srt, write_srt, write_json


def rows_to_map(rows: Any, item_id: str, field: str, failures: list[str]) -> dict[int, str] | None:
    if not isinstance(rows, list):
        failures.append(f"{item_id} 的 {field} 必须是数组")
        return None
    result: dict[int, str] = {}
    for row in rows:
        if not isinstance(row, dict) or "block" not in row or "text" not in row:
            failures.append(f"{item_id} 的 {field} 每项必须包含 block 和 text")
            return None
        try:
            number = int(row["block"])
        except (TypeError, ValueError):
            failures.append(f"{item_id} 的 {field} 含无效块号")
            return None
        if number in result:
            failures.append(f"{item_id} 的 {field} 重复包含第 {number} 块")
            return None
        result[number] = row["text"]
    return result


def replacements_to_map(value: Any, item_id: str, failures: list[str]) -> dict[int, str] | None:
    if isinstance(value, list):
        return rows_to_map(value, item_id, "replacement_texts", failures)
    if isinstance(value, dict):
        result: dict[int, str] = {}
        for key, text in value.items():
            try:
                number = int(key)
            except (TypeError, ValueError):
                failures.append(f"{item_id} 的 replacement_texts 含无效块号")
                return None
            if number in result:
                failures.append(f"{item_id} 的 replacement_texts 重复包含第 {number} 块")
                return None
            result[number] = text
        return result
    failures.append(f"{item_id} 缺少 replacement_texts")
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description="原子化应用已确认的多块字幕修改；绝不覆盖原 SRT。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--edits", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()

    source = args.srt.expanduser().resolve()
    out = args.out.expanduser().resolve()
    report = args.report.expanduser().resolve()
    if source == out:
        write_json(report, {"passed": False, "failures": ["禁止覆盖原始 SRT"], "applied": []})
        print("禁止覆盖原始 SRT。", file=sys.stderr)
        return 1

    blocks, trailing, newline = read_srt(source)
    raw = json.loads(args.edits.read_text(encoding="utf-8"))
    edits = raw.get("candidates", raw) if isinstance(raw, dict) else raw
    if not isinstance(edits, list):
        write_json(report, {"passed": False, "failures": ["edits 必须是数组或包含 candidates 数组"], "applied": []})
        print("edits 必须是数组或包含 candidates 数组。", file=sys.stderr)
        return 1

    confirmed = [item for item in edits if isinstance(item, dict) and item.get("status") == "confirmed"]
    touched: dict[int, str] = {}
    planned: list[tuple[dict[str, Any], dict[int, str]]] = []
    failures: list[str] = []

    for item in confirmed:
        item_id = str(item.get("id", "未知编号"))
        raw_numbers = item.get("blocks")
        if not isinstance(raw_numbers, list) or len(raw_numbers) < 2 or any(not isinstance(n, int) for n in raw_numbers):
            failures.append(f"{item_id} 必须包含至少两个整数连续 blocks")
            continue
        numbers = raw_numbers
        if numbers != list(range(numbers[0], numbers[-1] + 1)):
            failures.append(f"{item_id} blocks 必须升序且连续")
            continue
        if numbers[0] < 1 or numbers[-1] > len(blocks):
            failures.append(f"{item_id} blocks 超出字幕范围 1-{len(blocks)}")
            continue
        if item.get("requires_audio_review") and item.get("audio_review_status") != "resolved":
            failures.append(f"{item_id} 是必须试听项，但 audio_review_status 不是 resolved")
            continue

        original_map = rows_to_map(item.get("original_texts"), item_id, "original_texts", failures)
        replacement_map = replacements_to_map(item.get("replacement_texts"), item_id, failures)
        if original_map is None or replacement_map is None:
            continue
        if set(original_map) != set(numbers) or set(replacement_map) != set(numbers):
            failures.append(f"{item_id} 的 original_texts/replacement_texts 必须完整覆盖 blocks")
            continue

        local: dict[int, str] = {}
        item_failed = False
        for number in numbers:
            if number in touched:
                failures.append(f"{item_id} 与 {touched[number]} 重复修改第 {number} 块")
                item_failed = True
                continue
            current = blocks[number - 1]
            if current.text != original_map[number]:
                failures.append(f"{item_id} 第 {number} 块原文不匹配，禁止部分应用")
                item_failed = True
                continue
            replacement = replacement_map[number]
            if not isinstance(replacement, str) or not replacement.strip():
                failures.append(f"{item_id} 第 {number} 块替换文本为空")
                item_failed = True
                continue
            if len(replacement.split("\n")) != len(current.text_lines):
                failures.append(f"{item_id} 第 {number} 块内部行数改变")
                item_failed = True
                continue
            local[number] = replacement
        if not item_failed and len(local) == len(numbers):
            planned.append((item, local))
            for number in numbers:
                touched[number] = item_id

    if failures:
        write_json(report, {"passed": False, "failures": failures, "applied": []})
        print("V4 原子化应用失败：\n- " + "\n- ".join(failures), file=sys.stderr)
        return 1

    applied = []
    for item, replacement_map in planned:
        for number, replacement in replacement_map.items():
            blocks[number - 1].text_lines = replacement.split("\n")
        applied.append({"id": item["id"], "blocks": item["blocks"]})

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp_fd, tmp_name = tempfile.mkstemp(prefix=f".{out.name}.", suffix=".tmp", dir=str(out.parent))
    os.close(tmp_fd)
    tmp_path = Path(tmp_name)
    try:
        write_srt(tmp_path, blocks, trailing, newline)
        out_blocks, out_trailing, out_newline = read_srt(tmp_path)
        structural_failures: list[str] = []
        if len(out_blocks) != len(blocks):
            structural_failures.append("写入后字幕块数改变")
        if out_trailing != trailing:
            structural_failures.append("写入后末尾空行结构改变")
        if out_newline != newline:
            structural_failures.append("写入后换行符风格改变")
        for before, after in zip(blocks, out_blocks):
            if before.number != after.number or before.timecode != after.timecode:
                structural_failures.append(f"写入后第 {before.number} 块编号或时间码改变")
            if len(before.text_lines) != len(after.text_lines):
                structural_failures.append(f"写入后第 {before.number} 块内部行数改变")
        if structural_failures:
            write_json(report, {"passed": False, "failures": structural_failures, "applied": []})
            print("V4 写入后结构验证失败。", file=sys.stderr)
            return 1
        os.replace(tmp_path, out)
    finally:
        if tmp_path.exists():
            tmp_path.unlink()

    write_json(report, {
        "passed": True,
        "source_srt": str(source),
        "output_srt": str(out),
        "confirmed_group_count": len(confirmed),
        "applied_group_count": len(applied),
        "changed_block_count": len(touched),
        "applied": applied,
    })
    print(f"已原子化应用 {len(applied)} 个语义组、{len(touched)} 个字幕块：{out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
