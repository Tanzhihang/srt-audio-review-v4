#!/usr/bin/env python3
"""Ensure every final candidate has an explicit, non-compressed disposition."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="验收 最终方案候选逐项去向；禁止静默遗漏或多块压缩。")
    parser.add_argument("--prescan", required=True, type=Path)
    parser.add_argument("--accounting", required=True, type=Path)
    args = parser.parse_args()
    prescan = load(args.prescan)
    rows = load(args.accounting)
    if not isinstance(rows, list):
        print("候选去向文件必须是 JSON 数组。", file=sys.stderr); return 1
    candidates = {x["id"]: x for x in prescan.get("candidates", [])}
    seen: set[str] = set(); errors: list[str] = []
    allowed = {"reported", "not_issue", "deferred", "duplicate_same_block"}
    for row in rows:
        cid = row.get("candidate_id")
        if cid not in candidates:
            errors.append(f"未知候选：{cid}"); continue
        if cid in seen:
            errors.append(f"候选重复记账：{cid}")
        seen.add(cid)
        disposition = row.get("disposition")
        if disposition not in allowed:
            errors.append(f"候选 {cid} 的去向无效：{disposition}")
        if not row.get("reason"):
            errors.append(f"候选 {cid} 缺少去向原因")
        if disposition == "reported" and not row.get("d_id"):
            errors.append(f"已报告候选 {cid} 缺少 D 编号")
    missing = sorted(set(candidates) - seen)
    if missing:
        errors.append("未记账候选：" + "、".join(missing))
    if errors:
        print("候选去向验收失败：\n- " + "\n- ".join(errors), file=sys.stderr); return 1
    summary = {"candidates": len(candidates), "accounted": len(rows), "reported": sum(1 for x in rows if x["disposition"] == "reported")}
    print("候选去向验收通过：" + json.dumps(summary, ensure_ascii=False))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
