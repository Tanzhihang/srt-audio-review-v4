#!/usr/bin/env python3
"""Release gate for audio-positioned B groups and their final SRT timecodes."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from boundary_common import read_srt, sha256_file, write_json


TIMECODE_RE = re.compile(r"^(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})$")
VALID_METHODS = {"manual_listen", "word_timestamps", "manual_listen+word_timestamps"}
VALID_CONFIDENCE = {"high", "medium"}
MIN_DURATION_SECONDS = 0.300


def to_seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    seconds, milliseconds = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def parse_range(value: str) -> tuple[float, float]:
    match = TIMECODE_RE.fullmatch(value)
    if not match:
        raise ValueError(f"无效时间码：{value!r}")
    return to_seconds(match.group(1)), to_seconds(match.group(2))


def close(a: float, b: float, tolerance: float = 0.002) -> bool:
    return abs(a - b) <= tolerance


def main() -> int:
    parser = argparse.ArgumentParser(description="验证所有重新断句 B 组都已按原音定位到最终字幕时间码。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--edits", required=True, type=Path)
    parser.add_argument("--audio", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()

    srt_path = args.srt.expanduser().resolve()
    audio_path = args.audio.expanduser().resolve()
    edits_path = args.edits.expanduser().resolve()
    blocks, _, _ = read_srt(srt_path)
    raw = json.loads(edits_path.read_text(encoding="utf-8"))
    edits = raw.get("candidates", raw) if isinstance(raw, dict) else raw
    failures: list[str] = []
    if not isinstance(edits, list):
        raise SystemExit("edits 必须是数组或包含 candidates 数组")
    if not audio_path.is_file():
        raise SystemExit(f"找不到原始音频：{audio_path}")
    audio_hash = sha256_file(audio_path)

    confirmed = [item for item in edits if isinstance(item, dict) and item.get("status") == "confirmed"]
    checked_groups = 0
    checked_internal_boundaries = 0
    touched: set[int] = set()

    for item in confirmed:
        item_id = str(item.get("id") or "未知编号")
        numbers = item.get("blocks")
        if not isinstance(numbers, list) or len(numbers) < 2 or numbers != list(range(numbers[0], numbers[-1] + 1)):
            failures.append(f"{item_id} blocks 无效")
            continue
        if touched.intersection(numbers):
            failures.append(f"{item_id} 与其他 B 组重叠")
            continue
        touched.update(numbers)
        if item.get("requires_audio_timing_review") is not True:
            failures.append(f"{item_id} 未声明 requires_audio_timing_review=true")
        if item.get("audio_timing_review_status") != "resolved":
            failures.append(f"{item_id} 音频时间定位未 resolved")

        replacements = item.get("replacement_texts")
        timing_rows = item.get("replacement_timecodes")
        evidence = item.get("audio_timing_evidence")
        if not isinstance(replacements, list) or not isinstance(timing_rows, list):
            failures.append(f"{item_id} 缺少 replacement_texts/replacement_timecodes")
            continue
        try:
            replacement_by_block = {int(row.get("block")): row.get("text") for row in replacements if isinstance(row, dict)}
            timing_by_block = {int(row.get("block")): row.get("time_range") for row in timing_rows if isinstance(row, dict)}
        except (TypeError, ValueError):
            failures.append(f"{item_id} 的 replacement_texts/replacement_timecodes 含无效块号")
            continue
        if set(replacement_by_block) != set(numbers) or set(timing_by_block) != set(numbers):
            failures.append(f"{item_id} 的文字或时间码未完整覆盖 blocks")
            continue
        for number in numbers:
            final_block = blocks[number - 1]
            if final_block.text != replacement_by_block[number]:
                failures.append(f"{item_id} 第 {number} 块最终文字与计划不一致")
            if final_block.timecode != timing_by_block[number]:
                failures.append(f"{item_id} 第 {number} 块最终时间码与音频定位计划不一致")

        if not isinstance(evidence, dict):
            failures.append(f"{item_id} 缺少 audio_timing_evidence")
            continue
        if evidence.get("source_audio_sha256") != audio_hash:
            failures.append(f"{item_id} 的音频哈希与当前原音不一致")
        method = evidence.get("method")
        if method not in VALID_METHODS:
            failures.append(f"{item_id} 的定位方法无效：{method!r}")
        clip_range = evidence.get("clip_range_seconds")
        original_rows = item.get("original_texts")
        if not isinstance(original_rows, list) or len(original_rows) != len(numbers):
            failures.append(f"{item_id} 缺少完整 original_texts")
            continue
        try:
            original_by_block = {int(row.get("block")): row for row in original_rows if isinstance(row, dict)}
        except (TypeError, ValueError):
            failures.append(f"{item_id} 的 original_texts 含无效块号")
            continue
        if set(original_by_block) != set(numbers):
            failures.append(f"{item_id} 的 original_texts 未完整覆盖 blocks")
            continue
        try:
            group_start = parse_range(str(original_by_block[numbers[0]]["time_range"]))[0]
            group_end = parse_range(str(original_by_block[numbers[-1]]["time_range"]))[1]
        except (KeyError, TypeError, ValueError) as exc:
            failures.append(f"{item_id} 原时间范围无效：{exc}")
            continue

        planned_ranges: dict[int, tuple[float, float]] = {}
        try:
            for number in numbers:
                planned_ranges[number] = parse_range(str(timing_by_block[number]))
        except ValueError as exc:
            failures.append(f"{item_id} 计划时间码无效：{exc}")
            continue
        if not close(planned_ranges[numbers[0]][0], group_start):
            failures.append(f"{item_id} 改变了语义组最外侧开始时间")
        if not close(planned_ranges[numbers[-1]][1], group_end):
            failures.append(f"{item_id} 改变了语义组最外侧结束时间")
        for number in numbers:
            start, end = planned_ranges[number]
            if end - start < MIN_DURATION_SECONDS:
                failures.append(f"{item_id} 第 {number} 块时长短于 {MIN_DURATION_SECONDS:.3f} 秒")
        for left, right in zip(numbers, numbers[1:]):
            if planned_ranges[left][1] > planned_ranges[right][0]:
                failures.append(f"{item_id} 第 {left}-{right} 块时间码重叠")
        if (
            not isinstance(clip_range, list)
            or len(clip_range) != 2
            or not all(isinstance(value, (int, float)) for value in clip_range)
            or clip_range[0] > group_start
            or clip_range[1] < group_end
        ):
            failures.append(f"{item_id} 的音频片段未覆盖完整语义组")

        boundaries = evidence.get("internal_boundaries")
        if not isinstance(boundaries, list) or len(boundaries) != len(numbers) - 1:
            failures.append(f"{item_id} 必须为每个组内边界提供音频定位证据")
            continue
        by_pair = {
            (row.get("left_block"), row.get("right_block")): row
            for row in boundaries
            if isinstance(row, dict)
        }
        for left, right in zip(numbers, numbers[1:]):
            row = by_pair.get((left, right))
            if row is None:
                failures.append(f"{item_id} 缺少第 {left}-{right} 块音频定位记录")
                continue
            try:
                planned_left_end = planned_ranges[left][1]
                planned_right_start = planned_ranges[right][0]
            except KeyError:
                failures.append(f"{item_id} 第 {left}-{right} 块计划时间码缺失")
                continue
            if not isinstance(row.get("left_end_seconds"), (int, float)) or not close(float(row["left_end_seconds"]), planned_left_end):
                failures.append(f"{item_id} 第 {left}-{right} 块 left_end_seconds 不匹配")
            if not isinstance(row.get("right_start_seconds"), (int, float)) or not close(float(row["right_start_seconds"]), planned_right_start):
                failures.append(f"{item_id} 第 {left}-{right} 块 right_start_seconds 不匹配")
            basis = str(row.get("decision_basis") or "").strip()
            if len(basis) < 12:
                failures.append(f"{item_id} 第 {left}-{right} 块缺少具体音频定位依据")
            if row.get("confidence") not in VALID_CONFIDENCE:
                failures.append(f"{item_id} 第 {left}-{right} 块定位置信度必须为 high 或 medium")
            checked_internal_boundaries += 1
        checked_groups += 1

    report = {
        "passed": not failures,
        "schema": "srt-audio-review-v4/audio-timing-validation-v1",
        "srt": str(srt_path),
        "srt_sha256": sha256_file(srt_path),
        "audio": str(audio_path),
        "audio_sha256": audio_hash,
        "confirmed_group_count": len(confirmed),
        "checked_group_count": checked_groups,
        "checked_internal_boundary_count": checked_internal_boundaries,
        "failures": failures,
    }
    write_json(args.report, report)
    if failures:
        print(f"音频时间定位验收失败：{len(failures)} 项。", file=sys.stderr)
        for failure in failures[:20]:
            print(f"- {failure}", file=sys.stderr)
        return 1
    print(f"音频时间定位验收通过：{checked_groups} 个 B 组，{checked_internal_boundaries} 个组内边界。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
