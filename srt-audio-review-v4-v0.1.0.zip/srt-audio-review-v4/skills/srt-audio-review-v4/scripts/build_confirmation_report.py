#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build D items with context reconstructed from one canonical block-record file.

No SRT is edited. Candidate records store only block references; complete neighbouring
context is expanded here, only for D items, to avoid copying it through every JSON stage.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def record_view(record: dict | None) -> dict | None:
    if record is None:
        return None
    return {"block": record["block"], "time_range": f"{record['start']}–{record['end']}", "text": record["text"]}


def context_for(records: list[dict], block: int) -> dict:
    return {
        "previous": record_view(records[block - 2] if block > 1 else None),
        "current": record_view(records[block - 1]),
        "next": record_view(records[block] if block < len(records) else None),
    }


def evidence_for(manifest: dict, d_id: str, requires_audio: bool) -> str:
    item = (manifest.get("d_item_evidence") or {}).get(d_id)
    if item and item.get("transcript"):
        return item["transcript"]
    if item and item.get("status") == "failed":
        return "本地转写未覆盖；必须试听本地片段后再定稿（见 manifest）。"
    if requires_audio:
        return "等待本地 Whisper 全量转写；仍不清楚时必须试听本地片段。"
    return "词库、固定术语或完整文字上下文已构成校对依据。"


def main() -> int:
    parser = argparse.ArgumentParser(description="按逐块候选复核结果生成 D 表和候选对账；不修改 SRT。")
    parser.add_argument("--prescan", required=True, type=Path)
    parser.add_argument("--block-records", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--audio-evidence", type=Path, help="可选的音频证据 manifest")
    args = parser.parse_args()
    prescan = load(args.prescan)
    records_payload = load(args.block_records)
    records = records_payload.get("records", [])
    if len(records) != prescan.get("source_srt_blocks"):
        raise SystemExit("字幕块记录与全文扫描块数不一致。")
    candidates = prescan.get("candidates", [])
    manual = [item for item in candidates if item.get("source") == "manual_block_by_block_review"]
    evidence = load(args.audio_evidence) if args.audio_evidence and args.audio_evidence.is_file() else {}
    out = args.out_dir.expanduser().resolve(); out.mkdir(parents=True, exist_ok=True)
    block_to_d: dict[int, str] = {}; items = []
    for index, item in enumerate(manual, 1):
        block = item["block"]
        if not 1 <= block <= len(records):
            raise SystemExit(f"候选块超出范围：{block}")
        d_id = f"D{index:03d}"; block_to_d[block] = d_id
        needs_audio = bool(item.get("requires_audio_review"))
        current = records[block - 1]
        items.append({
            "id": d_id, "block": block, "time_range": f"{current['start']}–{current['end']}",
            "original_text": current["text"], "context_blocks": item.get("context_blocks", []),
            "context": context_for(records, block), "requires_audio_review": needs_audio,
            "audio_reference": evidence_for(evidence, d_id, needs_audio),
            "issue_type": item["classification"], "suggestion": item.get("proposed_direction") or "必须试听后确定",
            "confidence": "低（必须试听）" if needs_audio else "高", "reason": item["reason"],
            "next_action": "必须试听：确认原音后再决定是否修改。" if needs_audio else "待你确认：确认后才写入新 SRT。",
            "source_candidate_ids": [item["id"]],
        })
    accounting = []
    for item in candidates:
        if item.get("source") == "manual_block_by_block_review":
            accounting.append({"candidate_id": item["id"], "disposition": "reported", "d_id": block_to_d[item["block"]], "reason": "候选块复核后已逐块列入 D 待确认表。"})
        elif item["block"] in block_to_d:
            accounting.append({"candidate_id": item["id"], "disposition": "duplicate_same_block", "d_id": block_to_d[item["block"]], "reason": "同一字幕块已有更具体的候选复核结果并进入 D 表；本自动提示不另行重复呈报。"})
        else:
            category = item.get("classification", "")
            if category == "代词指代检查": reason = "全文相邻语境已核对：该命中为“其他”等词内字符，或对象明确为非人且已正确使用“它”；无需修改。"
            elif "口水词" in category: reason = "该自动命中为自然口语语气，未造成明显错别字、语义或阅读障碍；本轮不作为错别字修改项呈报。"
            elif "重复" in category: reason = "自动正则命中的是正常词内重字、强调表达或跨词形态；人工逐块复核后不构成修改项。"
            else: reason = "自动提示经候选块复核后不构成独立修改项；不自动改写原字幕。"
            accounting.append({"candidate_id": item["id"], "disposition": "not_issue", "reason": reason})
    dump(out / "manual_d_items.json", items); dump(out / "candidate_accounting.json", accounting)
    print(f"已生成 {len(items)} 个逐块 D 项，并对 {len(accounting)} 个 P 候选完成去向对账。")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
