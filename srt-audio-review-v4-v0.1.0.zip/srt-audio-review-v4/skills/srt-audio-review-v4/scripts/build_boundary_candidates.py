#!/usr/bin/env python3
"""Build V4 multi-block semantic boundary candidates."""
from __future__ import annotations
import argparse
from pathlib import Path
from boundary_common import coalesce_issues, detect_boundary_issues, read_srt, sha256_file, write_json


def main() -> int:
    parser = argparse.ArgumentParser(description="扫描相邻 SRT 块，生成可联动修改的 B 编号语义组。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--term", action="append", default=[])
    args = parser.parse_args()
    srt = args.srt.expanduser().resolve()
    blocks, _, _ = read_srt(srt)
    issues = detect_boundary_issues(blocks, args.term)
    candidates = coalesce_issues(blocks, issues)
    payload = {
        "schema": "srt-audio-review-v4/boundary-candidates-v1",
        "source_srt": str(srt),
        "source_sha256": sha256_file(srt),
        "source_blocks": len(blocks),
        "terms": args.term,
        "issue_count": len(issues),
        "candidate_count": len(candidates),
        "blocking_candidate_count": sum(x["severity"] == "blocking" for x in candidates),
        "review_candidate_count": sum(x["severity"] == "review" for x in candidates),
        "candidates": candidates,
    }
    write_json(args.out, payload)
    print(f"已生成跨块语义候选：{args.out}（{len(issues)} 个边界问题，{len(candidates)} 个 B 语义组）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
