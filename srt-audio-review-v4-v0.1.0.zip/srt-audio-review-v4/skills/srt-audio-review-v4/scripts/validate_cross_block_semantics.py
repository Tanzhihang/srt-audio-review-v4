#!/usr/bin/env python3
"""Hard release gate for V4 cross-block semantics and residual fillers."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from boundary_common import detect_boundary_issues, read_srt, sha256_file, write_json

DEFAULT_FILLERS = ("啊", "呢", "哦", "嗯", "呃", "哇")


def to_seconds(value: str) -> float:
    hours, minutes, tail = value.split(":")
    seconds, milliseconds = tail.split(",")
    return int(hours) * 3600 + int(minutes) * 60 + int(seconds) + int(milliseconds) / 1000


def load_allowlist(path: Path | None) -> dict[str, str]:
    if path is None:
        return {}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise ValueError("allowlist 必须是 JSON 数组")
    result: dict[str, str] = {}
    for row in raw:
        if not isinstance(row, dict):
            raise ValueError("allowlist 每项必须是对象")
        signature = row.get("signature")
        reason = str(row.get("reason", "")).strip()
        if not signature or not reason:
            raise ValueError("allowlist 每项必须同时包含 signature 和非空 reason")
        if signature in result:
            raise ValueError(f"allowlist 包含重复 signature：{signature}")
        result[str(signature)] = reason
    return result


def detect_residual_fillers(blocks, fillers: list[str]) -> list[dict]:
    issues = []
    for block in blocks:
        for token in fillers:
            count = block.text.count(token)
            if not count:
                continue
            issues.append({
                "signature": f"{block.number}|residual_filler|{token}",
                "block": block.number,
                "issue_type": "residual_filler",
                "severity": "blocking",
                "token": token,
                "count": count,
                "text": block.text,
                "reason": f"第 {block.number} 块仍残留口水词“{token}”{count} 处。",
            })
    return issues


def main() -> int:
    parser = argparse.ArgumentParser(description="最终 SRT 跨块语义与口水词硬验收；存在未处置问题时退出失败。")
    parser.add_argument("--srt", required=True, type=Path)
    parser.add_argument("--baseline", type=Path, help="原始 SRT；提供后强制校验块数、编号、时间码和内部行数")
    parser.add_argument("--term", action="append", default=[])
    parser.add_argument("--extra-filler", action="append", default=[], help="追加必须清零的口水词")
    parser.add_argument("--allowlist", type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--blocking-only", action="store_true", help="只阻止 blocking 边界；口水词仍会阻止交付")
    parser.add_argument(
        "--allow-timing-changes",
        action="store_true",
        help="允许已由音频定位验收覆盖的时间码变化；仍校验时间轴有效性",
    )
    args = parser.parse_args()

    srt = args.srt.expanduser().resolve()
    blocks, trailing, newline = read_srt(srt)
    structural_failures: list[str] = []
    baseline_path = None
    if args.baseline:
        baseline_path = args.baseline.expanduser().resolve()
        original, original_trailing, original_newline = read_srt(baseline_path)
        if len(original) != len(blocks):
            structural_failures.append(f"字幕块数改变：{len(original)} -> {len(blocks)}")
        for index, (before, after) in enumerate(zip(original, blocks), 1):
            if before.number != after.number:
                structural_failures.append(f"第 {index} 块编号改变")
            if before.timecode != after.timecode and not args.allow_timing_changes:
                structural_failures.append(f"第 {index} 块时间码改变")
            if len(before.text_lines) != len(after.text_lines):
                structural_failures.append(f"第 {index} 块内部行数改变")
        if original_trailing != trailing:
            structural_failures.append("末尾空行结构改变")
        if original_newline != newline:
            structural_failures.append("换行符风格改变")

    previous_end = None
    original_previous_end = None
    for index, block in enumerate(blocks):
        start_text, end_text = block.timecode.split(" --> ", 1)
        start, end = to_seconds(start_text), to_seconds(end_text)
        if end <= start:
            structural_failures.append(f"第 {block.number} 块结束时间不晚于开始时间")
        if previous_end is not None and start < previous_end:
            baseline_had_overlap = False
            if args.baseline and index < len(original):
                original_start_text, original_end_text = original[index].timecode.split(" --> ", 1)
                original_start = to_seconds(original_start_text)
                baseline_had_overlap = original_previous_end is not None and original_start < original_previous_end
            if not baseline_had_overlap:
                structural_failures.append(f"第 {block.number - 1}-{block.number} 块新增时间码重叠")
        previous_end = end
        if args.baseline and index < len(original):
            _, original_end_text = original[index].timecode.split(" --> ", 1)
            original_previous_end = to_seconds(original_end_text)

    allowlist = load_allowlist(args.allowlist)
    boundary_issues = detect_boundary_issues(blocks, args.term)
    fillers = list(dict.fromkeys([*DEFAULT_FILLERS, *[x for x in args.extra_filler if x]]))
    filler_issues = detect_residual_fillers(blocks, fillers)

    unresolved_boundaries = []
    unresolved_fillers = []
    accepted = []
    for issue in [*boundary_issues, *filler_issues]:
        if issue["signature"] in allowlist:
            accepted.append({**issue, "allow_reason": allowlist[issue["signature"]]})
        elif issue["issue_type"] == "residual_filler":
            unresolved_fillers.append(issue)
        elif issue["severity"] == "blocking" or not args.blocking_only:
            unresolved_boundaries.append(issue)

    passed = not structural_failures and not unresolved_boundaries and not unresolved_fillers
    report = {
        "schema": "srt-audio-review-v4/final-validation-v2",
        "srt": str(srt),
        "baseline": str(baseline_path) if baseline_path else None,
        "srt_sha256": sha256_file(srt),
        "block_count": len(blocks),
        "newline": "CRLF" if newline == "\r\n" else "LF",
        "timing_changes_allowed": args.allow_timing_changes,
        "checked_fillers": fillers,
        "structural_failures": structural_failures,
        "detected_boundary_issue_count": len(boundary_issues),
        "detected_filler_issue_count": len(filler_issues),
        "accepted_issue_count": len(accepted),
        "unresolved_boundary_count": len(unresolved_boundaries),
        "unresolved_filler_count": len(unresolved_fillers),
        # Compatibility total for simple consumers.
        "unresolved_issue_count": len(unresolved_boundaries) + len(unresolved_fillers),
        "accepted_issues": accepted,
        "unresolved_boundaries": unresolved_boundaries,
        "unresolved_fillers": unresolved_fillers,
        "passed": passed,
    }
    write_json(args.report, report)
    if not passed:
        print(
            "V4 最终验收失败："
            f"结构问题 {len(structural_failures)} 项，"
            f"未处置跨块问题 {len(unresolved_boundaries)} 项，"
            f"残留口水词问题 {len(unresolved_fillers)} 项。",
            file=sys.stderr,
        )
        return 1
    print(f"V4 最终验收通过：{len(blocks)} 块，跨块问题和口水词均已处置。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
