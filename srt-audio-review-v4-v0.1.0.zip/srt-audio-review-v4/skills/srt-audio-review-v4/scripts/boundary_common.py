#!/usr/bin/env python3
"""Shared SRT boundary primitives for V4 cross-block semantic review."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
import hashlib
import json
import re

TIMECODE_RE = re.compile(r"^\d{2}:\d{2}:\d{2},\d{3} --> \d{2}:\d{2}:\d{2},\d{3}$")
SPACE_RE = re.compile(r"\s+")
TRIM_PUNCT_RE = re.compile(r"^[，。！？!?、；;：:\s]+|[，。！？!?、；;：:\s]+$")

# A one-character suffix/prefix repeat is only blocking for these high-risk
# grammatical or deictic tokens. Longer exact overlaps are always blocking.
RISKY_SINGLE_OVERLAPS = {"有", "也", "来", "这", "对", "上", "下", "的", "在", "是", "把", "给", "从", "和", "跟", "并", "哇"}

# These endings are not automatically rewritten. They are mandatory review
# candidates because they commonly leave a semantic unit stranded across a cut.
DANGLING_TAILS = (
    "一个可以", "这是一个", "是一个", "有一个", "这样一个", "这个是",
    "以及", "或者", "因为", "如果", "虽然", "但是", "而且", "通过", "进行",
    "需要", "能够", "可以", "一个", "这个", "那个", "这种", "在", "把", "给",
    "从", "跟", "和", "并", "有", "也",
)


@dataclass
class SrtBlock:
    number: int
    timecode: str
    text_lines: list[str]

    @property
    def text(self) -> str:
        return "\n".join(self.text_lines)

    @property
    def start(self) -> str:
        return self.timecode.split(" --> ", 1)[0]

    @property
    def end(self) -> str:
        return self.timecode.split(" --> ", 1)[1]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_srt(path: Path) -> tuple[list[SrtBlock], bool, str]:
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):
        encoding = "utf-8-sig"
    else:
        encoding = "utf-8"
    text = raw.decode(encoding)
    newline = "\r\n" if "\r\n" in text else "\n"
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    trailing_blank = normalized.endswith("\n\n")
    payload = normalized[:-2] if trailing_blank else normalized.rstrip("\n")
    raw_blocks = payload.split("\n\n") if payload else []
    blocks: list[SrtBlock] = []
    for position, raw_block in enumerate(raw_blocks, 1):
        lines = raw_block.split("\n")
        if len(lines) < 3:
            raise ValueError(f"第 {position} 块少于三行")
        if not lines[0].isdigit():
            raise ValueError(f"第 {position} 块编号无效：{lines[0]!r}")
        if int(lines[0]) != position:
            raise ValueError(f"第 {position} 块编号不连续：{lines[0]!r}")
        if not TIMECODE_RE.fullmatch(lines[1]):
            raise ValueError(f"第 {position} 块时间码无效：{lines[1]!r}")
        blocks.append(SrtBlock(position, lines[1], lines[2:]))
    return blocks, trailing_blank, newline


def write_srt(path: Path, blocks: list[SrtBlock], trailing_blank: bool, newline: str = "\n") -> None:
    rendered = "\n\n".join(
        "\n".join([str(block.number), block.timecode, *block.text_lines]) for block in blocks
    )
    if trailing_blank:
        rendered += "\n\n"
    if newline != "\n":
        rendered = rendered.replace("\n", newline)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as f:
        f.write(rendered)


def compact(text: str) -> str:
    return SPACE_RE.sub("", TRIM_PUNCT_RE.sub("", text.replace("\n", " ")))


def longest_overlap(left: str, right: str, max_length: int = 32) -> str:
    a, b = compact(left), compact(right)
    best = ""
    for length in range(1, min(max_length, len(a), len(b)) + 1):
        if a[-length:] == b[:length]:
            best = a[-length:]
    return best


def boundary_signature(left_block: int, right_block: int, issue_type: str, token: str) -> str:
    return f"{left_block}-{right_block}|{issue_type}|{token}"


def _split_term_issue(left: str, right: str, term: str) -> tuple[str, str, str] | None:
    wanted = compact(term)
    if len(wanted) < 2:
        return None
    a, b = compact(left), compact(right)
    for cut in range(1, len(wanted)):
        prefix, suffix = wanted[:cut], wanted[cut:]
        if a.endswith(prefix) and b.startswith(suffix):
            return prefix, suffix, "split"
        # A speaker/editor may restart the whole canonical term in the next
        # subtitle after leaving its prefix at the end of the previous block.
        # This is both an overlap and a term-boundary defect.
        if a.endswith(prefix) and b.startswith(wanted):
            return prefix, wanted, "restart"
    return None


def detect_boundary_issues(blocks: list[SrtBlock], terms: Iterable[str] = ()) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    seen: set[str] = set()
    clean_terms = [term for term in terms if compact(term)]
    for index in range(len(blocks) - 1):
        left, right = blocks[index], blocks[index + 1]
        left_text, right_text = left.text, right.text
        overlap = longest_overlap(left_text, right_text)
        if overlap and (len(overlap) >= 2 or overlap in RISKY_SINGLE_OVERLAPS):
            sig = boundary_signature(left.number, right.number, "exact_overlap", overlap)
            issues.append({
                "signature": sig,
                "left_block": left.number,
                "right_block": right.number,
                "issue_type": "exact_overlap",
                "severity": "blocking",
                "token": overlap,
                "reason": f"前块结尾与后块开头重复“{overlap}”。",
            })
            seen.add(sig)

        left_compact = compact(left_text)
        right_compact = compact(right_text)
        for term in clean_terms:
            split = _split_term_issue(left_text, right_text, term)
            if not split:
                continue
            prefix, suffix, mode = split
            issue_type = "split_term" if mode == "split" else "term_restart"
            token = f"{prefix}|{suffix}->{compact(term)}"
            sig = boundary_signature(left.number, right.number, issue_type, token)
            if sig not in seen:
                reason = (
                    f"术语“{term}”被拆在相邻字幕块：{prefix} / {suffix}。"
                    if mode == "split"
                    else f"前块遗留术语“{term}”的前缀“{prefix}”，后块又从完整术语重新开始。"
                )
                issues.append({
                    "signature": sig,
                    "left_block": left.number,
                    "right_block": right.number,
                    "issue_type": issue_type,
                    "severity": "blocking",
                    "token": token,
                    "reason": reason,
                })
                seen.add(sig)

        dangling = next((tail for tail in DANGLING_TAILS if left_compact.endswith(tail)), "")
        if dangling:
            # Exact overlaps already provide the stronger diagnosis. Otherwise this
            # boundary must be reviewed, not silently accepted.
            sig = boundary_signature(left.number, right.number, "dangling_tail", dangling)
            if sig not in seen:
                issues.append({
                    "signature": sig,
                    "left_block": left.number,
                    "right_block": right.number,
                    "issue_type": "dangling_tail",
                    "severity": "review",
                    "token": dangling,
                    "reason": f"前块以高风险悬空词“{dangling}”结束，必须结合后一块复核语义归属。",
                })
                seen.add(sig)

        if len(left_compact) <= 4 and left_compact in {"打开的", "关闭的", "一个是", "这个是", "在这里", "在这", "有一个", "一个"}:
            sig = boundary_signature(left.number, right.number, "orphan_short_block", left_compact)
            if sig not in seen:
                issues.append({
                    "signature": sig,
                    "left_block": left.number,
                    "right_block": right.number,
                    "issue_type": "orphan_short_block",
                    "severity": "review",
                    "token": left_compact,
                    "reason": f"前块“{left_compact}”过短且语义不完整，必须与相邻块联动复核。",
                })
                seen.add(sig)
    return issues


def coalesce_issues(blocks: list[SrtBlock], issues: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Merge every connected flagged boundary into disjoint atomic groups.

    Disjointness is a release invariant: two B candidates must never share a
    subtitle block, otherwise independently confirming them could create
    contradictory writes. A chain such as 1-2 and 2-3 therefore becomes one
    three-block group regardless of individual issue severity.
    """
    grouped: list[list[dict[str, Any]]] = []
    for issue in sorted(issues, key=lambda x: (x["left_block"], x["right_block"], x["issue_type"])):
        if grouped and issue["left_block"] <= max(x["right_block"] for x in grouped[-1]):
            grouped[-1].append(issue)
        else:
            grouped.append([issue])

    candidates: list[dict[str, Any]] = []
    occupied: set[int] = set()
    for number, group in enumerate(grouped, 1):
        involved = list(range(
            min(x["left_block"] for x in group),
            max(x["right_block"] for x in group) + 1,
        ))
        overlap = occupied.intersection(involved)
        if overlap:
            raise AssertionError(f"B 候选块范围重叠：{sorted(overlap)}")
        occupied.update(involved)
        original_texts = [
            {"block": n, "time_range": blocks[n - 1].timecode, "text": blocks[n - 1].text}
            for n in involved
        ]
        candidates.append({
            "id": f"B{number:04d}",
            "blocks": involved,
            "time_range": f"{blocks[involved[0]-1].start}–{blocks[involved[-1]-1].end}",
            "original_texts": original_texts,
            "replacement_texts": None,
            "issue_types": sorted({x["issue_type"] for x in group}),
            "severity": "blocking" if any(x["severity"] == "blocking" for x in group) else "review",
            "signatures": [x["signature"] for x in group],
            "evidence": [x["reason"] for x in group],
            "requires_audio_review": True,
            "audio_review_status": "unresolved",
            "status": "unresolved",
            "next_action": "结合连续字幕块和原音，填写 replacement_texts 后确认；禁止逐块孤立修改。",
        })
    return candidates


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
