#!/usr/bin/env python3
"""Offline full-audio Whisper transcription with word timestamps.

This script never calls a transcription API. It reuses a local Python runtime and
model cache so separate Codex tasks can share one installation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

DEFAULT_CACHE = Path(os.environ.get("SRT_V4_CACHE", "~/.cache/srt-audio-review-v4")).expanduser()

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description="使用本地 Whisper 对完整音频生成逐词时间戳；不联网、不调用 API。")
    parser.add_argument("--audio", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--model", default="small", choices=("small", "medium", "large-v3"))
    parser.add_argument("--language", default="zh")
    parser.add_argument("--initial-prompt", default="", help="本次任务的用户规范词、产品名和高风险专名")
    parser.add_argument("--runtime-dir", type=Path, default=DEFAULT_CACHE / "python")
    parser.add_argument("--model-dir", type=Path, default=DEFAULT_CACHE / "models")
    args = parser.parse_args()

    audio = args.audio.expanduser().resolve()
    output = args.out.expanduser().resolve()
    runtime = args.runtime_dir.expanduser().resolve()
    model_dir = args.model_dir.expanduser().resolve()
    if not audio.is_file():
        raise SystemExit(f"找不到音频：{audio}")
    if not runtime.is_dir():
        raise SystemExit(f"缺少本地 Whisper 运行环境：{runtime}；只能安装本地依赖，禁止改用语音 API。")
    expected_model = model_dir / f"{args.model}.pt"
    if not expected_model.is_file():
        raise SystemExit(f"缺少本地模型：{expected_model}；获得网络授权后下载到共享缓存，禁止改用语音 API。")

    sys.path.insert(0, str(runtime))
    try:
        import whisper  # type: ignore
    except Exception as exc:
        raise SystemExit(f"本地 Whisper 无法载入：{exc}") from exc

    started = time.perf_counter()
    model = whisper.load_model(str(expected_model), device="cpu")
    result = model.transcribe(
        str(audio),
        language=args.language,
        task="transcribe",
        fp16=False,
        word_timestamps=True,
        initial_prompt=args.initial_prompt or None,
        verbose=False,
    )
    payload = {
        "schema": "srt-audio-review-v4/local-whisper-full-v1",
        "source_audio": str(audio),
        "source_audio_sha256": sha256_file(audio),
        "engine": "openai-whisper-local",
        "model": args.model,
        "device": "cpu",
        "language": args.language,
        "word_timestamps": True,
        "network_api_called": False,
        "audio_uploaded": False,
        "initial_prompt": args.initial_prompt,
        "elapsed_seconds": round(time.perf_counter() - started, 3),
        "text": result.get("text", ""),
        "segments": result.get("segments", []),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"本地转写完成：{len(payload['segments'])} 段，模型 {args.model}，未调用 API：{output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
