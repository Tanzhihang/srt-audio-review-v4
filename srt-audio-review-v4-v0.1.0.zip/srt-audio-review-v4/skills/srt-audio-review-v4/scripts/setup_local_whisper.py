#!/usr/bin/env python3
"""Install the offline Whisper runtime and small model into a user cache."""
from __future__ import annotations

import argparse
import importlib
import os
import shutil
import subprocess
import sys
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="安装 V4 本地 Whisper 运行环境和 small 模型。安装阶段需要联网。")
    parser.add_argument(
        "--cache-dir",
        type=Path,
        default=Path(os.environ.get("SRT_V4_CACHE", "~/.cache/srt-audio-review-v4")).expanduser(),
    )
    parser.add_argument("--force", action="store_true", help="重新安装 Python 依赖并重新校验模型")
    args = parser.parse_args()

    if sys.version_info < (3, 10):
        raise SystemExit("需要 Python 3.10 或更高版本；请使用 Python 3.10 或更高版本运行本脚本。")
    if not shutil.which("ffmpeg"):
        raise SystemExit("未找到 ffmpeg。macOS 可先运行 `brew install ffmpeg`，再重新执行本脚本。")

    cache = args.cache_dir.expanduser().resolve()
    runtime = cache / "python"
    models = cache / "models"
    runtime.mkdir(parents=True, exist_ok=True)
    models.mkdir(parents=True, exist_ok=True)

    whisper_package = runtime / "whisper"
    if args.force or not whisper_package.is_dir():
        print(f"正在安装本地 Whisper Python 依赖：{runtime}")
        subprocess.run(
            [
                sys.executable,
                "-m",
                "pip",
                "install",
                "--upgrade",
                "--target",
                str(runtime),
                "openai-whisper",
            ],
            check=True,
        )
    else:
        print(f"复用已有 Python 依赖：{runtime}")

    sys.path.insert(0, str(runtime))
    importlib.invalidate_caches()
    try:
        import whisper  # type: ignore
    except Exception as exc:
        raise SystemExit(f"Whisper 安装后无法载入：{exc}") from exc

    print(f"正在校验或下载 small 模型：{models}")
    whisper.load_model("small", device="cpu", download_root=str(models))
    model_path = models / "small.pt"
    if not model_path.is_file():
        raise SystemExit(f"模型初始化失败：{model_path}")

    print("V4 本地 Whisper 初始化完成。项目音频不会上传，后续转写可离线运行。")
    print(f"共享缓存：{cache}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
