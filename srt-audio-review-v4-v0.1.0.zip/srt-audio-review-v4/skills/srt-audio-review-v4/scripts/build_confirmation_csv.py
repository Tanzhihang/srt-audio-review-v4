#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create the user-facing UTF-8 BOM CSV confirmation table; never edits an SRT."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

COLUMNS = ["D编号", "时间范围", "块号", "原文", "前一块", "本块", "后一块", "本地音频参考", "问题类别", "建议", "置信度", "依据", "下一步动作"]

def load(path: Path): return json.loads(path.read_text(encoding="utf-8"))
def text(ctx: dict, part: str) -> str: return (ctx.get(part) or {}).get("text", "")

def main() -> int:
    p = argparse.ArgumentParser(description="生成首轮 CSV 待确认表；不修改 SRT。")
    p.add_argument("--d-items", required=True, type=Path); p.add_argument("--prescan", required=True, type=Path)
    p.add_argument("--context-manifest", required=True, type=Path); p.add_argument("--audio-evidence", required=True, type=Path)
    p.add_argument("--out", required=True, type=Path); args = p.parse_args()
    items, prescan, context, evidence = (load(x) for x in (args.d_items, args.prescan, args.context_manifest, args.audio_evidence))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=COLUMNS); writer.writeheader()
        for item in items:
            ctx = item["context"]
            writer.writerow({"D编号": item["id"], "时间范围": item["time_range"], "块号": item["block"], "原文": item["original_text"],
                "前一块": text(ctx, "previous"), "本块": text(ctx, "current"), "后一块": text(ctx, "next"),
                "本地音频参考": item["audio_reference"], "问题类别": item["issue_type"], "建议": item["suggestion"],
                "置信度": item["confidence"], "依据": item["reason"], "下一步动作": item["next_action"]})
        metas = [
            f"全文规则扫描：{prescan.get('scanned_block_count')} / {prescan.get('source_srt_blocks')} 块；D 项：{len(items)}。",
            f"音频证据：状态={evidence.get('status', 'not_run')}；请求块={len(evidence.get('d_item_evidence', {}))}；缓存命中={evidence.get('cache_hits', 0)}。",
            f"源 SRT：{context.get('source_srt')}；哈希：{context.get('source_srt_sha256')}；上下文闸门：{context.get('context_gate_status')}。",
        ]
        for value in metas: writer.writerow({"D编号": "__META__", "原文": value})
    print(f"已生成 CSV 待确认表：{args.out}（{len(items)} 个 D 项）。")

if __name__ == "__main__": raise SystemExit(main())
