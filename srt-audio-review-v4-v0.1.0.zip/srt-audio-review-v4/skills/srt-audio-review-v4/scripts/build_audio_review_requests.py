#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Select unresolved D items for audio evidence; never edits SRT or audio."""
from __future__ import annotations
import argparse, json
from pathlib import Path

def load(path: Path): return json.loads(path.read_text(encoding="utf-8"))
def ts(value: str) -> float:
    h, m, tail = value.split(":"); s, ms = tail.split(",")
    return int(h) * 3600 + int(m) * 60 + int(s) + int(ms) / 1000

def main() -> int:
    p = argparse.ArgumentParser(description="把仍需试听的 D 项写为音频证据请求；不修改字幕或音频。")
    p.add_argument("--d-items", required=True, type=Path); p.add_argument("--out", required=True, type=Path)
    p.add_argument("--d-id", action="append", default=[], help="需要试听的 D 编号；可重复")
    p.add_argument("--all-requires-audio", action="store_true", help="选择全部 requires_audio_review 的 D 项")
    a = p.parse_args(); items = load(a.d_items)
    wanted = set(a.d_id)
    if a.all_requires_audio: wanted.update(item["id"] for item in items if item.get("requires_audio_review"))
    known = {item["id"] for item in items}; unknown = sorted(wanted - known)
    if unknown: raise SystemExit("未知 D 编号：" + "、".join(unknown))
    requests = []
    for item in items:
        if item["id"] not in wanted: continue
        start, end = item["time_range"].split("–")
        requests.append({"d_id": item["id"], "block": item["block"], "start_seconds": ts(start), "end_seconds": ts(end),
                         "reason": "文字和完整上下文复核后仍需原音证据。"})
    a.out.parent.mkdir(parents=True, exist_ok=True)
    a.out.write_text(json.dumps({"schema_version": 1, "requests": requests}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"已生成音频证据请求：{a.out}（{len(requests)} 个 D 项）。")
if __name__ == "__main__": raise SystemExit(main())
