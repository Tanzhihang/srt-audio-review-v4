#!/usr/bin/env python3
"""Build a self-contained V4 HTML report that exposes complete semantic groups."""
from __future__ import annotations
import argparse
import html
import json
from pathlib import Path


def esc(value) -> str:
    return html.escape(str(value), quote=True)


def block_rows(rows) -> str:
    return "".join(
        f'<div class="subtitle-row"><b>第 {esc(row["block"])} 块</b><span>{esc(row["time_range"])}</span><p>{esc(row["text"])}</p></div>'
        for row in rows
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="生成显示完整跨块语义组的 V4 离线确认 HTML。")
    parser.add_argument("--candidates", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    data = json.loads(args.candidates.read_text(encoding="utf-8"))
    candidates = data.get("candidates", [])
    cards = []
    for item in candidates:
        after = item.get("replacement_texts")
        if isinstance(after, dict):
            replacement_rows = [{"block": int(k), "time_range": "", "text": v} for k, v in sorted(after.items(), key=lambda x: int(x[0]))]
            after_html = block_rows(replacement_rows)
        elif isinstance(after, list):
            replacement_rows = [{"block": row["block"], "time_range": row.get("time_range", ""), "text": row["text"]} for row in after]
            after_html = block_rows(replacement_rows)
        else:
            after_html = '<div class="pending">尚未填写联动修改文本；必须结合原音和连续语义组确认。</div>'
        evidence = "".join(f"<li>{esc(reason)}</li>" for reason in item.get("evidence", []))
        cards.append(f'''<article class="candidate" data-severity="{esc(item.get('severity'))}">
<header><span class="id">{esc(item['id'])}</span><span class="badge">{esc(item.get('severity'))}</span><span>第 {esc('–'.join(map(str,item['blocks'])))} 块</span><span>{esc(item.get('time_range'))}</span></header>
<div class="grid"><section><h2>修改前：连续字幕组</h2>{block_rows(item.get('original_texts', []))}</section><section><h2>修改后：必须整组填写</h2>{after_html}</section></div>
<div class="meta"><b>问题类型：</b>{esc(' / '.join(item.get('issue_types', [])))}<br><b>音频状态：</b>{esc(item.get('audio_review_status'))}<ul>{evidence}</ul><p>{esc(item.get('next_action'))}</p></div>
</article>''')
    source = f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SRT 校稿 V4 跨块语义断句确认表</title><style>
:root{{--bg:#f3f6fa;--ink:#142438;--blue:#174f82;--line:#d8e0ea;--warn:#fff4df;--bad:#b42318;--good:#147a50}}*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}}.hero{{padding:34px max(24px,5vw);color:white;background:linear-gradient(120deg,#173f67,#245d8f)}}.hero h1{{margin:0 0 8px;font-size:30px}}.hero p{{margin:4px 0;opacity:.92}}.toolbar{{position:sticky;top:0;z-index:2;padding:12px max(24px,5vw);background:#ffffffee;border-bottom:1px solid var(--line);backdrop-filter:blur(10px)}}input{{width:min(520px,100%);padding:10px 12px;border:1px solid #aab8c8;border-radius:8px}}main{{padding:24px max(24px,5vw) 60px}}.candidate{{background:white;border:1px solid var(--line);border-radius:14px;margin:0 0 18px;overflow:hidden;box-shadow:0 4px 16px #173f6710}}header{{display:flex;gap:14px;align-items:center;flex-wrap:wrap;padding:12px 16px;background:#edf4fb;border-bottom:1px solid var(--line)}}.id{{font-size:18px;font-weight:800;color:var(--blue)}}.badge{{border-radius:999px;padding:3px 9px;background:var(--warn);color:var(--bad);font-weight:700}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:16px}}section{{min-width:0}}h2{{font-size:16px;margin:0 0 10px}}.subtitle-row{{border:1px solid var(--line);border-radius:9px;padding:10px;margin:8px 0}}.subtitle-row span{{margin-left:10px;color:#64748b;font-size:12px}}.subtitle-row p{{margin:8px 0 0;font-size:17px;line-height:1.55}}.pending{{padding:16px;background:var(--warn);border-radius:9px;color:#7a4a00}}.meta{{padding:0 16px 16px;line-height:1.6}}.meta ul{{margin:8px 0}}@media(max-width:820px){{.grid{{grid-template-columns:1fr}}}}
</style></head><body><div class="hero"><h1>SRT 校稿 V4 跨块语义断句确认表</h1><p>每个 B 编号对应一个连续字幕语义组；禁止只修改其中一块。</p><p>扫描 {esc(data.get('source_blocks'))} 块，发现 {esc(data.get('issue_count'))} 个边界问题，合并为 {esc(len(candidates))} 个 B 语义组。</p></div><div class="toolbar"><input id="search" placeholder="搜索 B 编号、块号或字幕内容"></div><main>{''.join(cards)}</main><script>
const q=document.getElementById('search');q.addEventListener('input',()=>{{const v=q.value.trim().toLowerCase();document.querySelectorAll('.candidate').forEach(x=>x.hidden=v&&!x.innerText.toLowerCase().includes(v))}});
</script></body></html>'''
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(source, encoding="utf-8")
    print(f"已生成 V4 跨块确认 HTML：{args.out}（{len(candidates)} 个 B 语义组）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
