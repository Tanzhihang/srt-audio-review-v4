#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Create the final candidate-only review queue without altering an SRT.

Every subtitle block is still scanned by full_srt_prescan.py.  This helper keeps
full previous/current/next dialogue for each *flagged* candidate, so the model
reviews the relevant evidence instead of producing a 1-row audit for every
non-flagged subtitle block.
"""
from __future__ import annotations
import argparse
import json
from collections import Counter
from pathlib import Path


def load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description="生成 最终方案候选块复核队列；不压缩 D 项对白，也不修改 SRT。")
    parser.add_argument("--prescan", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()

    prescan = load(args.prescan.expanduser().resolve())
    if not prescan.get("full_scan_complete"):
        raise SystemExit("全文扫描未完成，拒绝建立快速复核队列。")
    candidates = prescan.get("candidates", [])
    automatic = [item for item in candidates if item.get("source") == "automated_full_text_scan"]
    queue = {
        "schema_version": 4,
        "mode": "candidate_only_review",
        "source_srt_blocks": prescan.get("source_srt_blocks"),
        "full_scan_complete": True,
        "full_scan_block_count": prescan.get("scanned_block_count"),
        "compression_forbidden": True,
        "review_instruction": "只审校候选所在块；每项保留完整前一块/本块/后一块。不得生成 452 块逐条长审计，也不得把不连续对白合并。",
        "automatic_candidate_count": len(automatic),
        "automatic_candidate_block_count": len({item["block"] for item in automatic}),
        "classifications": dict(Counter(item.get("classification", "未分类") for item in automatic)),
        "candidates": automatic,
    }
    out = args.out.expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(queue, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"最终方案复核队列已写入：{out}（全文扫描 {queue['full_scan_block_count']} 块；候选 {len(automatic)} 项 / {queue['automatic_candidate_block_count']} 块）。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
