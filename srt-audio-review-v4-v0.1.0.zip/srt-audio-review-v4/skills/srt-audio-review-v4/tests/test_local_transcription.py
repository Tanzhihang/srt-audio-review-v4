"""Validate the offline loader contract without downloading or running Whisper."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "transcribe_local_whisper.py"


class LocalTranscriptionTests(unittest.TestCase):
    def test_existing_model_is_loaded_by_path_and_word_timestamps_are_requested(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            runtime, models = root / "runtime", root / "models"
            runtime.mkdir()
            models.mkdir()
            (models / "small.pt").write_bytes(b"test model placeholder")
            audio, output = root / "audio.wav", root / "transcript.json"
            audio.write_bytes(b"test audio placeholder")
            (runtime / "whisper.py").write_text('''
from pathlib import Path
class Model:
    def transcribe(self, audio, **kwargs):
        assert kwargs["word_timestamps"] is True
        assert kwargs["fp16"] is False
        assert kwargs["task"] == "transcribe"
        return {"text": "demo", "segments": []}
def load_model(path, *, device):
    assert Path(path).is_file(), "model name could trigger a download"
    assert device == "cpu"
    return Model()
''', encoding="utf-8")
            result = subprocess.run([
                sys.executable, str(SCRIPT), "--audio", str(audio), "--out", str(output),
                "--runtime-dir", str(runtime), "--model-dir", str(models),
            ], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            payload = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(payload["text"], "demo")
            self.assertFalse(payload["network_api_called"])
            self.assertFalse(payload["audio_uploaded"])
            self.assertEqual(audio.read_bytes(), b"test audio placeholder")

    def test_missing_model_stops_before_importing_whisper(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            audio, output = root / "audio.wav", root / "out.json"
            audio.write_bytes(b"test audio placeholder")
            runtime = root / "runtime"
            runtime.mkdir()
            (runtime / "whisper.py").write_text("raise RuntimeError('must not import')\n")
            result = subprocess.run([
                sys.executable, str(SCRIPT), "--audio", str(audio), "--out", str(output),
                "--runtime-dir", str(runtime), "--model-dir", str(root / "missing"),
            ], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("缺少本地模型", result.stderr)
            self.assertNotIn("must not import", result.stderr)
            self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
