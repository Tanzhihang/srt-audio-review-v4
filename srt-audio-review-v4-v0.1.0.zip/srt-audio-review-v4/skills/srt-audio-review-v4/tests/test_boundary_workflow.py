#!/usr/bin/env python3
from __future__ import annotations
import json
import hashlib
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
from boundary_common import coalesce_issues, detect_boundary_issues, read_srt


def make_srt(lines: list[str]) -> str:
    parts = []
    for i, text in enumerate(lines, 1):
        parts.append(f"{i}\n00:00:{i:02d},000 --> 00:00:{i+1:02d},000\n{text}")
    return "\n\n".join(parts) + "\n\n"


def group(item_id: str, blocks: list[int], originals: list[str], replacements: list[str], *, audio="resolved") -> dict:
    return {
        "id": item_id,
        "blocks": blocks,
        "original_texts": [{"block": n, "text": text} for n, text in zip(blocks, originals)],
        "replacement_texts": [{"block": n, "text": text} for n, text in zip(blocks, replacements)],
        "requires_audio_review": True,
        "audio_review_status": audio,
        "status": "confirmed",
    }


def timed_group(audio_path: Path, *, status="resolved", first_end="00:00:01,800", second_start="00:00:01,800") -> dict:
    audio_hash = hashlib.sha256(audio_path.read_bytes()).hexdigest()
    return {
        "id": "B0001",
        "blocks": [1, 2],
        "original_texts": [
            {"block": 1, "time_range": "00:00:01,000 --> 00:00:02,000", "text": "一期视频告诉你这个原"},
            {"block": 2, "time_range": "00:00:02,000 --> 00:00:03,000", "text": "厂升顶帐篷"},
        ],
        "replacement_texts": [
            {"block": 1, "text": "一期视频告诉你"},
            {"block": 2, "text": "这个原厂升顶帐篷"},
        ],
        "replacement_timecodes": [
            {"block": 1, "time_range": f"00:00:01,000 --> {first_end}"},
            {"block": 2, "time_range": f"{second_start} --> 00:00:03,000"},
        ],
        "requires_audio_timing_review": True,
        "audio_timing_review_status": status,
        "audio_timing_evidence": {
            "source_audio_sha256": audio_hash,
            "method": "manual_listen+word_timestamps",
            "clip_range_seconds": [0.0, 4.0],
            "internal_boundaries": [{
                "left_block": 1,
                "right_block": 2,
                "left_end_seconds": 1.8,
                "right_start_seconds": 1.8,
                "decision_basis": "原音在“你”后出现清晰停顿，“这个原厂”连续发音",
                "confidence": "high",
            }],
        },
        "status": "confirmed",
    }


def run_script(name: str, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPTS / name), *map(str, args)],
        capture_output=True,
        text=True,
    )


class BoundaryWorkflowTests(unittest.TestCase):
    def test_detects_exact_overlap_split_term_and_term_restart(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "x.srt"
            path.write_text(make_srt([
                "这里边应该可以", "可以放三角牌",
                "非常强的通过性以及车顶", "帐和厨房",
                "以及车顶", "车顶帐可以打开",
            ]), encoding="utf-8")
            blocks, _, _ = read_srt(path)
            issues = detect_boundary_issues(blocks, ["车顶帐"])
            kinds = {(x["left_block"], x["issue_type"]) for x in issues}
            self.assertIn((1, "exact_overlap"), kinds)
            self.assertIn((3, "split_term"), kinds)
            self.assertIn((5, "term_restart"), kinds)

    def test_coalesces_three_block_repeat_chain(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "x.srt"
            path.write_text(make_srt(["它是通过这两个", "这两个X型的铰链", "铰链来撑起侧边帐"]), encoding="utf-8")
            blocks, _, _ = read_srt(path)
            candidates = coalesce_issues(blocks, detect_boundary_issues(blocks))
            blocking = [x for x in candidates if x["severity"] == "blocking"]
            self.assertEqual(len(blocking), 1)
            self.assertEqual(blocking[0]["blocks"], [1, 2, 3])
            self.assertEqual(len(blocking[0]["original_texts"]), 3)

    def test_review_diagnosis_on_blocking_boundary_is_not_duplicated(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "x.srt"
            path.write_text(make_srt(["这里可以", "可以打开"]), encoding="utf-8")
            blocks, _, _ = read_srt(path)
            candidates = coalesce_issues(blocks, detect_boundary_issues(blocks))
            self.assertEqual(len(candidates), 1)
            self.assertIn("exact_overlap", candidates[0]["issue_types"])
            self.assertIn("dangling_tail", candidates[0]["issue_types"])

    def test_adjacent_review_boundaries_form_disjoint_single_group(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "x.srt"
            path.write_text(make_srt(["这是一个", "有一个", "完整结果"]), encoding="utf-8")
            blocks, _, _ = read_srt(path)
            candidates = coalesce_issues(blocks, detect_boundary_issues(blocks))
            self.assertEqual(len(candidates), 1)
            self.assertEqual(candidates[0]["blocks"], [1, 2, 3])

    def test_filler_cleanup_exposes_boundary_repeat(self):
        with tempfile.TemporaryDirectory() as td:
            before = Path(td) / "before.srt"
            after = Path(td) / "after.srt"
            before.write_text(make_srt(["它的迎宾灯嗯", "迎宾灯会自动亮起"]), encoding="utf-8")
            after.write_text(make_srt(["它的迎宾灯", "迎宾灯会自动亮起"]), encoding="utf-8")
            before_blocks, _, _ = read_srt(before)
            after_blocks, _, _ = read_srt(after)
            self.assertFalse(any(x["issue_type"] == "exact_overlap" for x in detect_boundary_issues(before_blocks)))
            self.assertTrue(any(x["token"] == "迎宾灯" for x in detect_boundary_issues(after_blocks)))

    def test_atomic_apply_rejects_unresolved_audio_even_with_suggestion(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, edits, out, report = td/"x.srt", td/"edits.json", td/"out.srt", td/"report.json"
            src.write_text(make_srt(["都是有", "有一点费劲"]), encoding="utf-8")
            edits.write_text(json.dumps([group("B0001", [1, 2], ["都是有", "有一点费劲"], ["都是", "有一点费劲"], audio="unresolved")], ensure_ascii=False), encoding="utf-8")
            result = run_script("apply_confirmed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(out.exists())

    def test_atomic_apply_changes_both_blocks_together(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, edits, out, report = td/"x.srt", td/"edits.json", td/"out.srt", td/"report.json"
            src.write_text(make_srt(["都是有", "有一点费劲"]), encoding="utf-8")
            edits.write_text(json.dumps([group("B0001", [1, 2], ["都是有", "有一点费劲"], ["都是", "有一点费劲"])], ensure_ascii=False), encoding="utf-8")
            result = run_script("apply_confirmed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
            self.assertEqual(result.returncode, 0, result.stderr)
            blocks, _, _ = read_srt(out)
            self.assertEqual([x.text for x in blocks], ["都是", "有一点费劲"])

    def test_atomic_apply_original_mismatch_aborts_entire_output(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, edits, out, report = td/"x.srt", td/"edits.json", td/"out.srt", td/"report.json"
            src.write_text(make_srt(["应该可以", "可以放", "车顶", "帐打开"]), encoding="utf-8")
            payload = [
                group("B0001", [1, 2], ["应该可以", "可以放"], ["应该", "可以放"]),
                group("B0002", [3, 4], ["错误原文", "帐打开"], ["车顶帐", "打开"]),
            ]
            edits.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            result = run_script("apply_confirmed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(out.exists())
            self.assertFalse(json.loads(report.read_text(encoding="utf-8"))["passed"])

    def test_atomic_apply_rejects_overlapping_groups(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, edits, out, report = td/"x.srt", td/"edits.json", td/"out.srt", td/"report.json"
            src.write_text(make_srt(["甲可以", "可以乙", "乙结束"]), encoding="utf-8")
            payload = [
                group("B0001", [1, 2], ["甲可以", "可以乙"], ["甲", "可以乙"]),
                group("B0002", [2, 3], ["可以乙", "乙结束"], ["可以", "乙结束"]),
            ]
            edits.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            result = run_script("apply_confirmed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse(out.exists())

    def test_final_validator_blocks_unresolved_overlap(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            srt, report = td/"x.srt", td/"report.json"
            srt.write_text(make_srt(["这里应该可以", "可以放进去"]), encoding="utf-8")
            result = run_script("validate_cross_block_semantics.py", "--srt", srt, "--baseline", srt, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            data = json.loads(report.read_text(encoding="utf-8"))
            self.assertGreater(data["unresolved_issue_count"], 0)
            self.assertFalse(data["passed"])

    def test_allowlist_requires_reason_and_valid_reason_can_pass(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            srt, bad, good = td/"x.srt", td/"bad.json", td/"good.json"
            bad_report, good_report = td/"bad-report.json", td/"good-report.json"
            srt.write_text(make_srt(["这里应该可以", "可以放进去"]), encoding="utf-8")
            blocks, _, _ = read_srt(srt)
            issues = detect_boundary_issues(blocks)
            bad.write_text(json.dumps([{"signature": issues[0]["signature"], "reason": ""}], ensure_ascii=False), encoding="utf-8")
            bad_result = run_script("validate_cross_block_semantics.py", "--srt", srt, "--allowlist", bad, "--report", bad_report)
            self.assertNotEqual(bad_result.returncode, 0)
            good.write_text(json.dumps([{"signature": issue["signature"], "reason": "人工结合原音确认是有意重复"} for issue in issues], ensure_ascii=False), encoding="utf-8")
            good_result = run_script("validate_cross_block_semantics.py", "--srt", srt, "--allowlist", good, "--report", good_report)
            self.assertEqual(good_result.returncode, 0, good_result.stderr)
            self.assertTrue(json.loads(good_report.read_text(encoding="utf-8"))["passed"])

    def test_final_validator_blocks_residual_filler(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            srt, report = td/"x.srt", td/"report.json"
            srt.write_text(make_srt(["这个呢很好用", "马上出发"]), encoding="utf-8")
            result = run_script("validate_cross_block_semantics.py", "--srt", srt, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            data = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(data["unresolved_filler_count"], 1)
            self.assertEqual(data["unresolved_fillers"][0]["token"], "呢")

    def test_final_validator_rejects_timecode_change(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            baseline, changed, report = td/"base.srt", td/"changed.srt", td/"report.json"
            baseline.write_text(make_srt(["今天出发", "马上到达"]), encoding="utf-8")
            changed.write_text(make_srt(["今天出发", "马上到达"]).replace("00:00:01,000 --> 00:00:02,000", "00:00:01,100 --> 00:00:02,000"), encoding="utf-8")
            result = run_script("validate_cross_block_semantics.py", "--srt", changed, "--baseline", baseline, "--report", report)
            self.assertNotEqual(result.returncode, 0)
            self.assertTrue(any("时间码改变" in x for x in json.loads(report.read_text(encoding="utf-8"))["structural_failures"]))

    def test_timed_atomic_apply_moves_internal_cut_and_preserves_outer_bounds(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, audio, edits, out, report = td/"x.srt", td/"audio.m4a", td/"edits.json", td/"out.srt", td/"apply.json"
            src.write_text(make_srt(["一期视频告诉你这个原", "厂升顶帐篷"]), encoding="utf-8")
            audio.write_bytes(b"test audio evidence")
            edits.write_text(json.dumps([timed_group(audio)], ensure_ascii=False), encoding="utf-8")
            result = run_script("apply_confirmed_timed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
            self.assertEqual(result.returncode, 0, result.stderr)
            blocks, _, _ = read_srt(out)
            self.assertEqual([x.text for x in blocks], ["一期视频告诉你", "这个原厂升顶帐篷"])
            self.assertEqual(blocks[0].timecode, "00:00:01,000 --> 00:00:01,800")
            self.assertEqual(blocks[1].timecode, "00:00:01,800 --> 00:00:03,000")

    def test_timed_atomic_apply_rejects_unresolved_or_outer_bound_change(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, audio = td/"x.srt", td/"audio.m4a"
            src.write_text(make_srt(["一期视频告诉你这个原", "厂升顶帐篷"]), encoding="utf-8")
            audio.write_bytes(b"test audio evidence")
            for index, payload in enumerate((
                timed_group(audio, status="pending"),
                timed_group(audio),
            )):
                if index == 1:
                    payload["replacement_timecodes"][0]["time_range"] = "00:00:01,100 --> 00:00:01,800"
                edits, out, report = td/f"edits-{index}.json", td/f"out-{index}.srt", td/f"report-{index}.json"
                edits.write_text(json.dumps([payload], ensure_ascii=False), encoding="utf-8")
                result = run_script("apply_confirmed_timed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", report)
                self.assertNotEqual(result.returncode, 0)
                self.assertFalse(out.exists())

    def test_audio_timing_release_gate_and_conservation_allow_timing_changes(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, audio, edits, out = td/"x.srt", td/"audio.m4a", td/"edits.json", td/"out.srt"
            apply_report, timing_report, conservation_report = td/"apply.json", td/"timing.json", td/"conservation.json"
            src.write_text(make_srt(["一期视频告诉你这个原", "厂升顶帐篷"]), encoding="utf-8")
            audio.write_bytes(b"test audio evidence")
            edits.write_text(json.dumps([timed_group(audio)], ensure_ascii=False), encoding="utf-8")
            applied = run_script("apply_confirmed_timed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", apply_report)
            self.assertEqual(applied.returncode, 0, applied.stderr)
            timing = run_script("validate_audio_timing_alignment.py", "--srt", out, "--edits", edits, "--audio", audio, "--report", timing_report)
            self.assertEqual(timing.returncode, 0, timing.stderr)
            conserved = run_script("validate_boundary_text_conservation.py", "--before", src, "--after", out, "--allow-timing-changes", "--report", conservation_report)
            self.assertEqual(conserved.returncode, 0, conserved.stdout + conserved.stderr)
            rejected_without_flag = run_script("validate_boundary_text_conservation.py", "--before", src, "--after", out, "--report", td/"strict.json")
            self.assertNotEqual(rejected_without_flag.returncode, 0)

    def test_audio_timing_release_gate_rejects_wrong_audio(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            src, audio, wrong_audio, edits, out = td/"x.srt", td/"audio.m4a", td/"wrong.m4a", td/"edits.json", td/"out.srt"
            src.write_text(make_srt(["一期视频告诉你这个原", "厂升顶帐篷"]), encoding="utf-8")
            audio.write_bytes(b"correct audio")
            wrong_audio.write_bytes(b"wrong audio")
            edits.write_text(json.dumps([timed_group(audio)], ensure_ascii=False), encoding="utf-8")
            applied = run_script("apply_confirmed_timed_group_edits.py", "--srt", src, "--edits", edits, "--out", out, "--report", td/"apply.json")
            self.assertEqual(applied.returncode, 0, applied.stderr)
            timing = run_script("validate_audio_timing_alignment.py", "--srt", out, "--edits", edits, "--audio", wrong_audio, "--report", td/"timing.json")
            self.assertNotEqual(timing.returncode, 0)

    def test_final_validator_allows_valid_audio_timing_change_with_flag(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            baseline, changed, report = td/"base.srt", td/"changed.srt", td/"report.json"
            baseline.write_text(make_srt(["今天出发", "马上到达"]), encoding="utf-8")
            changed.write_text(make_srt(["今天出发", "马上到达"]).replace(
                "00:00:01,000 --> 00:00:02,000\n今天出发\n\n2\n00:00:02,000 --> 00:00:03,000",
                "00:00:01,000 --> 00:00:01,800\n今天出发\n\n2\n00:00:01,800 --> 00:00:03,000",
            ), encoding="utf-8")
            result = run_script("validate_cross_block_semantics.py", "--srt", changed, "--baseline", baseline, "--allow-timing-changes", "--report", report)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(json.loads(report.read_text(encoding="utf-8"))["passed"])

    def test_three_block_html_displays_complete_group(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td)
            srt, candidates, html = td/"x.srt", td/"candidates.json", td/"out.html"
            texts = ["它是通过这两个", "这两个X型的铰链", "铰链来撑起侧边帐"]
            srt.write_text(make_srt(texts), encoding="utf-8")
            build = run_script("build_boundary_candidates.py", "--srt", srt, "--out", candidates)
            self.assertEqual(build.returncode, 0, build.stderr)
            render = run_script("build_boundary_confirmation_html.py", "--candidates", candidates, "--out", html)
            self.assertEqual(render.returncode, 0, render.stderr)
            source = html.read_text(encoding="utf-8")
            for text in texts:
                self.assertIn(text, source)
            self.assertIn("第 1–2–3 块", source)
            self.assertNotIn("http://", source)
            self.assertNotIn("https://", source)


if __name__ == "__main__":
    unittest.main()
